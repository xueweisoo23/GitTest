import React, { Component, PropTypes } from 'react';
import { Button, FormControl, ControlLabel, FormGroup, Form } from 'react-bootstrap';
import { DynamicDataGrid, HorizontalLayout, FixedPanel, FlexPanel, VerticalLayout, connectCdtDataComponent } from 'ssc-cdt3';
import { connect } from 'react-redux';
import * as _service from '../service';
import ModalWindow from '../components/ModalWindow';
import * as _actionCreators from '../redux/ActionCreators';
import MessageDialog, * as _dialog from '../components/MessageDialog';
import { bindActionCreators } from 'redux';
import FileUpload from '../components/FileUpload';
import { Link } from 'react-router';
import * as _sutils from '../sharedutils';
import ClientSelectionHeader from '../components/ClientSelectionHeader';
import { MAPPING_DATA_COLUMNS } from '../shared/ColumnConfigs';

const UPLOAD_FILE = {
  fileTypes: ['.xlsx', '.xls', '.csv'],
  maxFilesAllowed: 1,
  templateFileId: '',
};


function mapStateToProps(state) {
  return {
    showHelpModalWindow: (state.modalWindow.HELP_WINDOW ? state.modalWindow.HELP_WINDOW : false),
    showFileUploadModalWindow: (state.modalWindow.FILE_UPLOAD ? state.modalWindow.FILE_UPLOAD : false),
    showMessageDialog: state.messageDialog.showMessageDialog,
    messageDialogParams: state.messageDialog.messageDialogParams,
    selectedClient: state.clients.selectedClient,
    isClientSelectionChanged: state.clients.isClientSelectionChanged,
    helpData: state.help.helpData,
  }
}

@connect(mapStateToProps, function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
})

@connectCdtDataComponent('mappingRuleList', 553840008)
@connectCdtDataComponent('reload', 553840014)
export default class MappingDataContainer extends Component {

  static contextTypes = {
    router: React.PropTypes.object.isRequired,
  }


  constructor(props) {
    super(props);
    this.state = {
      editRow: undefined, editErrors: undefined, checkedRows: [],
      inputParams: { isChildMode: false, mappingRuleId: undefined }, mappingRuleId: undefined, fileContent: undefined
    }
    
    this.existingRuleMappingId="";
    //addded coments
  }

  static defaultProps = {
    showMessageDialog: false
  }
  static propTypes = {
    mappingRuleList: PropTypes.object,
    mappingRuleListActions: PropTypes.object,
    reload:  PropTypes.object,
    reloadActions: PropTypes.object,
  }

  onCheck = (checked) => {
    this.setState({ checkedRows: checked });
  }
  addNew = () => {
    this.modifiedRow = {};
    this.modifiedRow.MAPPING_RULE_ID = this.existingRuleMappingId;
    this.setState({ editRow: this.modifiedRow, editErrors: undefined, });
  }

  uploadFileCallback = (filename, isSuccess, message) => {
    console.log('uploadFileCallback=>filename:' + filename + ':isSuccess:' + isSuccess + ':message:' + message);
    if (isSuccess) {
      this.props.actions.hideModalWindow('FILE_UPLOAD');
      this.gridActions.success('Success', 'File processed successfully. ');
      if (this.state.inputParams.isChildMode)
        this.connectCallback(this.gridActions, this.state.inputParams.mappingRuleId, true);
      else {
        this.loadMappingRuleList();
        if (this.state.mappingRuleId && this.state.mappingRuleId.trim() != '')
          this.connectCallback(this.gridActions, this.state.mappingRuleId, false);
      }
    } else {
      this.gridActions.error('Error', message);
    }
  }
  onDeleteLinkClick = () => {
    this.props.actions.showMessageDialog("Confirm Action", _dialog.DIALOG_TYPE_YES_NO, 'Are you sure you would like to delete ?', null, this.deleteDialogCallback, this);
  }
  deleteDialogCallback = (btntype, param) => {
    if (_dialog.BTN_TYPE_YES === btntype) {

      this.remove();
    }

  }
  remove = () => {
    var checkedRow = [];
    checkedRow = this.state.checkedRows;
    if (checkedRow.length == 0)
      checkedRow = [{ MAPPING_RULE_ID: this.state.mappingRuleId, CLIENT_ID: _sutils.getSelectedClientId() }];/*To delete all mapping_data based on mapping_rule_id */
    this.gridActions.delete(checkedRow).then((ret) => {
      if (ret.error) {
        this.gridActions.error('Error', ret.payload._error || 'Error deleting items.');
      } else {
        this.connectCallback(this.gridActions, this.state.mappingRuleId, false);
        this.gridActions.success('Success', 'Mapping data deleted successfully.');
        this.setState({ editRow: undefined, editErrors: undefined, checkedRows: [] });

      }
    });
  }

  onReloadLinkClick = () =>{
    let params= [];
    if(!this.state.checkedRows.length)
    {
         params = [{ MAPPING_RULE_ID: this.state.mappingRuleId, CLIENT_ID: _sutils.getSelectedClientId() }];
         this.props.actions.showMessageDialog("Confirm Action", _dialog.DIALOG_TYPE_YES_NO, 'Are you sure you would like to Reload all the values ?', params, this.reloadDialogCallback, this);
    }
    else{
      var INPUT_COL1_TXT=[];
      this.state.checkedRows.map((obj)=>{
        INPUT_COL1_TXT.push(obj.INPUT_COL1_TXT);
      });
       params = [{ INPUT_COL1_TXT: INPUT_COL1_TXT.join(), MAPPING_RULE_ID: this.state.mappingRuleId, CLIENT_ID: _sutils.getSelectedClientId() }];
         this.reload(params);
    }
  }
  
    reloadDialogCallback = (btntype, params) => {
        if (_dialog.BTN_TYPE_YES === btntype) {
          this.reload(params);
        }
      }

      reload= (params)=>{
        _service.makeCallWithHandlers(this.props.reloadActions, _service.CALL_TYPE_LOADLIST,params, this.reloadLinkCallback, null, undefined, this.props);
      }

        reloadLinkCallback = (ret, actions, spinJobId) => {
          if (ret.payload.data && ret.payload.data.length > 0){
            if(ret.payload.data[0].MESSAGE)
              this.props.reloadActions.error('Error',  ret.payload.data[0].MESSAGE);
          }

    }

  onRowDoubleClick = (row) => {
    this.modifiedRow = {...row }; // clone for new values
    this.setState({ editRow: row, editErrors: undefined });
  }

  connectCallback = (gridActions, mappingRuleId, onlyEmptyOutput) => {
    this.gridActions = gridActions;
    _service.makeCallWithHandlers(gridActions, _service.CALL_TYPE_LOADLIST, { MAPPING_RULE_ID: mappingRuleId, CLIENT_ID: _sutils.getSelectedClientId(), FILTER_EMPTY_OUTPUT_ONLY: onlyEmptyOutput }, this.gridLoadSuccessCallback, null, undefined, this.props);
  }

  gridLoadSuccessCallback = (ret, actions, spinJobId) => {
	    if (ret.payload.data && ret.payload.data.length > 0)
	       this.existingRuleMappingId = ret.payload.data[0].MAPPING_RULE_ID;
	     else
	    	  this.existingRuleMappingId = undefined;
	    }
  
  mappingRuleSuccessCallback = (ret, actions, spinJobId) => {
    if (ret.payload.data && ret.payload.data.length > 0) {
      //this.connectCallback(this.gridActions,'',false); //JUST FOR NOW adding will remove later, as not sure how to show the empty grid.
    }
  }


  componentWillMount() {
    if (_sutils.doCheckforEntitlement(this, true)) {
      const {inputParams} = this.props
      if (!(inputParams && inputParams.isChildMode))
        this.loadMappingRuleList();
    }
  }

  componentDidMount() {
    const {inputParams} = this.props
    if (inputParams && inputParams.isChildMode) {
      this.setState({ inputParams }, this.connectCallback(this.gridActions, inputParams.mappingRuleId, true))
    }
  }

  loadMappingRuleList = () => {
    _service.makeCallWithHandlers(this.props.mappingRuleListActions, _service.CALL_TYPE_LOADLIST, { CALL_TYPE: 'MAPPING_RULE_LIST', FILTER1: _sutils.getSelectedClientId() }, this.mappingRuleSuccessCallback, null, undefined, this.props);
  }

  componentWillReceiveProps(props) {
    if (!this.state.inputParams.isChildMode && this.props.selectedClient.CODE_VALUE != props.selectedClient.CODE_VALUE && props.isClientSelectionChanged)
      this.loadMappingRuleList();

    //  if (props.inputParams.isChildMode!==this.props.inputParams.isChildMode)
    //       this.connectCallback(this.gridActions,props.inputParams.mappingRuleId);
  }


  modalClosedCallback = (btnType, id) => {
    console.log('id:' + id + ':btnType:' + btnType);
    // this.setState({showFileUploadDialog:false});
  }
  showHelpWindow = () => {
    let {helpData} = this.props;
    helpData.map((obj) => {
      if (obj.HELP_DEF_ID == "MAPPING_DATA") {
        this.setState({ fileContent: { __html: obj.FILE_CONTENT } });
      }
    });
    this.props.actions.showModalWindow('HELP_WINDOW');
  }

  onChange = (value, column) => {
    const {editErrors = {}} = this.state;
    this.modifiedRow[column.dataKey] = value;
    if (!value) {
      this.setState(
        { editRow: {...this.modifiedRow},
    editErrors: {...editErrors, [column.dataKey]: `${column.label} is required.` }
  });
} else {
  this.setState({
    editRow: {...this.modifiedRow},
editErrors: {...editErrors, [column.dataKey]: undefined }
      });
    }
return true;
  }

onKeyDown = (e) => {
  switch (e.keyCode) {
    case 13: // enter key
      if (typeof this.modifiedRow['KEY_ID'] === 'undefined') {
        this.add();
      } else {
        this.update();
      }
      break;
    case 27: // escape key
      e.preventDefault();
      e.stopPropagation();
      this.setState({ editRow: undefined });
      break;
    default:
      break;
  }
}

update = () => {
  this.modifiedRow.CLIENT_ID = _sutils.getSelectedClientId();
  if (this.validate()) {
    this.gridActions.update(this.modifiedRow).then((ret) => {
      if (ret.error) {
        this.gridActions.error('Error', ret.payload._error || 'Please correct errors.');
        this.setState({ editErrors: ret.payload });
      } else {
        let mappingRuleId = this.state.inputParams.isChildMode ? this.state.inputParams.mappingRuleId : this.state.mappingRuleId;
        this.connectCallback(this.gridActions, mappingRuleId, this.state.inputParams.isChildMode);
        this.gridActions.success('Success', 'Update was successful.');
        this.setState({ editRow: undefined });
      }
    });
  }
}

add = () => {
  this.modifiedRow.CLIENT_ID = _sutils.getSelectedClientId();
  if (this.validate()) {
    this.gridActions.addNew(this.modifiedRow).then((ret) => {
      if (ret.error) {
        this.gridActions.error('Error', ret.payload._error || 'Please correct errors.');
        this.setState({ editErrors: ret.payload });
      } else {
        if (!this.state.mappingRuleId || this.state.mappingRuleId.trim() == '')
          this.loadMappingRuleList();

        this.connectCallback(this.gridActions, this.state.mappingRuleId, false);
        this.gridActions.success('Success', `New record inserted!`);
        this.setState({ editRow: undefined });
      }
    });
  }
}

validate() {
  // plug in any validation framework here
  const errors = {};
  if (!this.modifiedRow.MAPPING_RULE_ID) {
    errors.MAPPING_RULE_ID = 'Mapping rule ID is required';
  }
  if (!this.modifiedRow.INPUT_COL1_TXT) {
    errors.INPUT_COL1_TXT = 'Input column1 is required';
  }

  if (!this.modifiedRow.OUTPUT_COL_TXT) {
    errors.OUTPUT_COL_TXT = 'Output is required';
  }
  /* if (!this.modifiedRow.FILE_MAPPING_ID) {
     errors.OUTPUT = 'File Mapping is required';
   }*/
  this.setState({ editErrors: errors });
  return Object.keys(errors).length === 0;
}

showUploadWindow = () => {
  this.props.actions.showModalWindow('FILE_UPLOAD');
}

mappingRuleChanged = (event) => {
  this.setState({ mappingRuleId: event.target.value });
  this.connectCallback(this.gridActions, event.target.value, false);
}
render() {
  let {checkedRows, inputParams, mappingRuleId} = this.state;
  let {data} = this.props.mappingRuleList;
  let enableDelete = checkedRows && checkedRows.length > 0;
  let enableDeleteAll = mappingRuleId != undefined && mappingRuleId.trim() != '';
  let enableAdd = typeof editRow === 'undefined';
  let MESSAGE_DIALOG = <MessageDialog showDialog={this.props.showMessageDialog} messageDialogParams={this.props.messageDialogParams} />
  const CLIENT_HEADER = <ClientSelectionHeader />
  let FILE_UPLOAD = <ModalWindow id={'FILE_UPLOAD'} modalHeader={'Mapping data upload'} buttons={[]} showModalWindow={this.props.showFileUploadModalWindow} modalCloseCallback={this.modalClosedCallback}>
    <VerticalLayout flex='flex' style={{ width: '100%' }}>
      <FileUpload fileUploadCallback={this.uploadFileCallback.bind(this)} callType={'MAPPING_DATA_UPLOAD'} paramObject={{ PARAM2: _sutils.getSelectedClientId() }} fileUploadConfig={UPLOAD_FILE} />
    </VerticalLayout>
  </ModalWindow>;

  let HELP_WINDOW = <ModalWindow id={'HELP_WINDOW'} modalHeader={'Help'} buttons={[]} showModalWindow={this.props.showHelpModalWindow}
    modalCloseCallback={this.modalClosedCallback}>
    <VerticalLayout flex='flex' style={{ width: '100%' }}>
      <span dangerouslySetInnerHTML={this.state.fileContent}></span>
    </VerticalLayout>
  </ModalWindow>;
  const MAPPING_RULE_CONTROL = <div style={{ display: 'inline-block', float: 'left' }}>
    <Form inline>
      <FormGroup bsSize="small">
        <label>&nbsp;&nbsp;{'Mapping Rule ID'}&nbsp;</label>
        <FormControl componentClass="select" placeholder="select" onChange={this.mappingRuleChanged.bind(this)} >
          {
            (() => {
              if (data && data.length > 0) {
                return data.map((x) => {
                  return <option value={x.CODE_VALUE} key={x.CODE_VALUE}>{x.LABEL}</option>
                })
              }
            })()
          }
        </FormControl>
      </FormGroup>
    </Form>
  </div>
  const ADD_BUTTON = <Button className='btn btn-primary btn-xs' style={{ marginRight: 8 }}
    disabled={!enableAdd} onClick={this.addNew} >Add</Button>
  const DELETE_BUTTON = <Button className='btn btn-primary btn-xs' style={{ marginRight: 8 }} onClick={this.onDeleteLinkClick} disabled={!enableDelete}>Delete</Button>
  const DELETE_ALL_BUTTON = <Button className='btn btn-primary btn-xs' style={{ marginRight: 8 }} onClick={this.onDeleteLinkClick} disabled={!enableDeleteAll}>Delete All</Button>
  const SCREEN_HEADER = <h3 style={{ marginTop: 0, marginBottom: 0, width: 760 }}> <strong>Mapping Data Configuration</strong>
    <strong className=' fa fa-question-circle' style={{ color: '#286090', fontSize: 24, marginLeft: 10 ,cursor:'pointer' }}
      onClick={this.showHelpWindow.bind(this)} ></strong></h3>;
  const BREAK = <br />;
  const isChildMode = inputParams && inputParams.isChildMode
  const RELOAD_BUTTON = <Button className='btn btn-primary btn-xs' style={{ marginRight: 8 }} onClick={this.onReloadLinkClick} disabled={!enableDeleteAll}>Reload</Button>
  
  return (

    <HorizontalLayout>
      {!isChildMode && CLIENT_HEADER}
      <VerticalLayout flex='flex' onKeyDown={this.onKeyDown}>
        <FixedPanel style={{ overflow: 'visible' }}>
          {!isChildMode && SCREEN_HEADER}
          {!isChildMode && BREAK}
          {!isChildMode && MAPPING_RULE_CONTROL}
          <div style={{ display: 'inline-block', float: 'right' }}>
            {!isChildMode && ADD_BUTTON}
            {!isChildMode && DELETE_BUTTON}
            {!isChildMode && DELETE_ALL_BUTTON}
            {!isChildMode 
            && RELOAD_BUTTON}
            <Button className='btn btn-primary btn-xs' onClick={this.showUploadWindow.bind(this)}>Upload File</Button>
          </div>
        </FixedPanel>
        <FlexPanel>
          <DynamicDataGrid
            columns={MAPPING_DATA_COLUMNS}
            dataIdf={553840005}
            gridConnectCallback={this.connectCallback}
            componentId='translationGrid'
            keyFieldName='ID'
            editRow={this.state.editRow}
            onRowDoubleClick={this.onRowDoubleClick}
            onChange={this.onChange}
            editErrors={this.state.editErrors}
            onCheckedChange={this.onCheck}
            scale={1}
            pageSize={50}
            excelExport
            csvExport
            hasCheckbox
            />
        </FlexPanel>
        {FILE_UPLOAD}
        {HELP_WINDOW}
      </VerticalLayout>
      {MESSAGE_DIALOG}
    </HorizontalLayout>

  );
}
}



