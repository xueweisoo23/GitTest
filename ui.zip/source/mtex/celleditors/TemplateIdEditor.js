import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {DropdownList} from 'react-widgets';
import {connectCdtDataComponent} from 'ssc-cdt3';
import * as _service from '../service';
import * as _sutils from '../sharedutils'
import {OverlayTrigger, Popover} from 'react-bootstrap';
import {DropdownEditor} from './DropdownEditor';
import * as _actionCreators from '../redux/ActionCreators'; 
import { bindActionCreators } from 'redux'

function mapStateToProps(state) {
  return {
   selectedClient:state.clients.selectedClient,
   isClientSelectionChanged:state.clients.isClientSelectionChanged,
  }
}

@connect(mapStateToProps, function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
})
@connectCdtDataComponent('templateID',553840008)
export class TemplateIdEditor extends Component { // Refactor later to generic component and inherit for specific functions
  static propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    col: PropTypes.object,
    row: PropTypes.object,
    bottomOffset: PropTypes.number,
    rowHeight: PropTypes.number,
    templateID: PropTypes.object,
    templateIDActions: PropTypes.object,
  }

  constructor(props) {
    super(props);
    const {value} = props;
    this.state = {value};
  }

componentWillReceiveProps(props) {
    console.log(this.props);
    if(this.props.selectedClient.CODE_VALUE !== props.selectedClient.CODE_VALUE && props.isClientSelectionChanged)
    		this.callService();
  }

  callService =()=>{
    let clientId = _sutils.getSelectedClientId();
    _service.makeCallWithHandlers(this.props.templateIDActions,_service.CALL_TYPE_LOADLIST,{CALL_TYPE:'TEMPLATE_ID',FILTER1:clientId},null,null,undefined,this.props)
  }
  onChange = (val) => {
	  if (this.props.onChange(val, this.props.col)) {
      this.setState({value: val});
	  }
    
  }
   componentDidMount() {
      this.callService();
  }

  render() {
    const {col,error,templateID,row, bottomOffset, rowHeight} = this.props;
    return (
    <DropdownEditor value={this.state.value} onChange={this.onChange} col={col} row={row} bottomOffset={bottomOffset} rowHeight={rowHeight}
                    dropdownValues={templateID} error ={error}>
    </DropdownEditor>   
    );
  }
}
