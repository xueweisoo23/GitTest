import React, {Component, PropTypes} from 'react';
import {VerticalLayout,connectCdtDataComponent} from 'ssc-cdt3';
import FileUpload from '../components/FileUpload';
import {Button,FormControl,ControlLabel,FormGroup,Form,OverlayTrigger, Popover,Col} from 'react-bootstrap';
import VirtualizedSelect from 'react-virtualized-select';
import * as _sutils from '../sharedutils';
import ModalWindow from '../components/ModalWindow';
import { connect } from 'react-redux';
import * as _actionCreators from '../redux/ActionCreators'; 
import { bindActionCreators } from 'redux';
import ClientSelectionHeader from '../components/ClientSelectionHeader';
import * as _service from '../service';


const UPLOAD_FILE = {
	fileTypes:['.csv','.xls','.zip','.xlsx','.pdf'],
	maxFilesAllowed:5,
	templateFileId:'',
};

function mapStateToProps(state) {
  return {
		  showHelpModalWindow : (state.modalWindow.HELP_WINDOW?state.modalWindow.HELP_WINDOW:false),
	 showFileUploadModalWindow : (state.modalWindow.FILE_UPLOAD?state.modalWindow.FILE_UPLOAD:false),
   selectedClient:state.clients.selectedClient,
   isClientSelectionChanged:state.clients.isClientSelectionChanged,
	  helpData: state.help.helpData
  }
}

@connect(mapStateToProps, function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
})
@connectCdtDataComponent('fileDefinition',553840003)
export default class ProcessFileUploadContainer extends Component {

	static propTypes = {
		fileDefinition: PropTypes.object,
    	  fileDefinitionActions: PropTypes.object

	}

		constructor(props)
	{
		super(props);
		this.state = {fileID:'',fileContent:undefined};
	}

	componentDidMount() {
		const {fileDefinition: {data}, fileDefinitionActions} = this.props;
		const clientId = _sutils.getSelectedClientId();
		fileDefinitionActions.loadList({CLIENT_ID:clientId});
	
	}

	 componentWillReceiveProps(props) {
    if(this.props.selectedClient.CODE_VALUE !== props.selectedClient.CODE_VALUE && props.isClientSelectionChanged)
    		this.props.fileDefinitionActions.loadList({CLIENT_ID:props.selectedClient.CODE_VALUE});
  }
	
	 componentWillMount() {

		   _sutils.doCheckforEntitlement(this,true)
		  }

	 showHelpWindow=()=>{
    let {helpData} = this.props;
    helpData.map((obj)=>{
      if(obj.HELP_DEF_ID =="FILE_UPLOAD"){
          this.setState({fileContent:{__html:obj.FILE_CONTENT}});
      }
    });
    this.props.actions.showModalWindow('HELP_WINDOW');
  }
	uploadFileCallback=(filename,isSuccess,message)=> {
		console.log('uploadFileCallback=>filename:'+filename+':isSuccess:'+isSuccess+':message:'+message);
    if(isSuccess)
      this.props.fileDefinitionActions.success('Success', 'File processed successfully. ');
    else 
      this.props.fileDefinitionActions.error('Error', message);
	}
	  
  changeFileID =(val) => {
	  this.setState({'fileID':val}); 
  }
	modalClosedCallback = (btnType,id)=> {   
		console.log('id:'+id+':btnType:'+btnType);
	 }
	
	render() {
		console.log('render inside FileUploadContainer..........');
		const FILE_UPLOAD= <FileUpload fileUploadCallback={this.uploadFileCallback.bind(this)} callType={'TRANSLATION_UPLOAD'} paramObject={{PARAM1:this.state.fileID}} fileUploadConfig={UPLOAD_FILE} />
		 let HELP_WINDOW = <ModalWindow id={'HELP_WINDOW'} modalHeader={'Help'} buttons={[]} showModalWindow = {this.props.showHelpModalWindow}
                      modalCloseCallback={this.modalClosedCallback}> 
										<VerticalLayout flex='flex' style={{width: '100%'}}>
                       <span dangerouslySetInnerHTML={this.state.fileContent}></span>
                    </VerticalLayout> 
						   </ModalWindow>;
		let paramObj = {PARAM1:'SAmpleFile'}
		const {fileDefinition:{data,loading}}=this.props;
        console.log('File upload data for dropdwon:  '+data);
		return(
			
				<VerticalLayout flex="flex" style={{width: '100%'}}>
				        <ClientSelectionHeader/>

				<h3 > <strong>Process File Upload</strong><strong className =' fa fa-question-circle' style={{ color: '#286090', fontSize: 24, marginLeft: 10,cursor:'pointer' }}
        onClick = {this.showHelpWindow.bind(this)} ></strong></h3>
				<br/>				 
			
		<Form className='form-horizontal'>
		<FormGroup bsSize="small">
			<label>{'File Definition'}&nbsp;&nbsp;</label>
			<FormControl style={{width:'45%'}} value={this.state.fileID} componentClass="select" 
				onChange={(e) => this.changeFileID(e.target.value)}>
			<option style={{fontSize: '14px'}} value="">--Select--</option>
	         {(()=>{
	           if(data){
	             return data.map((x)=>{
	               return (
	                 <option style={{fontSize: '14px'}} value={x.FILE_DEF_ID}>{x.FILE_DEF_ID}</option>
	               );
	             });
	           }
	         })()}
			</FormControl>
		</FormGroup>
		<FormGroup bsSize="small">
		{undefined!=this.state.fileID && ''!=this.state.fileID && FILE_UPLOAD}
		</FormGroup>
		  </Form> 
			 {HELP_WINDOW}
			</VerticalLayout>	
		); 
	}
}