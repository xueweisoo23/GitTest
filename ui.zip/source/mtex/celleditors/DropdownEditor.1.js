import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {DropdownList} from 'react-widgets';
import {connectCdtDataComponent} from 'ssc-cdt3';
import * as _service from '../service'
import {OverlayTrigger, Popover} from 'react-bootstrap';

@connectCdtDataComponent('appDetails',553840008)
export class DropdownEditor extends Component { // Refactor later to generic component and inherit for specific functions
  static propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    col: PropTypes.object,
    row: PropTypes.object,
    bottomOffset: PropTypes.number,
    rowHeight: PropTypes.number,
    appDetails: PropTypes.object,
	  appDetailsActions: PropTypes.object,
  }

  constructor(props) {
    super(props);
    const {value} = props;
    this.state = {value};
  }

  onChange = (val) => {

    if (this.props.onChange(val, this.props.col)) {
      if(this.props.col.dataKey==='SENDER_APP_NM')
        this.props.onChange('true', {dataKey: 'IS_SENDER_APP_UPDATED'});
      else if(this.props.col.dataKey==='RECIEVER_APP_NM')
        this.props.onChange('true', {dataKey: 'IS_RECIEVER_APP_UPDATED'});

      this.setState({value: val});
    }
  }
   componentDidMount() {
     _service.makeCallWithHandlers(this.props.appDetailsActions,_service.CALL_TYPE_LOADLIST,{CALL_TYPE:'APP_DETAILS'},null,null,undefined,this.props) 
  }

  render() {
    const {col,error,appDetails,row, bottomOffset, rowHeight} = this.props;
    const {value} = this.state;
    const hover = error ? <Popover id={`${col.dataKey}_error`}>{error}</Popover> : <div />;
    return (
       <OverlayTrigger
        key={col.dataKey} overlay={hover} placement='top'
        trigger={['hover', 'focus']}>
         <DropdownList data={appDetails.data} value={value}
            style={{height: rowHeight- 2, width: '100%'}}
            dropUp={bottomOffset < 230}
            onChange={(val) => this.onChange(val.CODE_VALUE)}
            valueField='CODE_VALUE' textField='LABEL' />
      </OverlayTrigger>
      
    );
  }
}
