import {getCdtRegistryConnect, getRegistryDataReducer} from 'ssc-cdt3';

/**
 *  These constants are the top-level redux state properties
 */
const CDT_DATAGRID_COLUMNS = 'CDT_DATAGRID_COLUMNS';

/*
 * Transform function to massage the returned data
 * from the columns service into column objects
 * usable by the DataGrid. This is passed as the 3rd
 * argument to getCdtRegistryConnect()
 */
const getColumns = (rawColumns = []) => {
  //console.log("inside getColumns ***************"+JSON.stringify(rawColumns));
  var ret =  rawColumns.map(col => {
	  let width  = (col.COLUMN_WIDTH===undefined || col.COLUMN_WIDTH==null || col.COLUMN_WIDTH=='')?100:col.COLUMN_WIDTH;
    return {
      id: col.COLUMN,
      dataKey: col.COLUMN,
      label: col.LABEL,
      width: +(width*1.38),
      dataType: getConvertedDataType(col.DATATYPE),
      isKey: false,
      hidden:(col.DISPLAY_FLAG=='N' || col.DISPLAY_FLAG=='n')?true:false,
      stgFldName: col.STG_FIELD_NAME,
      actionFldName: col.ACTION_FIELD_NAME,
      sort: (col.DISPLAY_FLAG=='N' || col.DISPLAY_FLAG=='n')?false:true,
      filter: (col.DISPLAY_FLAG=='N' || col.DISPLAY_FLAG=='n')?false:true,
      locked: (col.DISPLAY_FLAG=='N' || col.DISPLAY_FLAG=='n')?true:false,
      fixed: (col.FREEZE_FLG=='Y' || col.FREEZE_FLG=='y')?true:false,
      decoratorType: col.DECORATE_TYPE,
      jumplinkUrl: col.JUMPLINK_URL,
    };
  });
  console.log(ret);
  return ret;
};

const getConvertedDataType = (sType) => {
  var uType = 'string'
  if(sType=='STRING')
    uType='string';
  else if(sType=='INTEGER' || sType=='FLOAT'  || sType=='DOUBLE'  || sType=='BIGDECIMAL'  )
    uType='string';
  else if(sType=='DATE' )
    uType='string';
  else if(sType=='TIMESTAMP' )
    uType='string';

  return uType;
}

/**
 * This object contains the reducers needed to process the
 * service calls for the various registries we set up. Import this
 * into your index.js entry point and pass it in the reducers prop of CdtApp.
 */
export const registryReducers = {
  CDT_DATAGRID_COLUMNS: getRegistryDataReducer(CDT_DATAGRID_COLUMNS)
};

/**
 * Now we export connect* functions for each of the registries.
 * These will be used by our dynamic grid containers to inject
 * the configuration props.
 */
export const connectCdtColumnRegistry =
  getCdtRegistryConnect(CDT_DATAGRID_COLUMNS, 'columns', getColumns, 913600016, 'id');


