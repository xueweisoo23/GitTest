var express = require('express');
var fs = require('fs');
var router = express.Router();
var app = express();

var PROD_ENV = (process.env.NODE_ENV === 'production');
var ctxRoot = process.argv[2];
if (!ctxRoot) {
  console.error('Error!');
  console.error('Must pass context root as second arg: node server.js <MyContextRoot>');
  process.exit();
}
process.env.CONTEXT_ROOT = ctxRoot;

var baseURL = `http://localhost:8080/${ctxRoot}/`;

var url = require('url');
function getOptions(proxyUrl) {
  var options = url.parse(proxyUrl);
  options.cookieRewrite = true;
  return options;
}

if (PROD_ENV) {
  app.use('/dist', express.static('dist'));
} else {
  var webpack = require('webpack');
  var config = require('./webpack.config');
  var compiler = webpack(config);

  app.use(require('webpack-dev-middleware')(compiler, {
    noInfo: true,
    publicPath: config.output.publicPath
  }));

  app.use(require('webpack-hot-middleware')(compiler));
}

var proxy = require('proxy-middleware');
router.use('/', proxy(getOptions(baseURL)));
router.use('/auth', proxy(getOptions(`${baseURL}auth`)));
router.use('/json', proxy(getOptions(`${baseURL}json`)));

app.get('/', (req, res) => {
  res.redirect(`http://localhost:8088/${ctxRoot}?src=express`);
});


// quick and dirty REST route

function readJSONFile(filename, callback) {
  fs.readFile(filename, (err, data) => {
    if (err) {
      callback(err);
      return;
    }
    try {
      callback(null, JSON.parse(data));
    } catch (exception) {
      callback(exception);
    }
  });
}

app.get('/employee', (req, res) => {
  res.header('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.header('Pragma', 'no-cache');
  res.header('Expires', 0);
  readJSONFile('employee.json', (err, data) => {
    if (err) {
      console.error(err);
    }
    // add a delay
    setTimeout(() => {
      res.json(data);
    }, 1500);
  });
});

app.use(`/${ctxRoot}/`, router);

app.listen(8088);
console.log('Navigate to http://localhost:8088');
console.log('in your browser for development.\n');
console.log('Make sure that your tomcat server is started on port 8080.\n');
console.log('Service calls will be proxied to');
console.log(`http://localhost:8080/${ctxRoot}`);

