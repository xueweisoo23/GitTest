import * as _actions from './ActionCreators'

/**
 *   @author p530579
 * 
 * Reducer to subscribe on the event bus. 
 * Make sure that to group  reducer based on the functionality and categorization
 * Also the reducer need to be mentioned on the index app
 * 
 **/
 

const modalWindowInitState ={modalWindow: {}};
const messageDialogInitState ={showMessageDialog: false,messageDialogParams:{}};
const entitledClientsInitState = {entitledClients:[],selectedClient:{},isClientSelectionChanged:false};
const helpDataInitState = {helpData: []};

export function helpDataReducer(state = helpDataInitState, action) { 
  switch (action.type) {
    case _actions.LOAD_HELP_DATA:
      return (todo => {
        return Object.assign({}, todo, {helpData:action.helpData});   
      })(state);
      break;
   
    default:
      return state;
  }
}


export function entitledClientsReducer(state = entitledClientsInitState, action) { 
  switch (action.type) {
    case _actions.RELOAD_CLIENT_DROPDOWN:
      return (todo => {
        return Object.assign({}, todo, {entitledClients:action.entitledClients});   
      })(state);
      break;
    case _actions.CLIENT_DROPDOWN_VALUE_CHANGE:
      return (todo => {
        return Object.assign({}, todo, {isClientSelectionChanged:true,selectedClient:action.selectedClient});   
      })(state);
      break;
     case _actions.POST_CLIENT_CHANGE_COMPLETED:
      return (todo => {
        return Object.assign({}, todo, {isClientSelectionChanged:false});    
      })(state);
      break;
    default:
      return state;
  }
}

export function messageDialogReducer(state = messageDialogInitState, action) {
  switch (action.type) {
    case _actions.SHOW_MESSAGE_DIALOG:
      return (todo => {
        return Object.assign({}, todo, {showMessageDialog:true,messageDialogParams:action.messageDialogParams}); 
      })(state);
      break;
    case _actions.HIDE_MESSAGE_DIALOG:
      return (todo => {
        return Object.assign({}, todo, {showMessageDialog:false}); 
      })(state);
      break;
    default:
      return state;
  }
}


export function modalWindowReducer(state = modalWindowInitState, action) {
  let modalId = action.modalId;
  let obj ={};
  switch (action.type) {
    case _actions.SHOW_MODAL_WINDOW:
      return (todo => {
        obj[modalId]=true;
        return Object.assign({}, todo, obj); 
      })(state);
      break;
    case _actions.HIDE_MODAL_WINDOW:
      return (todo => {
        obj[modalId]=false;
        return Object.assign({}, todo, obj);  
      })(state);
      break;
    default:
      return state;
  }
}


