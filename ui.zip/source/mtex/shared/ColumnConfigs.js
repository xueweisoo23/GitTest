import {AppNameEditor} 			from '../celleditors/AppNameEditor';
import TextboxEditor			from '../celleditors/TextboxEditor';
import {DelimiterEditor} 		from '../celleditors/DelimiterEditor';
import {FileTypeEditor} 		from '../celleditors/FileTypeEditor';
import {ClientEditor} 			from '../celleditors/ClientEditor';
import {FileMappingEditor} 		from '../celleditors/FileMappingEditor';
import {DeliveryTypeEditor} 	from '../celleditors/DeliveryTypeEditor';
import {RuleMappingEditor} 		from '../celleditors/RuleMappingEditor';
import {YesNoEditor} 			from '../celleditors/YesNoEditor';
import {RuleTypeEditor} 		from '../celleditors/RuleTypeEditor';
import {DataTypeEditor} 		from '../celleditors/DataTypeEditor';
import {RulePriorityEditor} 	from '../celleditors/RulePriorityEditor';
import {OutputFileTypeEditor} 	from '../celleditors/OutputFileTypeEditor';
import {OutputDelimiterEditor}  from '../celleditors/OutputDelimiterEditor';
import {RuleConditionEditor}    from '../celleditors/RuleConditionEditor';
import {XmlTypeEditor}          from  '../celleditors/XmlTypeEditor';
import {AlignmentEditor}          from  '../celleditors/AlignmentEditor';
import {TemplateIdEditor}       from  '../celleditors/TemplateIdEditor';
import {MandatoryYesNoEditor}   from '../celleditors/MandatoryYesNoEditor';

export const FILE_DEF_COLUMNS = 
	 [
	  /*{             	 
  dataKey: 'CLIENT_NM',
  label: '*Client',
  width: 150,
  dataType: 'string',
  edit: true,
  editor: ClientEditor,
  maxLength:100
}, {
  dataKey: 'CLIENT_ID',
  label: 'Client ID',
  dataType: 'string',
  hidden: true,
},*/
 {
  dataKey: 'FILE_DEF_ID',
  label: '*File Definition ID',
  width: 150,
  dataType: 'string',
  edit: true,
  editor: TextboxEditor,
  maxLength:100,
  disableOnEdit: true
},{
  dataKey: 'SENDER_APP_NM', 
  label: '*Sender App',
  width: 180,
  dataType: 'string',
  edit: true,
  editor: AppNameEditor
},{
  dataKey: 'RECIEVER_APP_NM',
  label: '*Receiver App',
  width: 180,
  dataType: 'string',
  edit: true,
  editor: AppNameEditor
},{
  dataKey: 'FILE_MAPPING_ID',
  label: '*File Mapping Id',
  hidden: true,
  dataType: 'string',
},{
  dataKey: 'FILE_PATTERN_TXT',
  label: '*File Pattern',
  width: 250,
  dataType: 'string',
  edit: true,
  editor: TextboxEditor,
  maxLength:150    
},{
  dataKey: 'FILE_TYPE_TXT',
  label: '*File Type',
  width: 150,
  dataType: 'string',
  edit: true,
  editor: FileTypeEditor
},{
  dataKey: 'DELIMITER_TXT',
  label: '*Delimiter',
  width: 120,
  dataType: 'string',
  edit: true,
  editor: DelimiterEditor
},{
  dataKey: 'HEADER_KEYWORD_TXT',
  label: 'Header keyword',
  width: 120,
  dataType: 'string',
  edit: true,
  maxLength:450,
  editor: TextboxEditor
},{
  dataKey: 'OUTPUT_FILE_NM',
  label: 'Output file name',
  width: 120,
  dataType: 'string',
  edit: true,
  maxLength:30,
  editor: TextboxEditor
},
{
  dataKey: 'OUTPUT_FILE_TYPE_TXT',
  label: '*Output File Type',
  width: 150,
  dataType: 'string',
  edit: true,
  editor: OutputFileTypeEditor
},
{
	  dataKey: 'OUTPUT_FILE_TYPE_CD',
	  dataType: 'string',
	  hidden: true,
	  label: 'Output File Type Cd(int)'
	},
{
  dataKey: 'OUTPUT_DELIMITER_TXT',
  label: '*Output Delimiter',
  width: 120,
  dataType: 'string',
  edit: true,
  editor: OutputDelimiterEditor
},
{
  dataKey: 'OUTPUT_DELIMITER',
  label: '*Output Delimiter',
  hidden: true
},
{
  dataKey: 'DELIVERY_PREF_NM',
  label: 'Delivery Type',
  width: 170,
  dataType: 'string',
  edit: true,
  editor: DeliveryTypeEditor
},{
  dataKey: 'IS_DELIMITER_UPDATED',
  dataType: 'string',
  hidden: true
},{
  dataKey: 'POLL_MS_QTY',
  label: 'Poll Qty',
  width: 120,
  dataType: 'number',
  edit: true,
  hidden: true,
  editor: TextboxEditor
},{
  dataKey: 'COMP_WAIT_TIME_QTY',
  label: 'Comp Wait Time',
  width: 120,
  dataType: 'number',
  edit: true,
  hidden: true,
  editor: TextboxEditor
},{
  dataKey: 'MAX_RECORD_QTY',
  label: 'Max Record Qty',
  width:120,
  dataType: 'number',
  edit: true,
  hidden: true,
  editor: TextboxEditor
},{
  dataKey: 'CORE_POOL_QTY',
  label: 'Core Pool Qty',
  width: 120,
  dataType: 'number',
  edit: true,
  hidden: true,
  editor: TextboxEditor
},{
  dataKey: 'MAX_POOL_QTY',
  label: 'Max Pool Qty',
  width: 120,
  dataType: 'number',
  edit: true,
  hidden: true,
  editor: TextboxEditor
},{
  dataKey: 'QUEUE_SIZE_QTY',
  label: 'Queue Size Qty',
  width: 120,
  dataType: 'number',
  edit: true,
  hidden: true,
  editor: TextboxEditor
},{
  dataKey: 'KEY_ID',
  dataType: 'string',
  edit: false,
  hidden: true
},{
  dataKey: 'RECIEVER_APP_CD', 
  dataType: 'string',
  hidden: true
},{
  dataKey: 'IS_SENDER_APP_UPDATED', 
  dataType: 'string',
  hidden: true
},{
  dataKey: 'IS_RECIEVER_APP_UPDATED',
  dataType: 'string', 
  hidden: true
},{
  dataKey: 'DELIVERY_PREF_CD',
  dataType: 'string',
  hidden: true
},{
  dataKey: 'IS_CLIENT_UPDATED',
  label: 'Client Updated',
  dataType: 'string',
  hidden: true
},{
  dataKey: 'SENDER_APP_CD', 
  hidden: true,
  dataType: 'string',
  label: 'Sender App Cd'
},{
  dataKey: 'FILE_TYPE_CD',
  dataType: 'string',
  hidden: true,
  label: 'File Type Cd(int)'
},{
  dataKey: 'IS_FILE_TYPE_UPDATED',
  dataType: 'string',
  label: 'File Type Updated',
  hidden: true
},{
  dataKey: 'DELIMITER_CD',
  dataType: 'string',
  hidden: true
},{
  dataKey: 'IS_DELIVERY_PREF_UPDATED',
  dataType: 'string',
  hidden: true
},
{
  dataKey:'IS_OUTPUT_FILE_TYPE_UPDATED',
  dataType: 'string',
  hidden: true
},
{
  dataKey:'IS_OUTPUT_DELIMITER_UPDATED',
  dataType: 'string',
  hidden: true
},
{
  dataKey:'XML_TYPE_CD',
  dataType: 'string',
  label: 'Delivery Mode',
  width: 120,
  edit: true,
  editor: XmlTypeEditor
}

	
];

export const RULE_CONFIG_COLUMNS_XML = [
	{
		  dataKey: 'SEQUENCE_NUM',
		  label: 'Seq #',
		  width: 100,
		  dataType: 'number',
		  edit: true,
		  editor: TextboxEditor
		},
	{
	  dataKey: 'COL_NM',
	  label: 'Column Name',
	  width: 150,
	  dataType: 'string',
	  edit: true,
	  hidden: true,
	  maxLength: 400,
	  editor: TextboxEditor
	},
	{
		  dataKey: 'OUTPUT_XML_TAG',
		  label: 'Output XML Tag',
		  width: 300,
		  dataType: 'string',
		  edit: true,
		  maxLength: 300,
		  editor: TextboxEditor
		},
	{
	  dataKey: 'DATA_TYPE_CD',
	  label: 'Data Type',
	  width: 120,
	  dataType: 'string',
	  edit: true,
	  editor: DataTypeEditor
	},{
	  dataKey: 'MAX_CHAR_QTY',
	  label: 'Max Character',
	  width: 120,
	  dataType: 'number',
	  edit: true,
	  editor: TextboxEditor
	},
	{
	  dataKey: 'INPUT_COL_NUM',
	  label: 'Input Column #',
	  width: 120,
	  dataType: 'string',
	  edit: true,
	  maxLength:50,
	  editor: TextboxEditor
	},{
	  dataKey: 'RULE_TYPE_NM',
	  label: 'Rule Type',
	  width:180,
	  dataType: 'string',
	  edit: true,
	  editor: RuleTypeEditor
	},{
	  dataKey: 'MAPPING_RULE_ID',
	  label: 'Mapping Rule ID',
	  width: 180,
	  dataType: 'string',
	  edit: true,
	  editor: RuleMappingEditor
	},{
	  dataKey: 'RULE_TXT',
	  label: 'Rule Criteria',
	  width: 250,
	  dataType: 'string',
	  edit: true,
	  maxLength:100,
	  editor: TextboxEditor
	},{
	  dataKey: 'IS_MANDATORY_NM',
	  label: 'Is Mandatory?',
	  width: 150,
	  dataType: 'string',
	  edit: true,
	  editor: MandatoryYesNoEditor
	},{
	  dataKey: 'ALLOW_EMPTY_NM',
	  label: 'Skip Empty?',
	  width: 150,
	  dataType: 'string',
	  edit: true,
	  hidden: true,
	  editor: YesNoEditor
	},
	{
	  dataKey: 'TRIM_VALUES_NM',
	  label: 'Trim Values',
	  width: 150,
	  dataType: 'string',
	  edit: true,
	  editor: YesNoEditor
	},
	{
	  dataKey: 'EXCEPTION_TXT',
	  label: 'Exception List',
	  width: 250,
	  dataType: 'string',
	  edit: true,
	  hidden: true,
	  maxLength:150,
	  editor: TextboxEditor
	},
	{
	  dataKey: 'TRIM_VALUES',
	  dataType: 'string',
	  hidden: true
	},
	{
	  dataKey: 'IS_TRIM_VALUES_CHANGED',
	  dataType: 'string',
	   hidden: true
	},
	{
	  dataKey: 'IS_MANDATORY',
	  dataType: 'string',
	  hidden: true
	},{
	  dataKey: 'IS_MANDATORY_CHANGED',
	  dataType: 'string',
	   hidden: true
	},{
	  dataKey: 'ALLOW_EMPTY_CD',
	  dataType: 'string',
	  hidden: true
	},{
	  dataKey: 'IS_ALLOW_EMPTY_CHANGED',
	  dataType: 'string',
	  hidden: true
	},{
	  dataKey: 'FILE_MAPPING_ID',
	  label: 'File Mapping ID',
	  width: 120,
	  dataType: 'string',
	  hidden: true,
	  edit: true
	},{
	  dataKey: 'INPUT_COL_NM',
	  label: 'Input Column Name',
	  width: 120,
	  dataType: 'string',
	  edit: true,
	  hidden: true
	},{
	  dataKey: 'INPUT_COL_KY',
	  label: 'Input Column Key',
	  width: 120,
	  dataType: 'string',
	  edit: true,
	  hidden: true
	},{
	  dataKey: 'RULE_TYPE_CD',
	  dataType: 'string',
	  hidden: true
	},{
	  dataKey: 'IS_RULE_TYPE_CHANGED',
	  dataType: 'string',
	  hidden: true
	},{
	  dataKey: 'KEY_ID',
	  label: 'KEY_ID',
	  width: 120,
	  dataType: 'string',
	  hidden: true
	}
	 ];



export const RULE_CONFIG_COLUMNS = [
 {
  dataKey: 'SEQUENCE_NUM',
  label: 'Seq #',
  width: 100,
  dataType: 'number',
  edit: true,
  editor: TextboxEditor
},{
  dataKey: 'COL_NM',
  label: 'Column Name',
  width: 200,
  dataType: 'string',
  edit: true,
  maxLength:50,
  editor: TextboxEditor
},{
  dataKey: 'DATA_TYPE_CD',
  label: 'Data Type',
  width: 120,
  dataType: 'string',
  edit: true,
  editor: DataTypeEditor
},{
  dataKey: 'MAX_CHAR_QTY',
  label: 'Max Character',
  width: 120,
  dataType: 'number',
  edit: true,
  editor: TextboxEditor
},{
  dataKey: 'INPUT_COL_NUM',
  label: 'Input Column #',
  width: 120,
  dataType: 'string',
  edit: true,
  maxLength:50,
  editor: TextboxEditor
},{
  dataKey: 'RULE_TYPE_NM',
  label: 'Rule Type',
  width:180,
  dataType: 'string',
  edit: true,
  editor: RuleTypeEditor
},{
  dataKey: 'MAPPING_RULE_ID',
  label: 'Mapping Rule ID',
  width: 180,
  dataType: 'string',
  edit: true,
  editor: RuleMappingEditor
},{
  dataKey: 'RULE_TXT',
  label: 'Rule Criteria',
  width: 250,
  dataType: 'string',
  edit: true,
  maxLength:100,
  editor: TextboxEditor
},{
  dataKey: 'IS_MANDATORY_NM',
  label: 'Is Mandatory?',
  width: 150,
  dataType: 'string',
  edit: true,
  editor: MandatoryYesNoEditor
},{
  dataKey: 'ALLOW_EMPTY_NM',
  label: 'Skip Empty?',
  width: 150,
  dataType: 'string',
  edit: true,
  hidden: true,
  editor: YesNoEditor
},
{
  dataKey: 'TRIM_VALUES_NM',
  label: 'Trim Values',
  width: 150,
  dataType: 'string',
  edit: true,
  editor: YesNoEditor
},
{
  dataKey: 'EXCEPTION_TXT',
  label: 'Exception List',
  width: 250,
  dataType: 'string',
  edit: true,
  hidden: true,
  maxLength:150,
  editor: TextboxEditor
},
{
  dataKey: 'TRIM_VALUES',
  dataType: 'string',
  hidden: true
},
{
  dataKey: 'IS_TRIM_VALUES_CHANGED',
  dataType: 'string',
   hidden: true
},
{
  dataKey: 'IS_MANDATORY',
  dataType: 'string',
  hidden: true
},{
  dataKey: 'IS_MANDATORY_CHANGED',
  dataType: 'string',
   hidden: true
},{
  dataKey: 'ALLOW_EMPTY_CD',
  dataType: 'string',
  hidden: true
},{
  dataKey: 'IS_ALLOW_EMPTY_CHANGED',
  dataType: 'string',
  hidden: true
},{
  dataKey: 'FILE_MAPPING_ID',
  label: 'File Mapping ID',
  width: 120,
  dataType: 'string',
  hidden: true,
  edit: true
},{
  dataKey: 'INPUT_COL_NM',
  label: 'Input Column Name',
  width: 120,
  dataType: 'string',
  edit: true,
  hidden: true
},{
  dataKey: 'INPUT_COL_KY',
  label: 'Input Column Key',
  width: 120,
  dataType: 'string',
  edit: true,
  hidden: true
},{
  dataKey: 'RULE_TYPE_CD',
  dataType: 'string',
  hidden: true
},{
  dataKey: 'IS_RULE_TYPE_CHANGED',
  dataType: 'string',
  hidden: true
},{
  dataKey: 'KEY_ID',
  label: 'KEY_ID',
  width: 120,
  dataType: 'string',
  hidden: true
}
 ];


export const MAPPING_DATA_COLUMNS = [{
  dataKey: 'KEY_ID',
  label: 'Id',
  width: 250,
  dataType: 'string',
  hidden: true
},{
  dataKey: 'MAPPING_RULE_ID',
  label: 'Mapping Rule',
  width: 200,
  dataType: 'string',
  disableOnEdit: true,
  edit: true,
  maxLength:30,
  editor: TextboxEditor
}, {
  dataKey: 'INPUT_COL1_TXT',
  label: 'Input Column1',
  width: 200,
  dataType: 'string',
  edit: true,
  maxLength:1500,
  editor: TextboxEditor
}, {
  dataKey: 'INPUT_COL2_TXT',
  label: 'Input Column2',
  width: 200,
  dataType: 'string',
  edit: true,
  maxLength:1500,
  editor: TextboxEditor
}, {
  dataKey: 'INPUT_COL3_TXT',
  label: 'Input Column3',
  width: 200,
  dataType: 'string',
  edit: true,
  maxLength:1500,
  editor: TextboxEditor
}, {
  dataKey: 'INPUT_COL4_TXT',
  label: 'Input Column4',
  width: 200,
  dataType: 'string',
  edit: true,
  maxLength:1500,
  editor: TextboxEditor
}, {
  dataKey: 'OUTPUT_COL_TXT',
  label: 'Output',
  width: 200,
  dataType: 'string',
  edit: true,
  maxLength:1500,
  editor: TextboxEditor
}, {
  dataKey: 'FILE_MAPPING_ID',
  label: 'File Mapping',
  width: 200,
  dataType: 'string',
	edit: true,
	hidden:true
}];

export const EXCEPTION_COLUMNS = [{
  dataKey: 'FILE_ID',
  label: 'File ID',
  width: 250,
  dataType: 'string',
} , {
  dataKey: 'MAPPING_RULE_ID',
  label: 'Mapped Rule ID',
  width: 350,
  dataType: 'string',
},{
  dataKey: 'EXCEPTION_TYPE',
  label: 'Error Type',
  width: 300,
  dataType: 'string',
},{
  dataKey: 'EXCEPTION_CNT',
  label: 'Error Count',
  width: 200,
  dataType: 'number',
},{
  dataKey: 'KEY_ID',
  label: 'UID',
  width: 120,
  dataType: 'string',
  hidden: true
	}];


export const FILE_STATUS_COLUMNS = [{
 dataKey: 'FILE_ID',
  label: 'File Id',
  width: 100,
  dataType: 'string',
},
{
 dataKey: 'PARENT_FILE_ID',
 label: 'Parent File Id',
 width: 100,
 dataType: 'string',
},
{
 dataKey: 'FILE_NM',
  label: 'File Name',
  width: 150,
  dataType: 'string',
},{
 dataKey: 'FILE_PATH_TXT',
  label: 'File Path',
  width: 250,
  dataType: 'string',
},{
 dataKey: 'FILE_TYPE_CD',
  label: 'File type',
  width: 75,
  dataType: 'string',
},{
 dataKey: 'STATUS_CD',
  label: 'Status',
  width: 100,
  dataType: 'string',
},{
 dataKey: 'RECORD_NUM',
  label: '# of recs',
  width: 100,
  dataType: 'number',
},{
 dataKey: 'TIME_TAKEN_QTY',
  label: 'Process Time[s]',
  width: 100,
  dataType: 'number',
},{
 dataKey: 'FILE_DEF_ID',
  label: 'File Defn ID',
  width: 150,
  dataType: 'string',
},{
 dataKey: 'PROCESSED_BY_NM',
  label: 'Processed VM',
  width: 150,
  dataType: 'string',
},{
 dataKey: 'SUCCESS_RECORD_NUM',
  label: 'Success Count',
  width: 100,
  dataType: 'number',
},{
 dataKey: 'ERROR_RECORD_NUM',
  label: 'Error Count',
  width: 100,
  dataType: 'number',
},{
 dataKey: 'UPD_TS',
  label: 'Processed At',
  width: 200,
  dataType: 'number',
},{
  dataKey: 'KEY_ID',
  dataType: 'string',
  edit: false,
  hidden: true,
	},
	{
		dataKey: 'INPUT_FILE_LOAD_ID',
		  dataType: 'string',
		  edit: false,
		  hidden: true,
	},
	{
		dataKey: 'TRANSFORMED_FILE_LOAD_ID',
		dataType: 'string',
		edit: false,
		 hidden: true,
	},
	{
		dataKey: 'OUTPUT_FILE_NM',
		dataType: 'string',
		edit: false,
		hidden: true,
	},
	{
		dataKey: 'ERR_FILE_LOAD_ID',
		dataType:'string',
		edit: false,
		hidden: true,
	}
	
  ];

export const RULE_MAPPING_CONFIG_COLUMNS = [
	 {
	  dataKey: 'EXEC_SEQUENCE',
	  label: 'Seq #',
	  width: 70,
	  disableOnEdit: true
	},
	{
	  dataKey: 'FILE_MAPPING_ID',
	  label: 'Rule Mapping',
	  width: 250,
	  dataType: 'string'
	},
	{
	  dataKey: 'EXEC_PARAMS',
	  label: 'Column',
	  width: 100,
	  dataType: 'string',
	  edit: true,
	  editor: TextboxEditor
	},
	{
	  dataKey: 'EXEC_CONDITION_TXT',
	  label: 'Condition',
	  width: 150,
	  dataType: 'string',
	  edit: true,
	  editor: RuleConditionEditor
	},
	{
	  dataKey: 'EXEC_CONDITION',
	  label: 'Condition',
	  hidden: true
	},
	{
	  dataKey: 'IS_RULE_CONDITION_UPDATED',
	  dataType: 'string',
	  hidden: true
	},
	
	{
	  dataKey: 'EXEC_VALUE',
	  label: 'Value',
	  width: 100,
	  dataType: 'string',
	  edit: true,
	  editor: TextboxEditor
	},
	{
	  dataKey: 'EXEC_LNK_PRIORITY',
	  label: 'Operator',
	  width: 100,
	  dataType: 'string',
	  edit: true,
	  editor: RulePriorityEditor
	},
	{
	  dataKey: 'KEY_ID',
	  dataType: 'string',
	  edit: false,
	  hidden: true
	}
	 ];