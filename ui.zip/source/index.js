import 'babel-polyfill';
import React from 'react';
import ReactDOM from 'react-dom';
import {CdtApp, CdtMainWrapper,CdtGlobalSideNav} from 'ssc-cdt3';
import './app.less';

import {registryReducers} from './registry';
import * as _reducers from './mtex/redux/Reducers';

import ProcessFileUploadContainer from './mtex/containers/ProcessFileUploadContainer';
import MappingDataContainer from './mtex/containers/MappingDataContainer';
import ExceptionContainer from './mtex/containers/ExceptionContainer';
import ApplicationSetup from './mtex/containers/ApplicationSetup';
import FileDefinitionContainer from './mtex/containers/FileDefinitionContainer';
import RuleConfigurationContainer from './mtex/containers/RuleConfigurationContainer';
import NoESFEntitlementsPage from './mtex/containers/NoESFEntitlementsPage';
import AppValidationContainer from './mtex/containers/AppValidationContainer';
import FileStatusContainer from './mtex/containers/FileStatusContainer';
import RuleMappingConfigContainer from './mtex/containers/RuleMappingConfigContainer';
import RuleConfigurationContainerNew from './mtex/containers/RuleConfigurationContainerNew';
import RuleConfigurationContainerHeader from './mtex/containers/RuleConfigurationContainerHeader';
import RuleConfigurationContainerFooter from './mtex/containers/RuleConfigurationContainerFooter';
import FileDownload from './mtex/FileDownload';



//this is for data written to the page on the server by the CdtReactIndexServlet
const initialState = window.CDT_SERVER_DATA;

const REDUCERS = {messageDialog: _reducers.messageDialogReducer,
                  modalWindow:_reducers.modalWindowReducer,CDT_DATAGRID_COLUMNS:registryReducers.CDT_DATAGRID_COLUMNS,
                  clients:_reducers.entitledClientsReducer, help:_reducers.helpDataReducer};


const routes = {
	name: 'Home',
  path: '/',
  component: CdtMainWrapper,
  indexRoute: { onEnter: (nextState, replace) => replace('/appvalidation') },
  childRoutes: [
   {
    component: CdtGlobalSideNav, 
	  childRoutes: [
        {
          component: AppValidationContainer,
          path: 'appvalidation'
        },
        { 
          component: ProcessFileUploadContainer,
          path: 'filedefupload'
        },
        { 
          component: MappingDataContainer,
          path: 'mappingdata'
        },
        { 
          component: FileDefinitionContainer,
          path: 'filedef'
        },
        { 
          component: RuleConfigurationContainer,
          path: 'ruleconfig'
        },
        { 
	        component: RuleConfigurationContainerNew,
	        path: 'ruleConfigNew'
        },
        {
        	component: RuleConfigurationContainerHeader,
	        path: 'ruleConfigHeader'
        },
        {
        	component: RuleConfigurationContainerFooter,
	        path: 'ruleConfigFooter'
        },
        { 
	        component: RuleMappingConfigContainer,
	        path: 'ruleMappingconfig'
        },
        { 
          component: ExceptionContainer,
          path: 'viewexception'
        },
        { 
            component: ApplicationSetup,
            path: 'appsetup'
        },
        {
          component: NoESFEntitlementsPage,
          path: 'noentitlement'
	      },
        {
          component: FileStatusContainer,
          path: 'filestatus'
	      },
	      {
	          component: FileDownload,
	          path: 'filedownload'
		      } 
      ]
      },
  ]
};
ReactDOM.render(
		<CdtApp
  initialState={initialState}
    routes={routes}
    title='' 
    reducers={REDUCERS}
		/>
    ,
  document.getElementById('app') 
);

