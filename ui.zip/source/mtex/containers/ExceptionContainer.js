import React, {Component,PropTypes} from 'react';
import {Button} from 'react-bootstrap';
import {DynamicDataGrid,HorizontalLayout,FixedPanel,FlexPanel,VerticalLayout,connectCdtDataComponent } from 'ssc-cdt3';
import { connect } from 'react-redux';
import * as _service from '../service';
import ModalWindow from '../components/ModalWindow';
import * as _actionCreators from '../redux/ActionCreators'; 
import { bindActionCreators } from 'redux';
import * as _sutils from '../sharedutils';
import MappingDataContainer from './MappingDataContainer';
import ClientSelectionHeader from '../components/ClientSelectionHeader';
import {EXCEPTION_COLUMNS} from '../shared/ColumnConfigs';
import { Link } from 'react-router';


function mapStateToProps(state) {
  return {
	 showFileUploadModalWindow : (state.modalWindow.MAP_DATA?state.modalWindow.MAP_DATA:false),
	 selectedClient:state.clients.selectedClient,
   isClientSelectionChanged:state.clients.isClientSelectionChanged,
  }
}

@connect(mapStateToProps, function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
})
@connectCdtDataComponent('exception',553840006) 
export default class ExceptionContainer extends Component {
  
  static contextTypes = {
		router: React.PropTypes.object.isRequired,
	}
  
  
  constructor(props) {
    super(props);
		this.state={fileId:undefined,selectedRow:{}};
  }

componentDidMount() {
    if(this.props.location && this.props.location.state && this.props.location.state.params 
        && this.props.location.state.params.fileId)  {
          const fileId = this.props.location.state.params.fileId;          
					const fileStatusFilter = this.props.location.state.params.fileStatusFilter;
          this.connectCallback(this.gridActions,{FILE_ID:fileId}); 
          this.setState({fileId,fileStatusFilter});  
      }
  }


  connectCallback = (gridActions,params) => {
    this.gridActions = gridActions;
    if(params && params.FILE_ID && params.FILE_ID.trim()!='')
        _service.makeCallWithHandlers(gridActions,_service.CALL_TYPE_LOADLIST,params,null,null,undefined,this.props) ; 
  }

  componentWillMount() {
   _sutils.doCheckforEntitlement(this,true);
  }

  componentWillReceiveProps(props) {
  
  }
  

modalClosedCallback = (btnType,id)=> {   
		console.log('id:'+id+':btnType:'+btnType);
		// this.props.actions.hideModalWindow('MAP_DATA');
	 }

 reprocess=()=>{
	   _service.makeCallWithHandlers(this.props.exceptionActions,_service.CALL_TYPE_UPDATE,{FILE_ID:this.state.fileId},this.reprocessSuccessHandler,_sutils.defaultErrorHandler.bind(this),undefined,this.props) ; 
 }

reprocessSuccessHandler =(ret,actions,spinJobId)=>{
   if (ret.error) 
        actions.error('Error', ret.payload._error || 'Error in reprocess');
	 else
	  		actions.success('Success', 'File marked for reprocess!');
	  
  }
	 showMappingData  = ()=> {
		this.props.actions.showModalWindow('MAP_DATA');
	 }
    goBack=()=>{
     	this.context.router.push({pathname: '/filestatus', state: {params:{filterInputs:this.state.fileStatusFilter,isBackMode:true}}});  
   }
   onRowClick=(row)=>{
    this.setState({selectedRow:row});
  }

  render() {
	const {selectedRow} = this.state;
  const BACK_BUTTON = <div style={{display: 'inline-block', float: 'left'}}>
        				<Button className='btn btn-primary btn-xs' onClick = {this.goBack.bind(this)}> {'<< Back'}</Button> </div> ;
  const enableMapData = selectedRow && selectedRow.MAPPING_RULE_ID && selectedRow.MAPPING_RULE_ID.trim()!=='' && selectedRow.EXCEPTION_TYPE==='MISSING_VALUE';
	const MAPPING_DATA = <ModalWindow className={'mapping-modal-class'} id={'MAP_DATA'} modalHeader={'Mapping data'} buttons={[]} showModalWindow = {this.props.showFileUploadModalWindow} modalCloseCallback={this.modalClosedCallback}> 
										<VerticalLayout flex='flex' style={{height:'500px'}}> 
                      <MappingDataContainer inputParams={{isChildMode:true,mappingRuleId:selectedRow.MAPPING_RULE_ID}}/>
                    </VerticalLayout> 
						   </ModalWindow>;
    return (

<HorizontalLayout>
 <ClientSelectionHeader disableDropDown={true}/>
       <VerticalLayout flex='flex' onKeyDown={this.onKeyDown}> 
       <FixedPanel style={{overflow: 'visible'}}>
			 <h3 style={{marginTop: 0,marginBottom: 0,width: 260}}> <strong>Manage Exceptions</strong></h3>
        {BACK_BUTTON}
			  <div style={{display: 'inline-block', float: 'right'}}>
              <Button className='btn btn-primary btn-xs' style={{marginRight: 8}} disabled ={!enableMapData} onClick={this.showMappingData}>Fix Mapping</Button>
							<Button className='btn btn-primary btn-xs' style={{marginRight: 8}} onClick={this.reprocess}>Reprocess</Button>
        </div>
     </FixedPanel>
     <FlexPanel>
      <DynamicDataGrid
		columns={EXCEPTION_COLUMNS}
        dataIdf={553840006}
        gridConnectCallback={this.connectCallback}
        componentId='exceptionGrid'
        keyFieldName='KEY_ID'			
				onRowClick={this.onRowClick}
				scale ={1}
				pageSize={50}
        excelExport
      	csvExport
      /> 
      </FlexPanel>
			</VerticalLayout>
		{MAPPING_DATA}
			</HorizontalLayout>

    );
  }
}



