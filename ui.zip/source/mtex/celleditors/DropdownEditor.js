import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {DropdownList} from 'react-widgets';
import {connectCdtDataComponent} from 'ssc-cdt3';
import * as _service from '../service'
import {OverlayTrigger, Popover} from 'react-bootstrap';

@connectCdtDataComponent('appDetails',553840008)
export class DropdownEditor extends Component { 
  static propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    col: PropTypes.object,
    row: PropTypes.object,
    bottomOffset: PropTypes.number,
    rowHeight: PropTypes.number,
    dropdownValues: PropTypes.object,	  // Make sure to pass on the DropdownIO object as value for this!!
  }

  constructor(props) {
    super(props);
    const {value} = props;
    this.state = {value};
  }

  
  onChange = (onChange,val) => {
       onChange(val)
      this.setState({value: val}); 
    }
  

  render() {
    const {col,error,dropdownValues,row, bottomOffset, rowHeight,value,onChange} = this.props;
    const hover = error ? <Popover id={`${col.dataKey}_error`}>{error}</Popover> : <div />;
    const bgColor = error||value==''?'#ffd':'';
    return (
       <OverlayTrigger
        key={col.dataKey} overlay={hover} placement='top'
        trigger={['hover', 'focus']}>
         <DropdownList data={dropdownValues.data} value={value}
            style={{height: rowHeight- 2, width: '100%',backgroundColor:bgColor}}
            dropUp={bottomOffset < 230}
            onChange={(val) => onChange(val.CODE_VALUE)}
            valueField='CODE_VALUE' textField='LABEL' />
      </OverlayTrigger>
      
    );
  }
}
