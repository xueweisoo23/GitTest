import React, {Component, PropTypes} from 'react';
import {Button,Modal} from 'react-bootstrap';
import { connect } from 'react-redux';

import {FlexPanel} from 'ssc-cdt3';

import * as _sutils from '../sharedutils';
import * as _actionCreators from '../redux/ActionCreators'; 
import { bindActionCreators } from 'redux'

/**
 *  @author p530579
 * 
 * Use this component when you wanted to show the dialog window and havve have any components inside it
 * Refere the TestPillboxCompoenet for usage
 * 
 * **/
 function mapStateToProps(state) {
  return {
  }
}

@connect(mapStateToProps, function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
})
export default class ModalWindow extends Component {
	
	static propType = {
     	modalCloseCallback:PropTypes.func,
		modalHeader:PropTypes.string,
		id:PropTypes.string.isRequired,
		buttons : PropTypes.array,
		showModalWindow:PropTypes.bool.isRequired,
    }
	 
	static defaultProps = {
		showmodalWindow:false,
		modalHeader:'DAS Dialog', 
		buttons:['OK'],
		isDisabled:true,
	 } 
 	
	 constructor(props) {
		super(props);
	}

	componentWillReceiveProps=(nextProps) => {
	  this.props = nextProps;
	  }
	  
	closeDialog=()=>{
		this.props.actions.hideModalWindow(this.props.id);
	}
	
	callbackHandler=(btnType) => {
	this.closeDialog();
	
	if(this.props.modalCloseCallback)
		this.props.modalCloseCallback(btnType,this.props.id)  
	}
	
	
  render() {
	 // let CUSTOM_BUTTON_GRP_START =  <ButtonGroup style={{align: 'right'}}>;
	return (
		<Modal  dialogClassName={this.props.className}  show={this.props.showModalWindow} onHide={this.callbackHandler.bind(this,'Close')} backdrop ={'static'} >
		 <Modal.Header closeButton>
            <Modal.Title><b>{this.props.modalHeader}</b></Modal.Title> 
          </Modal.Header>        
          <Modal.Body>
          	<FlexPanel >
		   	{this.props.children}					
		    </FlexPanel>
		  </Modal.Body>
		 
          <Modal.Footer>
              { this.props.buttons.map((item, index)=>{
				return (<Button className='btn btn-primary'  disabled={this.props.isDisabled} onClick={this.callbackHandler.bind(this,item)}>{item}</Button>)	
			})}
			<Button onClick={this.callbackHandler.bind(this,'Close')}>Close</Button> 
          </Modal.Footer>
		 </Modal>
		); 
	}
}