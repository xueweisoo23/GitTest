import React, { Component, PropTypes } from 'react';
import { Button } from 'react-bootstrap';
import { DynamicDataGrid, HorizontalLayout, FixedPanel, FlexPanel, VerticalLayout, connectCdtDataComponent } from 'ssc-cdt3';
import { connect } from 'react-redux';
import * as _service from '../service';
import ModalWindow from '../components/ModalWindow';
import ClientSelectionHeader from '../components/ClientSelectionHeader';
import MessageDialog, * as _dialog from '../components/MessageDialog';
import * as _actionCreators from '../redux/ActionCreators';
import { bindActionCreators } from 'redux'
import * as _sutils from '../sharedutils';
import * as _aconst from '../appconstants';
import FileUpload from '../components/FileUpload'; 
import {FILE_DEF_COLUMNS} from '../shared/ColumnConfigs';
import RuleMappingsDownload from '../RuleMappingsDownload';
const UPLOAD_FILE = {
		fileTypes:['.xls','.xml'],
		maxFilesAllowed:1,
		templateFileId:'',
	};
function mapStateToProps(state) {
  return {
     showFileUploadModalWindow : (state.modalWindow.FILE_UPLOAD?state.modalWindow.FILE_UPLOAD:false),
    showHelpModalWindow: (state.modalWindow.HELP_WINDOW ? state.modalWindow.HELP_WINDOW : false),
    selectedClient: state.clients.selectedClient,
    isClientSelectionChanged: state.clients.isClientSelectionChanged,
    helpData: state.help.helpData
  }
}

@connect(mapStateToProps, function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
})
@connectCdtDataComponent('fileDefinition', 553840003)
export default class FileDefinitionContainer extends Component {

  static contextTypes = {
    router: React.PropTypes.object.isRequired,
  }

  static defaultProps = {
    showMessageDialog: false
  }

  static propTypes = {
    fileDefinition: PropTypes.object,
    fileDefinitionActions: PropTypes.object,
  }


  constructor(props) {
    super(props);
    this.state = { selectedRow: undefined, editRow: undefined, editErrors: undefined, checkedRows: [], fileContent: undefined ,isDownloaded:false}
    this.gridData = [];
 this.file_def_id = null;
  this.sender_app_cd=null;
  }

  onCheck = (checked) => {
    this.setState({ checkedRows: checked });
  }
  addNew = () => {
    this.modifiedRow = {};
    this.setState({ editRow: {}, editErrors: undefined });
  }

  onDeleteLinkClick = () => {
    this.props.actions.showMessageDialog("Confirm Action", _dialog.DIALOG_TYPE_YES_NO, 'Are you sure you would like to delete ?', null, this.deleteDialogCallback, this);
  }
  deleteDialogCallback = (btntype, param) => {
    if (_dialog.BTN_TYPE_YES === btntype) {
      this.remove();
    }

  }

  remove = () => {
    const {checkedRows} = this.state;
    this.props.fileDefinitionActions.delete(checkedRows).then((ret) => {
      if (ret.error) {
        this.gridActions.error('Error', ret.payload._error || 'Error deleting items.');
      } else {
        this.connectCallback(this.gridActions);
        this.gridActions.success('Success', 'File definition(s) deleted.');
        this.setState({ editRow: undefined, editErrors: undefined, checkedRows: [] });
      }
    });
  }


  onRowDoubleClick = (row) => {
    this.modifiedRow = {...row }; // clone for new values
    this.setState({ editRow: row, editErrors: undefined });
  }

  connectCallback = (gridActions, clientId) => {

    this.gridActions = gridActions;
    if (!clientId)
      clientId = _sutils.getSelectedClientId();
    _service.makeCallWithHandlers(gridActions, _service.CALL_TYPE_LOADLIST, { CLIENT_ID: clientId }, this.fileDefSuccessCallback, null, undefined, this.props);
  }
  fileDefSuccessCallback = (ret, actions, spinJobId) => {
    if (ret.payload.data.length > 0)
      this.gridData = ret.payload.data;
  }

  componentDidMount() {

  }
  componentWillMount() {

    _sutils.doCheckforEntitlement(this, true)
  }

  componentWillReceiveProps(props) {

    if (this.props.selectedClient !== props.selectedClient && props.isClientSelectionChanged)
      this.connectCallback(this.gridActions, props.selectedClient.CODE_VALUE);
  }


  modalClosedCallback = (btnType, id) => {
    console.log('id:' + id + ':btnType:' + btnType);
  }

  onChange = (value, column) => {
    const {editErrors = {}} = this.state;
    this.modifiedRow[column.dataKey] = value;
    if (!value) {
      this.setState(
        { editRow: {...this.modifiedRow},
    editErrors: column.dataKey == 'FILE_PATTERN_TXT' ? {...editErrors, [column.dataKey]: `${column.label}:Please enter characters` } :
      column.dataKey == 'HEADER_KEYWORD_TXT' ? {...editErrors, [column.dataKey]: `${column.label}:Please enter characters` } :
        column.dataKey == 'OUTPUT_FILE_NM' ? {...editErrors, [column.dataKey]: `${column.label}:Please enter characters` } : {...editErrors, [column.dataKey]: `${column.label} is required` }
  });
} else {
  this.setState({
    editRow: {...this.modifiedRow},
editErrors: {...editErrors, [column.dataKey]: undefined }
      });
    }
return true;
  }

onKeyDown = (e) => {
  switch (e.keyCode) {
    case 13: // enter key
      if (typeof this.modifiedRow['KEY_ID'] === 'undefined') {
        this.add();
      } else {
        this.update();
      }
      break;
    case 27: // escape key
      e.preventDefault();
      e.stopPropagation();
      this.setState({ editRow: undefined });
      break;
    default:
      break;
  }
}

update = () => {
  if (this.validate()) {
    this.props.fileDefinitionActions.update(this.modifiedRow).then((ret) => {
      if (ret.error) {
        this.gridActions.error('Error', ret.payload._error || 'Please correct errors.');
        this.setState({ editErrors: ret.payload });
      } else {
        this.connectCallback(this.gridActions);
        this.gridActions.success('Success', 'File definition updated.');
        this.setState({ editRow: undefined });
      }
    });
  }
}

add = () => {
  if (this.validate()) {
    this.modifiedRow.CLIENT_ID = _sutils.getSelectedClientId();
    this.props.fileDefinitionActions.addNew(this.modifiedRow).then((ret) => {
      if (ret.error) {
        this.gridActions.error('Error', ret.payload._error || 'Please correct errors.');
        this.setState({ editErrors: ret.payload });
      } else {
        this.connectCallback(this.gridActions);
        this.gridActions.success('Success', `File definition added.`);
        this.setState({ editRow: undefined });

      }
    });
  }
}

validate() {
  // plug in any validation framework here
  const errors = {};

  //if (!this.modifiedRow.CLIENT_NM) 
  //   errors.CLIENT_NM = 'Client  is required';

  if (!this.modifiedRow.SENDER_APP_NM)
    errors.SENDER_APP_NM = 'Sender App is required';

  if (!this.modifiedRow.FILE_DEF_ID)
    errors.FILE_DEF_ID = 'File Definition ID is required';
  else {
    if (undefined == this.modifiedRow.FILE_DEF_ID || '' == this.modifiedRow.FILE_DEF_ID || '' == this.modifiedRow.FILE_DEF_ID.trim())
      errors.FILE_DEF_ID = 'Please enter File Definition ID';
    var regex = /^([a-zA-Z0-9 _-]+)$/;
    if (!regex.test(this.modifiedRow.FILE_DEF_ID))
      errors.FILE_DEF_ID = 'Special characters are not allowed';
  }

  if (!this.modifiedRow.FILE_TYPE_TXT)
    errors.FILE_TYPE_TXT = 'File Type is required';

  if (!this.modifiedRow.RECIEVER_APP_NM)
    errors.RECIEVER_APP_NM = 'Receiver App is required';

  if (!this.modifiedRow.FILE_PATTERN_TXT)
    errors.FILE_PATTERN_TXT = 'File Pattern is required';
  else {
    if (undefined == this.modifiedRow.FILE_PATTERN_TXT || '' == this.modifiedRow.FILE_PATTERN_TXT || '' == this.modifiedRow.FILE_PATTERN_TXT.trim())
      errors.FILE_PATTERN_TXT = 'Please enter file pattern';
    var regex = /^([a-zA-Z0-9 _*-]+)$/;
    if (!regex.test(this.modifiedRow.FILE_PATTERN_TXT))
      errors.FILE_PATTERN_TXT = 'Special characters are not allowed';

    this.gridData.forEach((col, index, array) => {
      if (this.modifiedRow.KEY_ID != col.KEY_ID)
        if (this.modifiedRow.SENDER_APP_NM == col.SENDER_APP_NM || this.modifiedRow.SENDER_APP_NM == col.SENDER_APP_CD) {
          if (this.modifiedRow.FILE_PATTERN_TXT.toLowerCase() == col.FILE_PATTERN_TXT.toLowerCase())
            errors.FILE_PATTERN_TXT = 'File Pattern already exist for SENDER APP - ' + col.SENDER_APP_NM;
          else {
            var colIntex = col.FILE_PATTERN_TXT.indexOf("*");
            var modifiedRawIndex = this.modifiedRow.FILE_PATTERN_TXT.indexOf("*")

            if (colIntex != -1 && colIntex > 0) {
              let begin = col.FILE_PATTERN_TXT.substr(0, colIntex);
              if (this.modifiedRow.FILE_PATTERN_TXT.toLowerCase().startsWith(begin.toLowerCase()))
                errors.FILE_PATTERN_TXT = 'File Pattern already exist for SENDER APP - ' + col.SENDER_APP_NM;
            }
            if (modifiedRawIndex != -1 && modifiedRawIndex > 0) {
              let begin = this.modifiedRow.FILE_PATTERN_TXT.substr(0, modifiedRawIndex);
              if (col.FILE_PATTERN_TXT.toLowerCase().startsWith(begin.toLowerCase()))
                errors.FILE_PATTERN_TXT = 'File Pattern already exist for SENDER APP - ' + col.SENDER_APP_NM;
            }
          }
        }
    });

  }

  if (!this.modifiedRow.DELIMITER_TXT)
    errors.DELIMITER_TXT = 'Delimiter is required';

  if (!this.modifiedRow.OUTPUT_FILE_TYPE_TXT)
    errors.OUTPUT_FILE_TYPE_TXT = 'Output File Type is required';
  if (!this.modifiedRow.OUTPUT_FILE_TYPE_TXT)
    errors.OUTPUT_DELIMITER_TXT = 'Output Delimeter is required';

  /* if (!this.modifiedRow.FILE_MAPPING_ID) 
     errors.FILE_MAPPING_ID = 'File Mapping is required';*/
  if (this.modifiedRow.OUTPUT_FILE_NM) {
    if (undefined == this.modifiedRow.OUTPUT_FILE_NM || '' == this.modifiedRow.OUTPUT_FILE_NM || '' == this.modifiedRow.OUTPUT_FILE_NM.trim())
      errors.OUTPUT_FILE_NM = 'Please enter output file name';
    // var regex = /^([a-zA-Z0-9 \_]+)$/;
    // if (!regex.test(this.modifiedRow.OUTPUT_FILE_NM)) {
    //   errors.OUTPUT_FILE_NM = 'Special characters are not allowed';
    // }
  }

  if (this.modifiedRow.POLL_MS_QTY && Number(this.modifiedRow.POLL_MS_QTY) === 'NaN')
    errors.POLL_MS_QTY = 'Pool time should be numeric';

  if (this.modifiedRow.COMP_WAIT_TIME_QTY && Number(this.modifiedRow.COMP_WAIT_TIME_QTY) === 'NaN')
    errors.COMP_WAIT_TIME_QTY = 'Wait time should be numeric';

  if (this.modifiedRow.MAX_RECORD_QTY && Number(this.modifiedRow.MAX_RECORD_QTY) === 'NaN')
    errors.MAX_RECORD_QTY = 'Max record should be numeric';

  if (this.modifiedRow.CORE_POOL_QTY && Number(this.modifiedRow.CORE_POOL_QTY) === 'NaN')
    errors.CORE_POOL_QTY = 'Core Pool time should be numeric';

  if (this.modifiedRow.MAX_POOL_QTY && Number(this.modifiedRow.MAX_POOL_QTY) === 'NaN')
    errors.MAX_POOL_QTY = 'Max pool time should be numeric';

  if (this.modifiedRow.QUEUE_SIZE_QTY && Number(this.modifiedRow.QUEUE_SIZE_QTY) === 'NaN')
    errors.QUEUE_SIZE_QTY = 'Queue size should be numeric';

  if (this.modifiedRow.FILE_TYPE_TXT == 'DELIMITED' && (this.modifiedRow.DELIMITER_TXT == 'NA' || !this.modifiedRow.DELIMITER_TXT))
    errors.DELIMITER_TXT = 'Please select delimeter';
  if (this.modifiedRow.FILE_TYPE_TXT && this.modifiedRow.FILE_TYPE_TXT != 'DELIMITED' && (this.modifiedRow.DELIMITER_TXT != 'NA' || !this.modifiedRow.DELIMITER_TXT))
    errors.DELIMITER_TXT = 'For the file type ' + this.modifiedRow.FILE_TYPE_TXT + ' delimeter is not applicable.Please select NA';
  if (this.modifiedRow.OUTPUT_FILE_TYPE_TXT == 'DELIMITED' && (this.modifiedRow.OUTPUT_DELIMITER_TXT == 'NA' || !this.modifiedRow.OUTPUT_DELIMITER_TXT))
    errors.OUTPUT_DELIMITER_TXT = 'Please select output delimeter';
  if (this.modifiedRow.OUTPUT_FILE_TYPE_TXT && this.modifiedRow.OUTPUT_FILE_TYPE_TXT != 'DELIMITED' && (this.modifiedRow.OUTPUT_DELIMITER_TXT != 'NA' || !this.modifiedRow.OUTPUT_DELIMITER_TXT))
    errors.OUTPUT_DELIMITER_TXT = 'For the output file type ' + this.modifiedRow.OUTPUT_FILE_TYPE_TXT + ' ouput delimeter is not applicable.Please select NA';
  
  this.setState({ editErrors: errors });
  return Object.keys(errors).length === 0;
}

viewRules = () => {
  console.log("client id:" + _sutils.getSelectedClientId());
  let params = { fileDefId: this.state.selectedRow.FILE_DEF_ID, clientId: _sutils.getSelectedClientId(), inputFileType: this.state.selectedRow.FILE_TYPE_TXT };
  this.context.router.push({ pathname: '/ruleMappingconfig', state: { params: params } });
}
showHelpWindow = () => {
  let {helpData} = this.props;
  helpData.map((obj) => {
    if (obj.HELP_DEF_ID == "FILE_DEF_ID") {
      this.setState({ fileContent: { __html: obj.FILE_CONTENT } });
    }
  })
  this.props.actions.showModalWindow('HELP_WINDOW');
}


manageRules = () => {
  console.log("client id:" + _sutils.getSelectedClientId());
  let params = { clientId: _sutils.getSelectedClientId() };
  this.context.router.push({ pathname: '/ruleConfigNew', state: { params: params } });
}

onRowClick = (row) => {
  this.setState({ selectedRow: row });
}
 exportFile =(filedefid,senderappcd) =>{
	
	  if((filedefid!=null && filedefid.trim!="") && (senderappcd!=null && senderappcd.trim!=""))
		  {
		  this.file_def_id = filedefid;
		    this.sender_app_cd=senderappcd;
		    this.setState({isDownloaded:true});
		  }
	  else
		  console.log('fileDefID cannot be null'); 
}
  uploadFileCallback=(filename,isSuccess,message)=> {
		console.log('uploadFileCallback=>filename:'+filename+':isSuccess:'+isSuccess+':message:'+message);
if(isSuccess){
  this.props.actions.hideModalWindow('FILE_UPLOAD');
  this.gridActions.success('Success', 'File processed successfully. ');
  this.connectCallback(this.gridActions);
} else {
	this.props.actions.hideModalWindow('FILE_UPLOAD');
    this.gridActions.error('Error', message);
}


		//alert(message);
	}
  downLoadCompleteCallBack=()=>{
	  this.setState({isDownloaded:false});
	}
  showUploadWindow  = ()=> {
		this.props.actions.showModalWindow('FILE_UPLOAD');
	 }


render() {
  let {checkedRows, selectedRow} = this.state;
	let filedefid=undefined;
	let senderappcd=undefined;
  let enableDelete = checkedRows && checkedRows.length > 0;
  let enableAdd = typeof editRow === 'undefined';
  let enableViewRule = selectedRow && selectedRow.FILE_DEF_ID && selectedRow.FILE_DEF_ID.trim() !== ''
  let MESSAGE_DIALOG = <MessageDialog showDialog={this.props.showMessageDialog} messageDialogParams={this.props.messageDialogParams} />
if(enableViewRule)
	  {
	  filedefid=selectedRow.FILE_DEF_ID;
	  senderappcd=selectedRow.SENDER_APP_CD;
	  }
let FILE_UPLOAD = <ModalWindow id={'FILE_UPLOAD'} modalHeader={'File defenition upload'} buttons={[]} showModalWindow = {this.props.showFileUploadModalWindow} modalCloseCallback={this.modalClosedCallback}> 
	  <VerticalLayout flex='flex' style={{width: '100%'}}>
<FileUpload fileUploadCallback={this.uploadFileCallback.bind(this)} callType={'ENTIRE_RULE_MAPPING'} paramObject={{PARAM1:_sutils.getSelectedClientId(),PARAM2:'ENTIRE_RULE_MAPPING'}} fileUploadConfig={UPLOAD_FILE} />
</VerticalLayout> 
</ModalWindow>;
let FILE_DOWNLOAD = <RuleMappingsDownload FILE_DEF_ID={this.file_def_id} CLIENT_ID={_sutils.getSelectedClientId()} SENDER_APP_CD={this.sender_app_cd} 
actionPath={'ExportMappingsServlet'} method={'POST'} onDownloadComplete={this.downLoadCompleteCallBack}/>;
	
let UPLOAD_BUTTON = <Button className='btn btn-primary btn-xs' onClick = {this.showUploadWindow.bind(this)}>Upload</Button>
  let HELP_WINDOW = <ModalWindow id={'HELP_WINDOW'} modalHeader={'Help'} buttons={[]} showModalWindow={this.props.showHelpModalWindow}
    modalCloseCallback={this.modalClosedCallback}>
    <VerticalLayout flex='flex' style={{ width: '100%' }}>
      <span dangerouslySetInnerHTML={this.state.fileContent}></span>
    </VerticalLayout>
  </ModalWindow>;
  return (
    <HorizontalLayout>
      <ClientSelectionHeader />
      <VerticalLayout flex='flex' onKeyDown={this.onKeyDown}>
        <FixedPanel style={{ overflow: 'visible' }}>
          <h3 style={{ marginTop: 0, marginBottom: 0, width: 260 }}> <strong>File Definitions</strong>
            <strong className=' fa fa-question-circle' style={{ color: '#286090', fontSize: 24, marginLeft: 10,cursor:'pointer' }}
              onClick={this.showHelpWindow.bind(this)} ></strong></h3>

          <div style={{ display: 'inline-block', float: 'right' }}>

            <Button className='btn btn-primary btn-xs' style={{ marginRight: 8 }}
              onClick={this.viewRules} disabled={!enableViewRule} >Manage Rule Config</Button>

            <Button className='btn btn-primary btn-xs' style={{ marginRight: 8 }}
              disabled={!enableAdd} onClick={this.addNew} >Add</Button>
            <Button className='btn btn-primary btn-xs' style={{ marginRight: 8 }} onClick={this.onDeleteLinkClick} disabled={!enableDelete}>Delete</Button>
	 <Button className='btn btn-primary btn-xs' style={{marginRight: 8}}
						     onClick={this.exportFile.bind(this,filedefid,senderappcd)} disabled={!enableViewRule}>Download</Button>
						     {UPLOAD_BUTTON}
          </div>
        </FixedPanel>
        <FlexPanel>
          <DynamicDataGrid
            columns={FILE_DEF_COLUMNS}
            dataIdf={553840003}
            gridConnectCallback={this.connectCallback}
            componentId='fileDefinitionGrid'
            keyFieldName='KEY_ID'
            editRow={this.state.editRow}
            onRowDoubleClick={this.onRowDoubleClick}
            onChange={this.onChange}
            editErrors={this.state.editErrors}
            onCheckedChange={this.onCheck}
            onRowClick={this.onRowClick}
            scale={1}
            pageSize={50}
            excelExport
            csvExport
            hasCheckbox
            />
        </FlexPanel>
        {HELP_WINDOW}
	{FILE_UPLOAD}
      </VerticalLayout>
      {MESSAGE_DIALOG}
       {this.state.isDownloaded && FILE_DOWNLOAD}
    </HorizontalLayout>


  );
}
}



