
import React,{Component, PropTypes, Form} from 'react';
import { connect } from 'react-redux';
import * as _sutils from './sharedutils.js';


/**
 *  @author p591995
 **/
 
export default class FileDownload extends Component {
	 static propTypes = {
	        actionPath: PropTypes.string.isRequired,
	        method: PropTypes.string,
	        onDownloadComplete: PropTypes.func,
	        LOAD_ID: PropTypes.string,
	        FILE_NAME: PropTypes.string
	        //queryParams: PropTypes.object
	    };

	    static defaultProps = {
	        method: 'POST'
	    };
	    
	    constructor(props) {
	        super(props);
	      }
	     
	      componentWillMount() {
	      }

	    componentDidMount() {
	          this.refs.Test.submit();
	          this.props.onDownloadComplete();
	     }
	    
	    render() {
	    	let {LOAD_ID,FILE_NAME,actionPath,method} = this.props;

	        return (
	        		<div>
			           <form ref='Test' className='hidden' action = {actionPath} method={method}>
			            <input name="LOAD_ID" value={LOAD_ID} />
			            <input name="FILE_NAME" value={FILE_NAME} />
			           </form>
	                </div>
	        );
	    }
}
