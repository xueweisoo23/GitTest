import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {DropdownList} from 'react-widgets';
import {connectCdtDataComponent} from 'ssc-cdt3';
import * as _service from '../service'
import {OverlayTrigger, Popover} from 'react-bootstrap';
import {DropdownEditor} from './DropdownEditor';

@connectCdtDataComponent('yesNoData',553840008)
export class YesNoEditor extends Component { 
  static propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    col: PropTypes.object,
    row: PropTypes.object,
    bottomOffset: PropTypes.number,
    rowHeight: PropTypes.number,
    yesNoData: PropTypes.object,
	  yesNoDataActions: PropTypes.object,
  }

  constructor(props) {
    super(props);
    const {value} = props;
    this.state = {value};
  }

  onChange = (val) => {

    if (this.props.onChange(val, this.props.col)) {
    	if(this.props.col.dataKey ==='IS_MANDATORY_NM')
    		this.props.onChange('true', {dataKey: 'IS_MANDATORY_CHANGED'});
    	else if(this.props.col.dataKey ==='ALLOW_EMPTY_NM')
    		this.props.onChange('true', {dataKey: 'IS_ALLOW_EMPTY_CHANGED'});
		else if(this.props.col.dataKey ==='TRIM_VALUES_NM')
    		this.props.onChange('true', {dataKey: 'IS_TRIM_VALUES_CHANGED'});
        this.setState({value: val});
    }
  }
   componentDidMount() {
     _service.makeCallWithHandlers(this.props.yesNoDataActions,_service.CALL_TYPE_LOADLIST,{CALL_TYPE:'YES_NO'},null,null,undefined,this.props) 
  }

  render() {
    const {col,error,yesNoData,row, bottomOffset, rowHeight} = this.props;
    return (
    <DropdownEditor value={this.state.value} onChange={this.onChange} col={col} row={row} bottomOffset={bottomOffset} rowHeight={rowHeight}
                    dropdownValues={yesNoData} error ={error}>
    </DropdownEditor>   
    );
  }
}
