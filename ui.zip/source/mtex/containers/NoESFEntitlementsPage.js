
import React, {Component, PropTypes} from 'react';
import { connect } from 'react-redux';
import * as _sutils from '..//sharedutils';


/**
 *  @author p530579
 * Page to be displayed if the user is not entitled to any of the functions on DAS
 **/
 
@connect(state => ({authsession: state.authsession})) 

export default class NoESFEntitlementsPage extends Component {
 static propTypes = {
	 
  };
 
  constructor(props) {
    super(props);
  }
 
  componentWillMount() {
  }

  componentWillReceiveProps(props) {

  }
  
  render() {
	  //<b><a href={message}>eSF Self-Service</a></b>
	    return (
	       <div> User <b>{_sutils.getUserName(this.props)}</b> is not entitled.Please visit &nbsp;
	       <b>APMD</b> 
	       &nbsp; and request access to <b> MTex</b> application.
	       </div>
	    );
  }
}
