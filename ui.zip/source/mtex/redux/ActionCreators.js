/**
 *   @author p530579
 * 
 * redux actions to be used on the application in DAS any new actioncreators/actions should be added here only
 * It's used to dispatach any actionevent across the components on the application 
 * 
 **/


export const SHOW_MODAL_WINDOW = 'SHOW_MODAL_WINDOW';
export const HIDE_MODAL_WINDOW = 'HIDE_MODAL_WINDOW';


export const SHOW_MESSAGE_DIALOG = 'SHOW_MESSAGE_DIALOG';
export const HIDE_MESSAGE_DIALOG = 'HIDE_MESSAGE_DIALOG';

export const RELOAD_CLIENT_DROPDOWN = 'RELOAD_CLIENT_DROPDOWN';
export const CLIENT_DROPDOWN_VALUE_CHANGE = 'CLIENT_DROPDOWN_SELECTION_CHANGE';

export const POST_CLIENT_CHANGE_COMPLETED = 'POST_CLIENT_CHANGE_COMPLETED';

export const LOAD_HELP_DATA = 'LOAD_HELP_DATA';

export function showMessageDialog(header,dialogType,message,messageId,callbackHandler,obj,customBtns) {
  return { 	type: SHOW_MESSAGE_DIALOG,
  		   	messageDialogParams: {	header,
							dialogType,
							message,
							messageId,
							obj,
							customBtns,
							callbackHandler 
						  }
			}
}

export function hideMessageDialog() {
  return { 	type: HIDE_MESSAGE_DIALOG }
}



export function showModalWindow(id) {
  return { 	type: SHOW_MODAL_WINDOW,
  			modalId:id}
}

export function hideModalWindow(id) {
  return { 	type: HIDE_MODAL_WINDOW,
  			modalId:id }
}

export function reloadClientDropdown(clientNames) {
  return { 	type: RELOAD_CLIENT_DROPDOWN,
  			entitledClients: clientNames }  
}

export function loadHelpData(helpData) {
  return { 	type: LOAD_HELP_DATA,
  			helpData: helpData }  
}

export function clientSelectionChanged(selectedClient) {
  return { 	type: CLIENT_DROPDOWN_VALUE_CHANGE,
  			selectedClient: selectedClient }  
} 

export function postViewChangeOperationCompleted() {
  return { 	type: POST_CLIENT_CHANGE_COMPLETED,
  			}  
} 



