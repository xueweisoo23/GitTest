import React, {Component, PropTypes} from 'react';
import DropzoneComponent from 'react-dropzone-component'; 
import {Button} from 'react-bootstrap';
import {VerticalLayout, FixedPanel} from 'ssc-cdt3';


export default class FileUpload extends Component {
	static propType = {
          fileUploadCallback: PropTypes.func.isRequired,
          callType: PropTypes.string.isRequired ,
          fileUploadConfig: PropTypes.object,
          paramObject: PropTypes.object
      }
	constructor(props)
	{
		super(props);
	}

	componentDidMount() {
		
	}	  
  
    componentWillReceiveProps=(nextProps) => {
        if(this.refs.uploader.dropzone.options.params)               
              this.refs.uploader.dropzone.options.params = Object.assign(this.refs.uploader.dropzone.options.params,nextProps.paramObject);
  }
     
    isEmpty=(value)=> {
    	  if(value!=undefined)
    	  {
    	     if(typeof value==='string')
    	        return value.trim()==='';
    	     else if(typeof value==='object') 
    	       return value===null;
    	  }
    	  else
    	    return true;
    	}


	downloadTemplateFile=(templateFileId)=>{
           if(templateFileId && !this.isEmpty(templateFileId))
                  window.location = 'AEFDownloadServlet?DOWNLOAD_CALL_TYPE='+templateFileId;
           else
                  console.log('templateFileId cannot be null'); 
      }
     
  onSuccess = (result) => {
    let resp =  JSON.parse(result.xhr.responseText);
    if(resp.xdata.rows.length>0){
            
       let fileName =  resp.xdata.rows[0].FILE_NAME;
       let status = resp.xdata.rows[0].IS_SUCCESS;
       let message = resp.xdata.rows[0].MESSAGE;
       this.props.fileUploadCallback(fileName,status==='true',message);
      }
  }

  onUpload = () => {
    this.refs.uploader.dropzone.processQueue();
  }

  render() {
		console.log('render inside File Upload..........')
        const{fileUploadConfig,paramObject} = this.props;
        let displayDownloadTemplate = fileUploadConfig.templateFileId && !this.isEmpty(fileUploadConfig.templateFileId);
        
        let TEMPLATE_DOWNLOAD_BUTTON = <Button  className="button" 
                     bsStyle="primary"  
                     onClick= {this.downloadTemplateFile.bind(this,fileUploadConfig.templateFileId)} 
                     style ={{margin:'2'}} >
                     Download Template File
            </Button> ;
        
      let componentConfig = {
                  iconFiletypes: fileUploadConfig.fileTypes?fileUploadConfig.fileTypes:[],
                  showFiletypeIcon: true,
                  thumbnailWidth: '50px',
                  thumbnailHeight: '20px'
                  //postUrl: 'UploadServlet'
            };
      let djsConfig = {
            maxFiles:fileUploadConfig.maxFilesAllowed?fileUploadConfig.maxFilesAllowed:10,
            addRemoveLinks: true,
            uploadMultiple: false,
            autoProcessQueue: true, 
            dictDefaultMessage:(fileUploadConfig.fileUploadCaption)?fileUploadConfig.fileUploadCaption:'Click here to upload file',
            params: Object.assign({
                  __request: '553840002',
                  CALL_TYPE: this.props.callType,
                  DATASOURCE:'D1V'
            },paramObject),
    };
    let simpleCallBack = function () {
        console.log('I\'m a simple callback');
        return false;
    };
    let eventHandlers = {
      // This one receives the dropzone object as the first parameter
      // and can be used to additional work with the dropzone.js
      // object
      init: null,
      // All of these receive the event as first parameter:
      drop: null,
      dragstart: null,
      dragend: null,
      dragenter: null,
      dragover: null,
      dragleave: null,
      // All of these receive the file as first parameter:
      addedfile: simpleCallBack,
      removedfile: null,
      thumbnail: null,
      error: null,
      processing: null,
      uploadprogress: null,
      sending: null,
      success: this.onSuccess,
      complete: null,
      canceled: null,
      maxfilesreached: null,
      maxfilesexceeded: null,
      // All of these receive a list of files as first parameter
      // and are only called if the uploadMultiple option
      // in djsConfig is true:
      processingmultiple: null,
      sendingmultiple: null,
      successmultiple: null,
      completemultiple: null,
      canceledmultiple: null,
      // Special Events
      totaluploadprogress: null,
      reset: null,
      queuecompleted: null
    }
return (
		 <VerticalLayout flex='fixed' width={'45%'}>
		 <FixedPanel style={{paddingTop: 2}}></FixedPanel>
		   <FixedPanel style={{backgroundColor: '#efefef'}}>
                <DropzoneComponent
                  ref="uploader"
                  config={componentConfig}
                  eventHandlers={eventHandlers}
                  action="AEFUploadServlet"
                  djsConfig={djsConfig} />
                
               {displayDownloadTemplate && TEMPLATE_DOWNLOAD_BUTTON}
               </FixedPanel>
            </VerticalLayout>
		); 
	}
}