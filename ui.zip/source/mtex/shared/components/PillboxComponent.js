import React, {Component, PropTypes} from 'react';
import {Icon,VerticalLayout, FlexPanel, FixedPanel, HorizontalLayout} from 'ssc-cdt3';
import {Button, ButtonGroup,Input} from 'react-bootstrap';
import FilteredMultiselect from './FilteredMultiselect'; 

/**
 * @author p530579
 * 
 * Component to display the pillbox with multiselection
 * Refer testcomponent TestPillbox for usage
 * 
 */
export default class PillboxComponent extends Component {

  static propTypes = {
    allValues: PropTypes.array.isRequired,
    selectedValues: PropTypes.array.isRequired,
    onChange: PropTypes.func.isRequired,    
    keyField: PropTypes.string.isRequired, 
    displayField: PropTypes.string.isRequired,
    leftCaption: PropTypes.string,
    rightCaption: PropTypes.string,
    size: PropTypes.number,
    enableApplyBtnOnOrderChange: PropTypes.func,
    enableSort: PropTypes.bool,
    sortOrder: PropTypes.string
  };
  
  static defaultProps = {
	  leftCaption : 'Available Items',
      rightCaption : 'Selected Items',
      displayField : 'name',
      keyField : 'id',
      leftFilter : true,
      rightFilter : true,
      enableSort:false,
      sortOrder: 'ASC'
	 } 

  constructor(props) {
    super(props);
    this.state = this.getInitState(props);
    this.intitialize();
    this.INITIAL_SELECTED_VALUE=props.selectedValues;
  }
  intitialize(){
	  this.leftSelected = [];
	  this.rightSelected = [];
    Array.prototype.swap = function(x,y) {
      var t = this[x];
      this[x] = this[y];
      this[y] = t;
      return this;
}
  }
    
    getInitState(props) {
    const {allValues,selectedValues} = props; 
    const rightListData = selectedValues;
    //filtering the non-selected values here!!
    let selectedOptions=[];
    const leftListData = this.filterOutCommonItems(allValues,selectedValues,props.keyField);
    return {rightListData, leftListData,selectedOptions};
  }
   
   filterOutCommonItems = (sourceArr,filterArr,keyfield) => {
     return sourceArr.filter((val) => { return (filterArr.findIndex((element) =>{ return (element[keyfield]==val[keyfield]);})==-1);}) 
   }
     
  moveRight = () => {
    let {rightListData, leftListData} = this.state;     
    leftListData = this.filterOutCommonItems(leftListData,this.leftSelected,this.props.keyField);
    rightListData = rightListData.concat(this.leftSelected);
    this.setState({leftListData, rightListData}, this.getUpdatedDataSelection);
    this.leftSelected = [];
  }

  moveLeft = () => {
    let {rightListData, leftListData} = this.state;
    rightListData = this.filterOutCommonItems(rightListData,this.rightSelected,this.props.keyField);
    leftListData = leftListData.concat(this.rightSelected);
    this.setState({leftListData, rightListData}, this.getUpdatedDataSelection);
    this.rightSelected = [];
  }
  
  orderItems=(clickType)=>{
    let {selectedOptions, rightListData} = this.state;
    if(_.isEmpty(this.rightSelected))
    	this.rightSelected = selectedOptions;
	  rightListData = this.swapObjects(rightListData,this.rightSelected,clickType); 
	  this.setState({rightListData}, this.rightListData);
	  this.setState({selectedOptions:this.rightSelected});
	  /*Below code enable pillbox apply button on order change of selected values */
	  if(this.state.rightListData.length>1 && this.rightSelected.length>0)
		  this.props.enableApplyBtnOnOrderChange();
  }
  
  swapObjects = (sourceArr,selectedItems,position) =>{
    let selectedItem = (selectedItems && selectedItems.length)>0?selectedItems[0]:undefined; 
    if(!selectedItem) return sourceArr;
    let selectedItemIndex = sourceArr.findIndex((element)=>{ return (element[this.props.keyField]===selectedItem[this.props.keyField]);}); 
    if((selectedItemIndex===0 && position==='UP') 
            ||  (selectedItemIndex===(sourceArr.length-1) && position==='DOWN'))
      return sourceArr;
    let toMoveIndex = position==='UP'?(selectedItemIndex-1):(selectedItemIndex+1);
    sourceArr = sourceArr.swap(selectedItemIndex,toMoveIndex);
    return sourceArr;
  }
  

  getUpdatedDataSelection = () => {
    const {onChange} = this.props;
    const {rightListData, leftListData} = this.state;
    onChange({rightListData,leftListData},this.INITIAL_SELECTED_VALUE);
  }
  
  leftListChanged = (data) =>
  {
    this.leftSelected =  data;
  }
  
  rightListChanged = (data) =>
  {
    this.rightSelected =  data;
  }
  
  leftDoubleClicked =(data) => {
	if(undefined!=data[0][this.props.keyField]){
    this.leftListChanged(data);
    this.moveRight();
	}
  }
  
  rightDoubleClicked =(data) => {
	if(undefined!=data[0][this.props.keyField]){
    this.rightListChanged(data);
    this.moveLeft();
	}
  }
  
  componentWillReceiveProps(nextProps) {
	    this.props = nextProps;
	    let newSelectedOption = this.state.selectedOptions;
	    this.state = this.getInitState(nextProps);
	    this.setState({selectedOptions: newSelectedOption});
	    this.intitialize();
	  }
 
  render() {    
    const {rightListData, leftListData} = this.state;
    let{leftCaption, rightCaption, displayField, keyField, size, leftFilter, rightFilter, enableSort, sortOrder} = this.props;
    		return (
     
        <HorizontalLayout>
          <VerticalLayout>
             <FlexPanel style={{marginTop: '33%'},{marginBottom: '10%'}}>
                <FilteredMultiselect enableSort={enableSort} sortOrder={sortOrder} caption={leftCaption} showFilter={leftFilter} onChange ={this.leftListChanged} options={leftListData} displayField={displayField} valueField={keyField} selectedOptions={[]} onDoubleClick={this.leftDoubleClicked} size={size}/> 
            </FlexPanel>
          </VerticalLayout>
           <FixedPanel style={{paddingTop: '6%', paddingLeft: '2%', marginRight: '2%'}}>
            <ButtonGroup vertical style={{marginTop: '45%'}}>
              <Button onClick={this.moveRight} style={{marginBottom: '40%', padding : '8px 10px'}}><Icon fa='caret-right' /></Button> 
              <Button onClick={this.moveLeft} style={{padding : '8px 10px'}}><Icon fa='caret-left' /></Button>         
            </ButtonGroup>
          </FixedPanel>
          <VerticalLayout>
          <HorizontalLayout  style={{backgroundColor: 'rgba(204, 204, 204, 1)', marginTop: '17%', width: '100%', height: '30px'}}>
          		<Input label={rightCaption} labelClassName="col-sx-1" style={{ fontSize:'90%', paddingLeft: '3%', marginBottom: '0%', width: '81%'}} /> 
		        <ButtonGroup horizontal style={{marginTop: '1%', width: '19%', marginLeft: '1%'}}>
		            <Button onClick={this.orderItems.bind(this,'UP')} style={{padding : '1px 6px', marginRight: '8%'}}><Icon fa='caret-up' /></Button> 
		            <Button onClick={this.orderItems.bind(this,'DOWN')} style={{padding : '1px 6px'}}><Icon fa='caret-down' /></Button> 
		        </ButtonGroup>
          </HorizontalLayout>
             <FlexPanel style={{marginBottom: '0%'}}>
                <FilteredMultiselect showFilter={rightFilter} onChange ={this.rightListChanged} options={rightListData} 
                displayField={displayField} valueField={keyField}  selectedOptions={this.state.selectedOptions} onDoubleClick={this.rightDoubleClicked} size={size}/>
            </FlexPanel>
          </VerticalLayout>
       </HorizontalLayout>
   
    )
  }
}
