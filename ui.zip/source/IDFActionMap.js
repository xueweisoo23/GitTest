/**
 * @author p530579
 * 
 * File to define all the service calls, any service calls should be defined here,
 * so its one place to check if the service can be re-used  
 * 
 */

export const idfActionMap = {
  customizeViewData : {name:'customizeViewData', idfNumber: 913600003},
  //linkData: 'linkData'
  
};