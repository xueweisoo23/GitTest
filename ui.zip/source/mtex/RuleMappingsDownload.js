import React,{Component, PropTypes, Form} from 'react';
import { connect } from 'react-redux';
import * as _sutils from './sharedutils.js';


/**
 *  @author p588129
 **/
 export default class RuleMappingsDownload extends Component {
	 static propTypes = {
		 actionPath: PropTypes.string.isRequired,
	        method: PropTypes.string,
	        onDownloadComplete: PropTypes.func,
	        FILE_DEF_ID:PropTypes.string,
	        CLIENT_ID:PropTypes.string,
	        SENDER_APP_CD:PropTypes.string
	 };
	 
	 static defaultProps = {
	        method: 'POST'
	    };
	    
	    constructor(props) {
	        super(props);
	      }
	     
	      componentWillMount() {
	      }
	      componentDidMount() {
	          this.refs.Test.submit();
	          this.props.onDownloadComplete();
	      }
	      render() {
		    	let {FILE_DEF_ID,CLIENT_ID,SENDER_APP_CD,actionPath,method} = this.props;

		        return (
		        		<div>
				           <form ref='Test' className='hidden' action = {actionPath} method={method}>
				            <input name="FILE_DEF_ID" value={FILE_DEF_ID} />
				            <input name="CLIENT_ID" value={CLIENT_ID} />" +
				            <input name="SENDER_APP_CD" value={SENDER_APP_CD} />
				           </form>
		                </div>
		        );
	      }
 }