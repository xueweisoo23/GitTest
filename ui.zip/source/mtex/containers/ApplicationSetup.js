import React, {Component,PropTypes} from 'react';
import {Button} from 'react-bootstrap';
import {DynamicDataGrid,HorizontalLayout,FixedPanel,FlexPanel,VerticalLayout } from 'ssc-cdt3';
import { connect } from 'react-redux';
import * as _service from '../service';
import * as _actionCreators from '../redux/ActionCreators'; 
import { bindActionCreators } from 'redux'
import * as _sutils from '../sharedutils';



import { Link } from 'react-router';

const columnConfig = [{
	  dataKey: 'FILE_ID',
	  label: 'File ID',
	  width: 250,
	  dataType: 'string',
	},{
	  dataKey: 'COL_NM',
	  label: 'Column Name',
	  width: 200,
	  dataType: 'string',
		
	}, {
	  dataKey: 'COL_VAL',
	  label: 'Column Value',
	  width: 200,
	  dataType: 'string',
	}, {
	  dataKey: 'EXCEPTION_TXT',
	  label: 'Exception',
	  width: 700,
	  dataType: 'string',
		
	}, {
	  dataKey: 'MAPPING_RULE_ID',
	  label: 'Mapped Rule ID',
	  width: 150,
	  dataType: 'string',
	},{
	  dataKey: 'UID',
	  label: 'UID',
	  width: 120,
	  dataType: 'string',
    hidden: true
	}];

function mapStateToProps(state) {
  return {
	 //showFileUploadModalWindow : (state.modalWindow.FILE_UPLOAD?state.modalWindow.FILE_UPLOAD:false),
  }
}

@connect(mapStateToProps, function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
})

export default class ApplicationSetup extends Component {
  
  static contextTypes = {
		router: React.PropTypes.object.isRequired,
	}
  
  
  constructor(props) {
    super(props);
		this.state={editRow: undefined,editErrors: undefined, checkedRows: []}
  }

onCheck = (checked) => {
    this.setState({checkedRows: checked});
  }
	 addNew = () => {
    this.modifiedRow = {};
    this.setState({editRow: {}, editErrors: undefined});
  }

remove = () => {
    const {checkedRows} = this.state;
    this.gridActions.delete(checkedRows).then((ret) => {
      if (ret.error) {
        this.gridActions.error('Error', ret.payload._error || 'Error deleting items.');
      } else {
        this.gridActions.success('Success', 'Deleted row(s).');
        this.setState({editRow: undefined, editErrors: undefined, checkedRows: []});
      }
    });
  }

	
	onRowDoubleClick = (row) => {
    this.modifiedRow = {...row}; // clone for new values
    this.setState({editRow: row, editErrors: undefined});
  }
  
  connectCallback = (gridActions) => {
    this.gridActions = gridActions;
     _service.makeCallWithHandlers(gridActions,_service.CALL_TYPE_LOADLIST,{},null,null,undefined,this.props) ; 
  }

  componentWillMount() {
   _sutils.doCheckforEntitlement(this,true)
  }

  componentWillReceiveProps(props) {
//   if(this.gridActions && props.refreshGrid && this.props.refreshGrid!==props.refreshGrid)
//      this.connectCallback(this.gridActions)  
  }
  

modalClosedCallback = (btnType,id)=> {   
		console.log('id:'+id+':btnType:'+btnType);
		// this.setState({showFileUploadDialog:false});
	 }

 onChange = (value, column) => {
    const {editErrors = {}} = this.state;
    if (!value) {
      this.setState(
        {editErrors: {...editErrors, [column.dataKey]: `${column.label} is required.`}
      });
    } else {
      this.modifiedRow[column.dataKey] = value;
      this.setState({
        editRow: {...this.modifiedRow},
        editErrors: {...editErrors, [column.dataKey]: undefined}
      });
    }
    return true;
  }

	onKeyDown = (e) => {
    switch (e.keyCode) {
      case 13: // enter key
        if (typeof this.modifiedRow['ID'] === 'undefined') {
          this.add();
        } else {
          this.update();
        }
        break;
      case 27: // escape key
        e.preventDefault();
        e.stopPropagation();
        this.setState({editRow: undefined});
        break;
      default:
        break;
    }
  }

	update = () => {
    if (this.validate()) {
      this.gridActions.update(this.modifiedRow).then((ret) => {
        if (ret.error) {
          this.gridActions.error('Error', ret.payload._error || 'Please correct errors.');
          this.setState({editErrors: ret.payload});
        } else {
          this.gridActions.success('Success', 'Update was successful.');
          this.setState({editRow: undefined});
        }
      });
    }
  }

  add = () => {
    if (this.validate()) {
      const empName = `${this.modifiedRow.FIRST_NAME} ${this.modifiedRow.LAST_NAME}`;
      this.gridActions.addNew(this.modifiedRow).then((ret) => {
        if (ret.error) {
          this.gridActions.error('Error', ret.payload._error || 'Please correct errors.');
          this.setState({editErrors: ret.payload});
        } else {
          this.gridActions.success('Success', `New record inserted!`);
          this.setState({editRow: undefined});
        }
      });
    }
  }

validate() {
    // plug in any validation framework here
    const errors = {};
    if (!this.modifiedRow.TRANSLATION_TYPE) {
      errors.TRANSLATION_TYPE = 'Translation Type is required';
    }
    if (!this.modifiedRow.INPUT) {
      errors.INPUT = 'Input is required';
    }

		if (!this.modifiedRow.OUTPUT) {
      errors.OUTPUT = 'Output is required';
    }
    this.setState({editErrors: errors}); 
    return Object.keys(errors).length === 0;
  }

	
  render() {
debugger;
	let {checkedRows} = this.state;
	let enableDelete = false;//checkedRows && checkedRows.length > 0;
	let enableAdd = typeof editRow === 'undefined';
					   
    return (

<HorizontalLayout>
       <VerticalLayout flex='flex' onKeyDown={this.onKeyDown}> 
       <FixedPanel style={{overflow: 'visible'}}>
			 <h3 style={{marginTop: 0,marginBottom: 0,width: 260}}> <strong>Application Setup</strong></h3>
			  <div style={{display: 'inline-block', float: 'right'}}>
			  <Button className='btn btn-primary btn-xs' style={{marginRight: 8}}
              disabled={!enableAdd} onClick={this.addNew} >Add</Button>
            </div>
     </FixedPanel>
     <FlexPanel>
      <DynamicDataGrid
		columns={columnConfig}
        dataIdf={553840006}
        gridConnectCallback={this.connectCallback}
        componentId='exceptionGrid'
        keyFieldName='UID'
				editRow={this.state.editRow}
				onRowDoubleClick={this.onRowDoubleClick}
				onChange={this.onChange}
				editErrors={this.state.editErrors}
        onCheckedChange={this.onCheck}
        scale ={1}
				pageSize={50}
        excelExport
      	csvExport
				hasCheckbox
      /> 
      </FlexPanel>
			</VerticalLayout>
		
			</HorizontalLayout>

    );
  }
}



