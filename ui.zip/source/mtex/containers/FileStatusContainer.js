import React, { Component, PropTypes } from 'react';
import { Button, FormControl, ControlLabel, FormGroup, Form } from 'react-bootstrap';
import DatePicker from 'react-bootstrap-date-picker';
import { DynamicDataGrid, HorizontalLayout, FixedPanel, FlexPanel, VerticalLayout, connectCdtDataComponent, Icon } from 'ssc-cdt3';
import { connect } from 'react-redux';
import * as _service from '../service';
import ModalWindow from '../components/ModalWindow';
import * as _actionCreators from '../redux/ActionCreators';
import { bindActionCreators } from 'redux'
import { AppNameEditor } from '../celleditors/AppNameEditor';
import TextboxEditor from '../celleditors/TextboxEditor';
import { DelimiterEditor } from '../celleditors/DelimiterEditor';
import { FileTypeEditor } from '../celleditors/FileTypeEditor';
import { ClientEditor } from '../celleditors/ClientEditor';
import * as _sutils from '../sharedutils';
import ClientSelectionHeader from '../components/ClientSelectionHeader';
import { FILE_STATUS_COLUMNS } from '../shared/ColumnConfigs';
import { Link } from 'react-router';
import FileDownload from '../FileDownload';

function mapStateToProps(state) {
  return {
    showHelpModalWindow: (state.modalWindow.HELP_WINDOW ? state.modalWindow.HELP_WINDOW : false),
    showFailureLogsWindow: (state.modalWindow.FAILURE_LOGS? state.modalWindow.FAILURE_LOGS: false),
    showFileUploadModalWindow: (state.modalWindow.FILE_UPLOAD ? state.modalWindow.FILE_UPLOAD : false),
    selectedClient: state.clients.selectedClient,
    isClientSelectionChanged: state.clients.isClientSelectionChanged,
    helpData: state.help.helpData,
  }
}

@connect(mapStateToProps, function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
})
@connectCdtDataComponent('fileStatus', 553840007)
@connectCdtDataComponent('statusValues', 553840008)
@connectCdtDataComponent('exception', 553840006)
export default class FileStatusContainer extends Component {

  static contextTypes = {
    router: React.PropTypes.object.isRequired,
  }

  static propTypes = {
    fileStatus: PropTypes.object,
    fileStatusActions: PropTypes.object,
    statusValues: PropTypes.object,
    statusValuesActions: PropTypes.object,
  }


  constructor(props) {
    super(props);  
    this.state = {
      selectedRow: undefined, filterInputs: {
        fromDate: { value: this.getTodayISOFormat(), formatted: this.getTodayDefaultFormat() },
        toDate: { value: this.getTodayISOFormat(), formatted: this.getTodayDefaultFormat() }, filterStatus: ''
      }, isDownloaded: false, fileContent: undefined, errorLog: undefined
    };

    this.columns = [
      {
        dataKey: 'LOADID',
        width: 70,
        label: '',
        dataType: 'string',
        menu: false,
        fixed: true,
        sort: false,
        filter: false,
        locked: true,
        cell: (cellProps) => {
          return (
            <div style={{ paddingLeft: '8px', paddingTop: '4px' }}>

            <Icon title= 'Download input file' fa='arrow-circle-down' onClick={() =>this.downloadInputFile(cellProps.row)} style={{cursor:'pointer'}}/> | <Icon title= 'Download transformed file' style={{cursor:'pointer',color:'green'}} fa='arrow-circle-down' onClick={() =>this.downloadTransFormedFile(cellProps.row)} /> | <Icon title= 'Download failed file' style={{cursor:'pointer',color:'red'}} fa='arrow-circle-down' onClick={() =>this.downloadErrorFile(cellProps.row)} />
            </div>
          );

        }
      },
      ...FILE_STATUS_COLUMNS  // append the rest of the editColConfig columns
    ];

    this.load_Id = null;
    this.file_name = null;
  }

  
  downloadErrorFile=(row) =>
  {
	  var {ERR_FILE_LOAD_ID, OUTPUT_FILE_NM} = row;
    OUTPUT_FILE_NM = OUTPUT_FILE_NM.substr(0,OUTPUT_FILE_NM.lastIndexOf("."))+"_Exception.csv";

	  if (ERR_FILE_LOAD_ID != null && ERR_FILE_LOAD_ID.trim() != "") {
		  this.load_Id = ERR_FILE_LOAD_ID;
	      this.file_name = OUTPUT_FILE_NM;
	      console.log('error file Load_id :->' + this.load_Id + 'File_Name :->' + this.file_name);
	      this.setState({ isDownloaded: true });
	    }
	    else
	      this.gridActions.error('Error', 'Load_Id is not available');
  }
  downloadInputFile = (row) => {
    const {INPUT_FILE_LOAD_ID, FILE_NM} = row;
    if (INPUT_FILE_LOAD_ID != null && INPUT_FILE_LOAD_ID.trim() != "") {
      //  window.location = 'DEHFileDownloadServlet?LOAD_ID='+INPUT_FILE_LOAD_ID+'&FILE_NAME='+FILE_NM;
      this.load_Id = INPUT_FILE_LOAD_ID;
      this.file_name = FILE_NM;
      console.log('Input file Load_id :->' + this.load_Id + 'File_Name :->' + this.file_name);
      this.setState({ isDownloaded: true });
    }
    else
      this.gridActions.error('Error', 'Load_Id is not available');
  }

  loadIdSuccessHandler = (ret, actions, spinJobId) => {
    this.gridActions.success('Success', 'File downloaded successfully');
  }

  downloadTransFormedFile = (row) => {
    const {TRANSFORMED_FILE_LOAD_ID, OUTPUT_FILE_NM} = row;

    if (TRANSFORMED_FILE_LOAD_ID != null && TRANSFORMED_FILE_LOAD_ID.trim() != "") {
      // window.location = 'DEHFileDownloadServlet?LOAD_ID='+TRANSFORMED_FILE_LOAD_ID+'&FILE_NAME='+OUTPUT_FILE_NM;
      this.load_Id = TRANSFORMED_FILE_LOAD_ID;
      this.file_name = OUTPUT_FILE_NM;
      console.log('Transformed file Load_id :->' + this.load_Id + 'File_Name :->' + this.file_name);
      this.setState({ isDownloaded: true });
    }
    else
      this.gridActions.error('Error', 'Load_Id is not available');
  }

  onCheck = (checked) => {
    this.setState({ checkedRows: checked });
  }


  getTodayISOFormat = () => {
    return new Date(Date.now()).toISOString();
  }

  getTodayDefaultFormat = () => {
    let todayTime = new Date(Date.now());
    return (todayTime.getMonth() + 1) + '/' + todayTime.getDate() + '/' + todayTime.getFullYear();
  }

  connectCallback = (gridActions, fromDate, toDate, filterStatus, clientId) => {
    this.gridActions = gridActions;
    if (!clientId)
      clientId = _sutils.getSelectedClientId();

    if (fromDate && toDate && filterStatus && clientId)
      _service.makeCallWithHandlers(gridActions, _service.CALL_TYPE_LOADLIST, { FILTER_FROM_DATE: fromDate, FILTER_TO_DATE: toDate, FILTER_STATUS: filterStatus, CLIENT_ID: clientId }, null, null, undefined, this.props);
}

  reprocessSuccessHandler = (ret, actions, spinJobId) => {
    if (ret.error)
      actions.error('Error', ret.payload._error || 'Error in reprocess');
    else {
      let {filterInputs} = this.state;
      this.connectCallback(this.gridActions, filterInputs.fromDate.formatted, filterInputs.toDate.formatted, filterInputs.filterStatus);
      actions.success('Success', 'File marked for reprocess!');
    }

  }


  componentWillMount() {
    if (_sutils.doCheckforEntitlement(this, true))
      this.loadStatusValueList();
  }

  componentDidMount() {
    if (!this.isBackMode()) {
      let {filterInputs} = this.state;
      this.connectCallback(this.gridActions, filterInputs.fromDate.formatted, filterInputs.toDate.formatted, 'ERROR');
    }

    if (undefined != this.props.location && undefined != this.props.location.query &&
      undefined != this.props.location.query.downloadFailed && this.props.location.query.downloadFailed == 'true') {
      this.gridActions.error('Error', 'File Download has failed.');
      this.context.router.push({ pathname: '/filestatus' });
    }
  }

  isBackMode = () => {
    if (this.props.location && this.props.location.state && this.props.location.state.params
      && this.props.location.state.params.isBackMode) {
      const filterInputs = this.props.location.state.params.filterInputs;
      this.setState({ filterInputs },
        this.connectCallback(this.gridActions, filterInputs.fromDate.formatted, filterInputs.toDate.formatted, filterInputs.filterStatus, undefined));
      return true;
    }
    return false;
  }

  componentWillReceiveProps(props) {
    if (this.props.selectedClient.CODE_VALUE !== props.selectedClient.CODE_VALUE && props.isClientSelectionChanged){
        this.setState({ selectedRow: undefined });
        this.search(props.selectedClient.CODE_VALUE);
    }
  }


  modalClosedCallback = (btnType, id) => {
    console.log('id:' + id + ':btnType:' + btnType);
  }

  showHelpWindow = () => {
    let {helpData} = this.props;
    helpData.map((obj) => {
      if (obj.HELP_DEF_ID == "FILE_STATUS") {
        this.setState({ fileContent: { __html: obj.FILE_CONTENT } });
      }
    });
    this.props.actions.showModalWindow('HELP_WINDOW'); 
  }


  validate() {
    // plug in any validation framework here
    const errors = {};

    if (!this.modifiedRow.CLIENT_NM)
      errors.CLIENT_NM = 'Client  is required';

    if (!this.modifiedRow.SENDER_APP_NM)
      errors.SENDER_APP_NM = 'Sender App is required';

    if (!this.modifiedRow.FILE_DEF_ID)
      errors.FILE_DEF_ID = 'File Definition ID is required';


    this.setState({ editErrors: errors });
    return Object.keys(errors).length === 0;
  }

  viewExceptions = () => {
    const {FILE_ID} = this.state.selectedRow;
    let params = { fileId: FILE_ID, fileStatusFilter: this.state.filterInputs };
    this.context.router.push({ pathname: '/viewexception', state: { params: params } });
  }

  viewFailureLogs=()=>{
    this.props.actions.showModalWindow('FAILURE_LOGS'); 
  }

  onRowClick = (row) => {
    this.setState({ selectedRow: row, errorLog:row.ERROR_LOG });
  }

  fromDateChanged(obj, value, formattedDisplay) {
    let {filterInputs} = this.state;
    this.setState({ filterInputs: { fromDate: { value: value, formatted: formattedDisplay }, toDate: filterInputs.toDate, filterStatus: filterInputs.filterStatus } });
  }

  toDateChanged(obj, value, formattedDisplay) {
    let {filterInputs} = this.state;
    this.setState({ filterInputs: { toDate: { value: value, formatted: formattedDisplay }, fromDate: filterInputs.fromDate, filterStatus: filterInputs.filterStatus } });
  }

  statusChanged = (e) => {
    let {filterInputs} = this.state;
    this.setState({ filterInputs: { toDate: filterInputs.toDate, fromDate: filterInputs.fromDate, filterStatus: e.target.value } });
  }

  loadStatusValueList = () => {
    _service.makeCallWithHandlers(this.props.statusValuesActions, _service.CALL_TYPE_LOADLIST, { CALL_TYPE: 'FILE_STATUS' }, this.statusSuccessCallback, null, undefined, this.props);
  }
  statusSuccessCallback = (ret, actions, spinJobId) => {
    if (ret.payload.data && ret.payload.data.length > 0) {
      let {filterInputs} = this.state;
      this.setState({ filterInputs: { toDate: filterInputs.toDate, fromDate: filterInputs.fromDate, filterStatus: ret.payload.data[0].CODE_VALUE } });
    }
  }
  search = (clientId) => {
    this.setState({ selectedRow: undefined });
    let {filterInputs} = this.state;
    if (this.doValidation(filterInputs))
      this.connectCallback(this.gridActions, filterInputs.fromDate.formatted, filterInputs.toDate.formatted, filterInputs.filterStatus, clientId);
  }

  doValidation = (filterInputs) => {
    if (filterInputs.fromDate.formatted == '' || filterInputs.toDate.formatted == '' || filterInputs.filterStatus == '')
      return false;

    return true;
  }

  reprocess = () => {
    const {FILE_ID} = this.state.selectedRow;
    _service.makeCallWithHandlers(this.props.exceptionActions, _service.CALL_TYPE_UPDATE, { FILE_ID }, this.reprocessSuccessHandler, _sutils.defaultErrorHandler.bind(this), undefined, this.props);
  }

  downLoadCompleteCallBack = () => {
    this.setState({ isDownloaded: false });
  }

  render() {
    const {checkedRows, selectedRow, errorLog, fileContent} = this.state;
    const {data} = this.props.statusValues;
    const enableExceptionButton = selectedRow && (selectedRow.STATUS_CD == 'EXCEPTION' || selectedRow.STATUS_CD == 'DELIVERY_FAILED' || selectedRow.STATUS_CD == 'FAILED_PROCESSING');
    const enableViewFailureLog = selectedRow && (selectedRow.STATUS_CD == 'FAILED' || selectedRow.STATUS_CD == 'DELIVERY_FAILED' || selectedRow.STATUS_CD == 'FAILED_PROCESSING');

    const FILE_DOWNLOAD = <FileDownload LOAD_ID={this.load_Id} FILE_NAME={this.file_name}
      actionPath={'DEHFileDownloadServlet'} method={'POST'} onDownloadComplete={this.downLoadCompleteCallBack} />;

    let HELP_WINDOW = <ModalWindow id={'HELP_WINDOW'} modalHeader={'Help'} buttons={[]} showModalWindow={this.props.showHelpModalWindow}
      modalCloseCallback={this.modalClosedCallback}>
      <VerticalLayout flex='flex' style={{ width: '100%' }}>
        <span dangerouslySetInnerHTML={fileContent}></span>
      </VerticalLayout>
    </ModalWindow>;

    let FAILURE_LOGS = <ModalWindow id={'FAILURE_LOGS'} modalHeader={'Failure Logs'} buttons={[]} showModalWindow={this.props.showFailureLogsWindow}
      modalCloseCallback={this.modalClosedCallback}>
      <VerticalLayout flex='flex' style={{ width: '100%' }}>
        <span>{errorLog}</span>
      </VerticalLayout>
    </ModalWindow>;
    
    return (

      <HorizontalLayout>
        <ClientSelectionHeader />
        <VerticalLayout flex='flex'>
          <FixedPanel style={{ overflow: 'visible' }}>
            <h3 style={{ marginTop: 0, marginBottom: 0, width: 260 }}> <strong>File Status</strong><strong className=' fa fa-question-circle' style={{ color: '#286090', fontSize: 24, marginLeft: 10,cursor:'pointer'  }}
              onClick={this.showHelpWindow.bind(this)} ></strong></h3>
          </FixedPanel>


          <Form inline>
            <FormGroup bsSize="small">

              <label>Date From:   </label> <DatePicker value={this.state.filterInputs.fromDate.value} placeholder="Enter from date" onChange={this.fromDateChanged.bind(this, this)} />
              <label>&nbsp;&nbsp;&nbsp;&nbsp;To:&nbsp;</label>
              <DatePicker value={this.state.filterInputs.toDate.value} placeholder="Enter to date" onChange={this.toDateChanged.bind(this, this)} />
              <label>&nbsp;&nbsp;&nbsp;&nbsp;{'Status'}:&nbsp;</label>
              <FormControl componentClass="select" placeholder="select" onChange={this.statusChanged}>
                {
                  (() => {
                    if (data && data.length > 0) {
                      return data.map((x) => {
                        return <option value={x.CODE_VALUE} key={x.CODE_VALUE}>{x.LABEL}</option>
                      })
                    }
                  })()
                }
              </FormControl>
              <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
              <Button className='btn btn-primary btn-xs' style={{ marginRight: 8 }} onClick={this.search.bind(this, undefined)} >Search</Button>
            </FormGroup>
          </Form>

          <FixedPanel style={{ overflow: 'visible' }} >
            <div style={{ display: 'inline-block', float: 'right' }}>
              <Button className='btn btn-primary btn-xs' style={{ marginRight: 8, display: enableViewFailureLog?'inline':'none' }} disabled={!enableViewFailureLog && !enableExceptionButton} onClick={this.viewFailureLogs}>View Failure Logs</Button>
              <Button className='btn btn-primary btn-xs' style={{ marginRight: 8 }} disabled={!enableExceptionButton} onClick={this.viewExceptions} >View Exceptions</Button>
              <Button className='btn btn-primary btn-xs' style={{ marginRight: 8 }} disabled={!enableExceptionButton} onClick={this.reprocess}>Reprocess</Button>

            </div>
          </FixedPanel>


          <FlexPanel>
            <DynamicDataGrid
              columns={this.columns}
              dataIdf={553840007}
              gridConnectCallback={this.connectCallback}
              componentId='fileStatusGrid'
              keyFieldName='KEY_ID'
              onRowClick={this.onRowClick}
              scale={1}
              pageSize={50}
              excelExport
              csvExport
              />
          </FlexPanel>
          {HELP_WINDOW}
          {FAILURE_LOGS}
        </VerticalLayout>
        {this.state.isDownloaded && FILE_DOWNLOAD}
      </HorizontalLayout>

    );
  }
}
