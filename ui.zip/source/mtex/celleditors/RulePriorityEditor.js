import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {DropdownList} from 'react-widgets';
import {connectCdtDataComponent} from 'ssc-cdt3';
import * as _service from '../service'
import {OverlayTrigger, Popover} from 'react-bootstrap';
import {DropdownEditor} from './DropdownEditor';

@connectCdtDataComponent('rulePriorityData',553840008)
export class RulePriorityEditor extends Component { 
  static propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    col: PropTypes.object,
    row: PropTypes.object,
    bottomOffset: PropTypes.number,
    rowHeight: PropTypes.number,
    rulePriorityData: PropTypes.object,
    rulePriorityDataActions: PropTypes.object,
  }

  constructor(props) {
    super(props);
    const {value} = props;
    this.state = {value};
  }

  onChange = (val) => {

    if (this.props.onChange(val, this.props.col)) {
        //this.props.onChange('true', {dataKey: 'IS_DELIVERY_PREF_UPDATED'});
        this.setState({value: val});
    }
  }
   componentDidMount() {
     _service.makeCallWithHandlers(this.props.rulePriorityDataActions,_service.CALL_TYPE_LOADLIST,{CALL_TYPE:'RULE_PRIORITY'},null,null,undefined,this.props) 
  }

  render() {
    const {col,error,rulePriorityData,row, bottomOffset, rowHeight} = this.props;
    return (
    <DropdownEditor value={this.state.value} onChange={this.onChange} col={col} row={row} bottomOffset={bottomOffset} rowHeight={rowHeight}
                    dropdownValues={rulePriorityData} error ={error}>
    </DropdownEditor>   
    );
  }
}
