import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {DropdownList} from 'react-widgets';
import {connectCdtDataComponent} from 'ssc-cdt3';
import * as _service from '../service';
import * as _sutils from '../sharedutils'
import {OverlayTrigger, Popover} from 'react-bootstrap';
import {DropdownEditor} from './DropdownEditor';
import * as _actionCreators from '../redux/ActionCreators'; 
import { bindActionCreators } from 'redux'

function mapStateToProps(state) {
  return {
   selectedClient:state.clients.selectedClient,
   isClientSelectionChanged:state.clients.isClientSelectionChanged,
  }
}

@connect(mapStateToProps, function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
})
@connectCdtDataComponent('appDetails',553840008)
export class AppNameEditor extends Component { // Refactor later to generic component and inherit for specific functions
  static propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    col: PropTypes.object,
    row: PropTypes.object,
    bottomOffset: PropTypes.number,
    rowHeight: PropTypes.number,
    appDetails: PropTypes.object,
	  appDetailsActions: PropTypes.object,
  }

  constructor(props) {
    super(props);
    const {value} = props;
    this.state = {value};
  }

componentWillReceiveProps(props) {
    console.log(this.props);
    if(this.props.selectedClient.CODE_VALUE !== props.selectedClient.CODE_VALUE && props.isClientSelectionChanged)
    		this.callService();
  }

  callService =()=>{
    let clientId = _sutils.getSelectedClientId();
    _service.makeCallWithHandlers(this.props.appDetailsActions,_service.CALL_TYPE_LOADLIST,{CALL_TYPE:'APP_DETAILS',FILTER1:clientId},null,null,undefined,this.props)
  }
  onChange = (val) => {

    if (this.props.onChange(val, this.props.col)) {
      if(this.props.col.dataKey==='SENDER_APP_NM')
        this.props.onChange('true', {dataKey: 'IS_SENDER_APP_UPDATED'});
      else if(this.props.col.dataKey==='RECIEVER_APP_NM')
        this.props.onChange('true', {dataKey: 'IS_RECIEVER_APP_UPDATED'});

      this.setState({value: val});
    }
  }
   componentDidMount() {
      this.callService();
  }

  render() {
    const {col,error,appDetails,row, bottomOffset, rowHeight} = this.props;
     appDetails.data=  appDetails.data.filter((arr,index,self)=>{
        return  index === self.findIndex((t)=>(t.LABEL === arr.LABEL))
    });
    return (
    <DropdownEditor value={this.state.value} onChange={this.onChange} col={col} row={row} bottomOffset={bottomOffset} rowHeight={rowHeight}
                    dropdownValues={appDetails} error ={error}>
    </DropdownEditor>   
    );
  }
}
