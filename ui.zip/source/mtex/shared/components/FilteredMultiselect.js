import React, {Component, PropTypes} from 'react';
import {VerticalLayout, FlexPanel, FixedPanel, HorizontalLayout} from 'ssc-cdt3';
import {Input} from 'react-bootstrap';
/**
 * @author p530579
 * Component to be used for the multiselect listbox with the filter option on the top
 * 
 */
const divStyle = {
		 position: 'relative',
};

const divStyleI ={
		position: 'absolute',
		right: 10,
		top: 10,
		color: '#efefef'
};
	  
export default class FilteredMultiselect extends Component {
  
  static propTypes = {
    onChange: PropTypes.func.isRequired,
    options: PropTypes.array.isRequired, 
    displayField: PropTypes.string.isRequired,
    valueField: PropTypes.string.isRequired,
    selectedOptions: PropTypes.array.isRequired,
    
    buttonText: PropTypes.string,
    className: PropTypes.string,
    classNames: PropTypes.object,
    defaultFilter: PropTypes.string,
    disabled: PropTypes.bool,
    placeholder: PropTypes.string,
    size: PropTypes.number,
    onDoubleClick: PropTypes.func,
    showFilter: PropTypes.bool,
    caption: PropTypes.string,
    enableSort: PropTypes.bool,
    sortOrder:PropTypes.string
  }
  
  static defaultProps = {
		  defaultFilter: '',
      placeholder: 'Type to filter...',
      size: 4,
      selectedOptions: [],
      displayField: 'text',
      valueField: 'value',
      disabled: false,
      showFilter:true,
      caption:'Select Item(s)',
      enableSort:false,
      sortOrder: 'ASC'
	 } 
  

  constructor(props)
  {
     super(props);
     this.state = this.initializeState();
     this.sortOrder = 'ASC';
  }
  
  initializeState() {
    let {defaultFilter,selectedOptions} = this.props
    return {
      filter: defaultFilter,
      filteredOptions: this.filterOptions(defaultFilter, selectedOptions),
      selectedValues: this.initialSelectedValus(selectedOptions)
    }
  }
  
  initialSelectedValus = (selectedOptions)=> {
    let selectedVal=[];
    for(let i=0; i<selectedOptions.length; i++){
      selectedVal.push(selectedOptions[i][this.props.valueField]);  
    }
    return selectedVal;
  }
  
   filterOptions=(filter, selectedOptions, options)=>{
    if (typeof filter == 'undefined') {
      filter = this.state.filter
    }
    if (typeof selectedOptions == 'undefined') {
      selectedOptions = this.props.selectedOptions;
    }
    if (typeof options == 'undefined') {
      options = this.props.options
    }
    filter = filter.toUpperCase()
    let {displayField, valueField} = this.props
    let selectedValueLookup = this.lookupData(selectedOptions, valueField)
    let filteredOptions = []

    for (let i = 0, l = options.length; i < l; i++) {
      if (!filter || options[i][displayField].toUpperCase().indexOf(filter) !== -1) {
        filteredOptions.push(options[i]) 
      }
    }

    return filteredOptions
  }

  
lookupData(arr, prop) {
  let lkup = {}
  for (let i = 0, l = arr.length; i < l; i++) {
    if (prop) {
      lkup[arr[i][prop]] = true
    }
    else {
      lkup[arr[i]] = true
    }
  }
  return lkup
}

lookupSpecificData(arr, prop,val) {
  let lkup = {}
  for (let i = 0, l = arr.length; i < l; i++) {
    if (arr[i][prop]==val) {
      lkup = arr[i];
      break;
    }
  }
  return lkup
}

componentDidMount(){
	if(this.props.enableSort){
	this.sortOrder==this.props.sortOrder;
	this.sortItems();
	}
}

componentWillReceiveProps(nextProps) {
    this.props = nextProps;
     this.state = this.initializeState();
     if(this.props.enableSort){
    		this.sortOrder==this.props.sortOrder;
    		this.sortItems();
    		}
  }
  
   onFilterChange= (e)=> {
    let filter = e.target.value
    this.setState({
      filter,
      filteredOptions: this.filterOptions(filter)
    }, this._updateSelectedValues)
  }
  
   onFilterKeyPress = (e)=> {
    if (e.key === 'Enter') {
      e.preventDefault()
      if (this.state.filteredOptions.length === 1) {
        let selectedOption = this.state.filteredOptions[0]
        let selectedOptions = this.props.selectedOptions.concat([selectedOption])
        this.setState({filter: '', selectedValues: []}, () => {
          this.props.onChange(selectedOptions)
        })
      }
    }
  }
  
    updateSelectedValues = (e) => {
    let el = e ? e.target : this.refs.select
    let selectedValues = [];
    let selectedOptions = []
    for (let i = 0, l = el.options.length; i < l; i++) {
      if (el.options[i].selected) {
        let selVal = el.options[i].value;
        let obj = this.lookupSpecificData(this.props.options, this.props.valueField,selVal)
        selectedValues.push(selVal);
        selectedOptions.push(obj);
      }
    }
  
    if (e || String(this.state.selectedValues) !== String(selectedValues)) {
      this.setState({selectedValues})
    }
     this.props.onChange(selectedOptions);
  }
  
  handleDoubleClick = (e) => {
  let el = e ? e.target : this.refs.select
  let selectedValues = [];
  let selVal = el.value;
  selectedValues.push(this.lookupSpecificData(this.props.options, this.props.valueField,selVal));
  
    if(this.props.onDoubleClick)
      this.props.onDoubleClick(selectedValues);  
  } 
  
  /*Below method will sort the available entity groups in left side of Multi Select box*/
  sortItems = () =>{
	  let sortField = this.props.displayField;
	  let filteredOptions = this.state.filteredOptions;
	  if(undefined!=filteredOptions && filteredOptions.length>1){
	     if(this.sortOrder=='ASC'){
	   		  filteredOptions = filteredOptions.sort(function(a,b){			 	  
			  let aTxt = a[sortField].toUpperCase();
			  let bTxt = b[sortField].toUpperCase();
	  		  return (aTxt< bTxt) ?-1:(aTxt > bTxt)?1:0
	  		  });	  	  
	  	  this.sortOrder = 'DSC';
	    }else{
		  filteredOptions = filteredOptions.sort(function(a,b){	  		  
			  let aTxt = a[sortField].toUpperCase();
		  	  let bTxt = b[sortField].toUpperCase();
	  		  return (aTxt< bTxt) ?1:(aTxt > bTxt)?-1:0
	  		  });
	  	  this.sortOrder = 'ASC';
	    }
	     this.setState({filteredOptions:filteredOptions});
	  }
  }
  
render() {
    let {filter, filteredOptions, selectedValues} = this.state;
    let {disabled, placeholder, size, displayField, valueField,showFilter,caption} = this.props;  
    let hasSelectedOptions = selectedValues.length > 0;
    let INPUT_FIELD =<div className="divStyle" style={{marginBottom:'0%'}}>
    <i className=""  style={{...divStyleI}}/> 
    			<input  className='form-control' style={{paddingBottom: '5%'}} type="text" placeholder= { placeholder } value={filter} onChange={this.onFilterChange}
                              onKeyPress={this.onFilterKeyPress} disabled={disabled}/>
    			<Input label={caption} onClick={this.sortItems} labelClassName="col-sx-1" style={{fontSize:'90%', marginBottom: '0%', marginTop: '4%', backgroundColor: 'rgba(204, 204, 204, 1)', paddingLeft: '3%' ,cursor: 'pointer'}}/>
    			</div>
    return (
       <VerticalLayout>
       <FixedPanel>
           { showFilter && INPUT_FIELD }   
            <select multiple style={{paddingLeft: '5px'}}
              className='form-control'
              ref="select"
              size={size+2}
              value={selectedValues}
              onChange={this.updateSelectedValues}
              onDoubleClick={this.handleDoubleClick}
              disabled={disabled} >
              {filteredOptions.map((option) => {
                return <option key={option[valueField]} value={option[valueField]}>{option[displayField]}</option>
              })}
            </select>
            </FixedPanel>
            </VerticalLayout>
    )
    
  }

}