import React, {Component,PropTypes} from 'react';
import ReactDOM from 'react';
import {DropdownList} from 'react-widgets';
import {Button,FormControl,ControlLabel,FormGroup,Form,OverlayTrigger, Popover,Col} from 'react-bootstrap';
import {DynamicDataGrid,HorizontalLayout,FixedPanel,FlexPanel,VerticalLayout,connectCdtDataComponent } from 'ssc-cdt3';
import { connect } from 'react-redux';
import {reduxForm} from 'redux-form';
import * as _service from '../service';
import ModalWindow from '../components/ModalWindow';
import * as _actionCreators from '../redux/ActionCreators'; 
import { bindActionCreators } from 'redux'
import MessageDialog,* as _dialog from '../components/MessageDialog';
import { Link } from 'react-router';
import * as _sutils from '../sharedutils';
import ClientSelectionHeader from '../components/ClientSelectionHeader';
import {RULE_MAPPING_CONFIG_COLUMNS} from '../shared/ColumnConfigs';

export const fieldNames = ['EXEC_PARAMS','EXEC_CONDITION','EXEC_VALUE'];

function mapStateToProps(state) {
  return {
   showMessageDialog :state.messageDialog.showMessageDialog,
   messageDialogParams :state.messageDialog.messageDialogParams,
   selectedClient:state.clients.selectedClient,
   isClientSelectionChanged:state.clients.isClientSelectionChanged,
  }
}

@connect(mapStateToProps, function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
})
	
@reduxForm({form: 'ADD_RULE_MAPPING_ID_FORM', fields: fieldNames,  destroyOnUnmount: false})
@connectCdtDataComponent('fileMappingData',553840008)
@connectCdtDataComponent('fileRuleConditionData',553840008)
@connectCdtDataComponent('fileRuleMasterData',553840010)
@connectCdtDataComponent('ruleInputColNumData',553840004)
@connectCdtDataComponent('ruleFetchMappingMetaData',553840011)
export default class RuleMappingConfigContainer extends Component {
	
  static defaultProps = {
		  showMessageDialog: false
		}
	 
	static propType = {
		fileMappingId: PropTypes.string,
		clientId: PropTypes.string,
		fileMappingData: PropTypes.object,
		fileMappingDataActions: PropTypes.object,
		fileRuleMasterData: PropTypes.object,
		fileRuleMasterDataActions: PropTypes.object,
		fileRuleConditionData: PropTypes.object,
		fileRuleConditionDataActions:PropTypes.object,
		ruleInputColNumData: PropTypes.object,
		ruleInputColNumDataActions: PropTypes.object,
		ruleFetchMappingMetaData: PropTypes.object,
		ruleFetchMappingMetaDataActions: PropTypes.object,
		fields: PropTypes.object
      }
  
  static contextTypes = {
		router: React.PropTypes.object.isRequired,
	}
  
  
  constructor(props) {
    super(props);
		this.state={selectedRow:undefined,fileMappingId:undefined,fileDefId:undefined,clientId:undefined,editRow: undefined,
				editErrors: undefined, checkedRows: [],exeConditionFlag: false,exeParamFlag: false};
		this.modifiedRow = {};
		this.mappingColumns = [];
		this.gridData = [];
		this.columns = [   	     
    	      ...RULE_MAPPING_CONFIG_COLUMNS];
  }

onCheck = (checked) => {
    this.setState({checkedRows: checked});
  }

onDeleteLinkClick =() =>{
 this.props.actions.showMessageDialog("Confirm Action",_dialog.DIALOG_TYPE_YES_NO,'Are you sure you would like to delete ?',null, this.deleteDialogCallback, this);
}
deleteDialogCallback = (btntype, param) => {
	 if(_dialog.BTN_TYPE_YES === btntype) {
		this.remove();
	 }
	
}
remove =()=> {
	 const {checkedRows} = this.state;
	    this.props.fileRuleMasterDataActions.delete(checkedRows).then((ret) => {
	      if (ret.error) {
	        this.gridActions.error('Error', ret.payload._error || 'Error deleting items.');
	      } else {
	        this.connectCallback(this.gridActions,{FILE_DEF_ID:this.state.fileDefId, CLIENT_ID: _sutils.getSelectedClientId()});
	        this.gridActions.success('Success', 'Deleted row(s).'); 
	        this.setState({editRow: undefined, editErrors: undefined, checkedRows: []}); 
	      }
	    });
}


onRowClick=(row)=>{
  this.setState({selectedRow:row});
}
	onRowDoubleClick = (row) => {
    this.modifiedRow = {...row}; // clone for new values
    this.setState({editRow: row, editErrors: undefined});
  }
  
  connectCallback = (gridActions,params,successCallback) => {
    this.gridActions = gridActions;
    if(params)
     _service.makeCallWithHandlers(gridActions,_service.CALL_TYPE_LOADLIST,params,this.ruleMappingSuccessCallback,null,undefined,this.props) ;  
  }
  
  ruleMappingSuccessCallback =(ret,actions,spinJobId) =>{
	  if(ret.payload.data.length>0)
		  this.gridData = ret.payload.data;
  }
  
 
  loadRuleSuccessCallBack =(ret,actions,spinJobId)=>{
	    if(ret.payload.data && ret.payload.data.length>0){	
	    	_service.makeCallWithHandlers(this.props.fileRuleConditionDataActions,_service.CALL_TYPE_LOADLIST,
            		{CALL_TYPE:'RULE_CONDITION'},this.loadRuleConditionSuccessCallBack,
            		null,undefined,this.props) }
	    }
  
  loadInputColumnCallBack=(ret,actions,spinJobId)=>{
	    if(ret.payload.data && ret.payload.data.length>0){
	    	console.log("inside success handler of loadInputColumnCallBack call :"+JSON.stringify(ret))
	    }
  }
  
  loadRuleConditionSuccessCallBack=(ret,actions,spinJobId)=>{
	    if(ret.payload.data && ret.payload.data.length>0){
	    	console.log("Rule Conditions :"+JSON.stringify(ret));
	    }
  }

  componentWillMount() {
	  this.setDefaultValues();
  }
  
  componentDidMount() {
    if(this.props.location && this.props.location.state && this.props.location.state.params 
        && this.props.location.state.params.fileDefId)  {
          const fileDefId = this.props.location.state.params.fileDefId; 
          const clientId = this.props.location.state.params.clientId; 
          const inputFileType = this.props.location.state.params.inputFileType;
          
         
          _service.makeCallWithHandlers(this.props.fileMappingDataActions,_service.CALL_TYPE_LOADLIST,
            		{CALL_TYPE:'FILE_MAPPING_LIST',FILTER1:clientId},this.loadRuleSuccessCallBack,
            		null,undefined,this.props)
            		
          
          this.connectCallback(this.gridActions,{FILE_DEF_ID:fileDefId,CLIENT_ID:clientId});         
          this.setState({fileDefId,clientId});  
      }
    
  }

  componentWillReceiveProps(props) {
    console.log(this.props); }
 
 onChange = (value, column) => {
    const {editErrors = {}} = this.state;
    this.modifiedRow[column.dataKey] = value;
    
    if (!value) {
      this.setState(
        {editRow: {...this.modifiedRow},
        editErrors:column.dataKey=='EXEC_PARAMS'? {...editErrors, [column.dataKey]: `${column.label}:Please enter column number`}:
        	column.dataKey=='EXEC_VALUE'?{...editErrors, [column.dataKey]: `${column.label}:Please only alphanumeric characters`}:
            column.dataKey=='EXEC_SEQUENCE'?{...editErrors, [column.dataKey]: `${column.label}:Please enter sequence number`}:
        	{...editErrors, [column.dataKey]: `${column.label} is required`}
      });
    } else {
      this.setState({
        editRow: {...this.modifiedRow},
        editErrors: {...editErrors, [column.dataKey]: undefined}
      });
    }
    return true;
  }

	onKeyDown = (e) => {
    switch (e.keyCode) {
      case 13: // enter key
      if(!this.modifiedRow) return;
         this.update();
        break;
      case 27: // escape key
        e.preventDefault();
        e.stopPropagation();
        this.setState({editRow: undefined});
        break;
      default:
        break;
    }
  }

	update = () => {
		this.modifiedRow.CLIENT_ID = _sutils.getSelectedClientId();
    if (this.validate()) {
      this.gridActions.update(this.modifiedRow).then((ret) => {
        if (ret.error) {
        if (ret.payload._error.includes('RuleError2'))
          this.gridActions.error('Error', 'This rule already exist for '+this.state.fileMappingId || 'Please correct errors.');
        else if(ret.payload._error.includes('RuleError6'))
            this.gridActions.error('Error', 'Update operation not supported for templates.Please contact administrator.');        
        else
          this.gridActions.error('Error', ret.payload._error || 'Please correct errors.');
          this.setState({editErrors: ret.payload});
         
        } else {
        	let fileDefId = this.state.fileDefId;
        	this.connectCallback(this.gridActions,{FILE_DEF_ID:fileDefId, CLIENT_ID: _sutils.getSelectedClientId()});
        	this.gridActions.success('Success', 'Update was successful.');
	        this.setState({editRow: undefined});
        }
      });
    }
  }



  
  
validate(){
    // plug in any validation framework here
    const errors = {};
	    
	    if (!this.modifiedRow.EXEC_PARAMS) {
	        errors.EXEC_PARAMS = 'Column required';
	      }
	    if(!this.modifiedRow.EXEC_VALUE)
	    	{
	    	if(this.modifiedRow.EXEC_CONDITION_TXT !='IS_EMPTY' && this.modifiedRow.EXEC_CONDITION_TXT !='NOT_EMPTY' )
	    	{
	    	errors.EXEC_VALUE = 'Value required';
	    	}
	    	}
	    if (this.modifiedRow.EXEC_PARAMS) {
	        
		    	var regex  = /[A-Za-z_~!@#$%&*()_+-]/;
		    	if (regex.test(this.modifiedRow.EXEC_PARAMS))
		    	errors.EXEC_PARAMS = 'Please enter number only.';
	      }
 
	    if (this.modifiedRow.EXEC_LNK_PRIORITY) {
	        let singleRule = true;
	    	this.gridData.forEach((col, index, array)=> {
				  if(this.modifiedRow.KEY_ID!=col.KEY_ID)
					  if(this.modifiedRow.FILE_MAPPING_ID.trim()==col.FILE_MAPPING_ID.trim()){
						  singleRule = false;
						  if(this.modifiedRow.EXEC_LNK_PRIORITY=='NA' || this.modifiedRow.EXEC_LNK_PRIORITY==' ')
							 errors.EXEC_LNK_PRIORITY = 'Please select either AND/OR'; 
					  }
					 
						  
				  });
	    	if(singleRule && this.modifiedRow.EXEC_LNK_PRIORITY!=' ' && this.modifiedRow.EXEC_LNK_PRIORITY !='NA'){
	    		errors.EXEC_LNK_PRIORITY = 'Operator not applicable for single rule select NA';
	    	}
      }

	    
	    
	    if (this.modifiedRow.EXEC_VALUE) {
	     
	 	this.gridData.forEach((col, index, array)=> {
				  if(this.modifiedRow.KEY_ID!=col.KEY_ID)
					  if(this.modifiedRow.FILE_MAPPING_ID.trim()==col.FILE_MAPPING_ID.trim())
						  if(this.modifiedRow.EXEC_LNK_PRIORITY==col.EXEC_LNK_PRIORITY)
							  if(this.modifiedRow.EXEC_CONDITION==col.EXEC_CONDITION)
								  if(this.modifiedRow.EXEC_PARAMS==col.EXEC_PARAMS)
								    if(this.modifiedRow.EXEC_VALUE==col.EXEC_VALUE)
									  
							  errors.EXEC_VALUE = 'Same rule mapping id can not have duplicate rule';
				 
				  });
	 	if((undefined==this.modifiedRow.EXEC_VALUE || ""==this.modifiedRow.EXEC_VALUE || ""==this.modifiedRow.EXEC_VALUE.trim()))
	 		{
	 		if(this.modifiedRow.EXEC_CONDITION_TXT !='IS_EMPTY' && this.modifiedRow.EXEC_CONDITION_TXT !='NOT_EMPTY' )
	    	{
	 		errors.EXEC_VALUE = 'Value must be provided';
	    	}
	 		
	 		}
	 	if(undefined!=this.modifiedRow.EXEC_VALUE && ""!=this.modifiedRow.EXEC_VALUE && ""!=this.modifiedRow.EXEC_VALUE.trim())
	 		{
	 		if(this.modifiedRow.EXEC_CONDITION_TXT =='IS_EMPTY' || this.modifiedRow.EXEC_CONDITION_TXT =='NOT_EMPTY' )
	    	{
	 		errors.EXEC_VALUE = 'Value should not be provided for empty conditions';
	    	}
	 		
	 		if(this.modifiedRow.EXEC_CONDITION_TXT=='CONTAINS' || ( this.modifiedRow.EXEC_CONDITION_TXT =='ISNOT' || this.modifiedRow.EXEC_CONDITION_TXT =='NOT') || (this.modifiedRow.EXEC_CONDITION_TXT == '=' || this.modifiedRow.EXEC_CONDITION_TXT == 'EQUALS'))
	 	   {
	 		   //var regex = /[A-Za-z]+$/;
	 		   var regex = /^([a-zA-Z0-9 ]+)$/;
	 		   var regex2 = /^[0-9][\.\d]*(,\d+)?$/;
	 		   if(!regex.test(this.modifiedRow.EXEC_VALUE) && !regex2.test(this.modifiedRow.EXEC_VALUE)){
	 			   errors.EXEC_VALUE = 'Special characters are not allowed';
	 		   }
	 		 }
	 		 if(undefined!=this.modifiedRow.EXEC_CONDITION_TXT && ""!=this.modifiedRow.EXEC_CONDITION_TXT && this.modifiedRow.EXEC_CONDITION_TXT!='CONTAINS' && 
	 				   this.modifiedRow.EXEC_CONDITION_TXT!='ISNOT' && this.modifiedRow.EXEC_CONDITION_TXT!='=' && this.modifiedRow.EXEC_CONDITION_TXT!='NOT' && this.modifiedRow.EXEC_CONDITION_TXT!='EQUALS'
	 					   && this.modifiedRow.EXEC_CONDITION_TXT !='IS_EMPTY' && this.modifiedRow.EXEC_CONDITION_TXT !='NOT_EMPTY'){
	 			   
	 			   var regex = /^[0-9][\.\d]*(,\d+)?$/;
	 		  	if (!regex.test(this.modifiedRow.EXEC_VALUE)){
	 		  		
	 			    errors.EXEC_VALUE = 'Only numbers allowed for numeric conditions';
	 		  	}
	   }
	 		}
	    }
	 if (this.modifiedRow.EXEC_CONDITION_TXT) {
	     
		 	this.gridData.forEach((col, index, array)=> {
					  if(this.modifiedRow.KEY_ID!=col.KEY_ID)
						  if(this.modifiedRow.FILE_MAPPING_ID.trim()==col.FILE_MAPPING_ID.trim())
							  if(this.modifiedRow.EXEC_LNK_PRIORITY==col.EXEC_LNK_PRIORITY)
								  if(this.modifiedRow.EXEC_PARAMS==col.EXEC_PARAMS)
									    if(this.modifiedRow.EXEC_VALUE==col.EXEC_VALUE)
								  if(this.modifiedRow.EXEC_CONDITION_TXT==col.EXEC_CONDITION_TXT)
									 
										  
								  errors.EXEC_CONDITION_TXT = 'Same rule mapping id can not have duplicate rule';
					 
					  });
		   
		   }
 	
    this.setState({editErrors: errors}); 
    return Object.keys(errors).length === 0;
  }
   goBack=()=>{
     	this.context.router.push({pathname: '/filedef', state: {}}); 
   }
   
   setDefaultValues=()=> {
	   let {EXEC_PARAMS,EXEC_CONDITION,EXEC_VALUE} = this.props.fields;		
	   EXEC_PARAMS.onChange('');
	   EXEC_CONDITION.onChange('');
	   EXEC_VALUE.onChange(undefined);
	}

   onMappingChange =(val) =>{
	   
	  /* 
		_service.makeCallWithHandlers(this.props.ruleInputColNumDataActions,_service.CALL_TYPE_LOADLIST,
				{FILE_MAPPING_ID: val,CLIENT_ID: _sutils.getSelectedClientId()},this.loadInputColumnCallBack,
				null,undefined,this.props); */
			   
	   this.setState({fileMappingId:val,exeConditionFlag:false,exeParamFlag:false});
	   this.setDefaultValues();
   
   }
   
   onConditionChange = (defaultOnChange,val) =>{
	   defaultOnChange(val);
	   if(undefined!=val && val!="" && val!='IS_EMPTY' && val!='NOT_EMPTY') 
		this.setState({exeConditionFlag:true});
	   else
		   this.setState({exeConditionFlag:false});   

   }
   
   onParamChange = (defaultOnChange,val) =>{
	   defaultOnChange(val);
	   if(undefined!=val && val!="")
	   this.setState({exeParamFlag:true});
	   else
		   this.setState({exeParamFlag:false});  
   }
       
   onFormSubmit = () => {
		  
	   let {EXEC_PARAMS,EXEC_CONDITION,EXEC_VALUE} = this.props.fields;
	   let {fileMappingId,fileDefId} = this.state;
	   let add = true;
	   if(undefined!= fileDefId && undefined!= fileMappingId){
		   if(undefined!=EXEC_PARAMS.value && ""!=EXEC_PARAMS.value){
			   var regex = /^([0-9]+)$/;
			   if(!regex.test(EXEC_PARAMS.value))
				   {
				   this.props.actions.showMessageDialog(_dialog.HEADER_ERROR,_dialog.DIALOG_TYPE_CUSTOM,'Only numbers allowed in the coulmn field','CUSTOM_DIALOG',this.messageDialogCallback,this,['OK']);
				   add =false;
				   return;
				   }
			   if((undefined==EXEC_CONDITION.value || ""==EXEC_CONDITION.value)) {
				   this.props.actions.showMessageDialog(_dialog.HEADER_ERROR,_dialog.DIALOG_TYPE_CUSTOM,'Condition must be provided','CUSTOM_DIALOG',this.messageDialogCallback,this,['OK']);
				   add = false;
			   }

			   else if(EXEC_CONDITION.value!='IS_EMPTY' && EXEC_CONDITION.value!='NOT_EMPTY' && (undefined==EXEC_VALUE.value || ""==EXEC_VALUE.value || ""==EXEC_VALUE.value.trim())){
				   this.props.actions.showMessageDialog(_dialog.HEADER_ERROR,_dialog.DIALOG_TYPE_CUSTOM,'Value must be provided','CUSTOM_DIALOG',this.messageDialogCallback,this,['OK']);
				   add = false;
			   }

			   if(EXEC_CONDITION.value=='CONTAINS' || EXEC_CONDITION.value=='ISNOT' || EXEC_CONDITION.value=='=')
				   {
				   //var regex = /[A-Za-z]+$/;
				   var regex = /^([a-zA-Z0-9 ]+)$/;
				   var regex2 = /^[0-9][\.\d]*(,\d+)?$/;
				   if(!regex.test(EXEC_VALUE.value) && !regex2.test(EXEC_VALUE.value)){
					   this.props.actions.showMessageDialog(_dialog.HEADER_ERROR,_dialog.DIALOG_TYPE_CUSTOM,'Special characters are not allowed','CUSTOM_DIALOG',this.messageDialogCallback,this,['OK']);
					   add = false;
				   }
				   }
			   if(undefined!=EXEC_CONDITION.value && ""!=EXEC_CONDITION.value && EXEC_CONDITION.value!='CONTAINS' && 
					   EXEC_CONDITION.value!='ISNOT' && EXEC_CONDITION.value!='=' &&  EXEC_CONDITION.value!='IS_EMPTY' && EXEC_CONDITION.value!='NOT_EMPTY' &&  undefined!=EXEC_VALUE.value && ""!=EXEC_VALUE.value && ""!=EXEC_VALUE.value.trim()){
				   
				   var regex = /^[0-9][\.\d]*(,\d+)?$/;
			    	if (!regex.test(EXEC_VALUE.value)){
			    		this.props.actions.showMessageDialog(_dialog.HEADER_ERROR,_dialog.DIALOG_TYPE_CUSTOM,'Only numbers allowed for numeric conditions','CUSTOM_DIALOG',this.messageDialogCallback,this,['OK']);
						   add = false;
			    	}
			   }
		   }
		   if(undefined == EXEC_PARAMS.value || ""==EXEC_PARAMS.value || ""==EXEC_PARAMS.value.trim()){
			  if((undefined != EXEC_CONDITION.value && ""!= EXEC_CONDITION.value) ||  (undefined!=EXEC_VALUE.value && ""!=EXEC_VALUE.value && ""!=EXEC_VALUE.value.trim())){
				  this.props.actions.showMessageDialog(_dialog.HEADER_ERROR,_dialog.DIALOG_TYPE_CUSTOM,'Column value must be provided','CUSTOM_DIALOG',this.messageDialogCallback,this,['OK']);
			  	  add = false;  
			  }
		   }
			   if(add){
	   		   _service.makeCallWithHandlers(this.props.fileRuleMasterDataActions,_service.CALL_TYPE_ADD,
				   {FILE_MAPPING_ID:fileMappingId, CLIENT_ID: _sutils.getSelectedClientId(), 
			   			FILE_DEF_ID:fileDefId,EXEC_PARAMS: EXEC_PARAMS.value,EXEC_CONDITION: EXEC_CONDITION.value,
			   			EXEC_VALUE: EXEC_VALUE.value,EXEC_LNK_PRIORITY: ' '},
				   this.fileRuleMasterAddCallback,this.fileRuleMstAddFailureCallback,undefined,this.props) ;
			   }
	   }
   }
   
   fileRuleMstAddFailureCallback=(ret,actions,spinJobId) =>{
		if(ret.error){
			if (ret.payload._error.includes('RuleError1'))
				this.props.actions.showMessageDialog(_dialog.HEADER_ERROR,_dialog.DIALOG_TYPE_CUSTOM,'Mapping id '+'<b>'+this.state.fileMappingId+'</b>'+ ' must have same column count as existing mapping ids in grid','CUSTOM_DIALOG',this.messageDialogCallback,this,['OK']);
			if (ret.payload._error.includes('RuleError2'))
				this.props.actions.showMessageDialog(_dialog.HEADER_ERROR,_dialog.DIALOG_TYPE_CUSTOM,'This rule already exist for '+'<b>'+this.state.fileMappingId+'</b>','CUSTOM_DIALOG',this.messageDialogCallback,this,['OK']);
			if (ret.payload._error.includes('RuleError3'))
				this.props.actions.showMessageDialog(_dialog.HEADER_ERROR,_dialog.DIALOG_TYPE_CUSTOM,'This rule already exist for '+'<b>'+this.state.fileMappingId+'</b>','CUSTOM_DIALOG',this.messageDialogCallback,this,['OK']);
			if (ret.payload._error.includes('RuleError4'))
				this.props.actions.showMessageDialog(_dialog.HEADER_ERROR,_dialog.DIALOG_TYPE_CUSTOM,'Existing mapping is a template,but '+'<b>'+this.state.fileMappingId+'</b>'+' is not a template','CUSTOM_DIALOG',this.messageDialogCallback,this,['OK']);
			if (ret.payload._error.includes('RuleError5'))
				this.props.actions.showMessageDialog(_dialog.HEADER_ERROR,_dialog.DIALOG_TYPE_CUSTOM,'Existing mapping is not a template,but '+'<b>'+this.state.fileMappingId+'</b>'+' is a template','CUSTOM_DIALOG',this.messageDialogCallback,this,['OK']);


			}}
   
   fileRuleMasterAddCallback =(ret,actions,spinJobId) =>{
	   this.connectCallback(this.gridActions,{FILE_DEF_ID:this.state.fileDefId,CLIENT_ID:this.state.clientId});
   }
   viewRule =() =>{
	    console.log("client id:"+_sutils.getSelectedClientId()+" file mapping id:"+this.state.selectedRow.FILE_MAPPING_ID);
	    
	    _service.makeCallWithHandlers(this.props.ruleFetchMappingMetaDataActions,_service.CALL_TYPE_LOADLIST,
	  	   		{CLIENT_ID: _sutils.getSelectedClientId(),RULE_MAPPING_ID: this.state.selectedRow.FILE_MAPPING_ID},this.loadRuleMetadataSuccessCallBack,
	  	   		null,undefined,this.props);
	  }
   
   loadRuleMetadataSuccessCallBack=(ret,actions,spinJobId) =>{
	   if(ret.payload.data && ret.payload.data.length>0){
		    let params = {fileMappingId:this.state.selectedRow.FILE_MAPPING_ID,
		    		clientId:_sutils.getSelectedClientId(),
		    		fileDefId: this.state.fileDefId,fileType: ret.payload.data[0].OUTPUT_FILE_TYPE};
				this.context.router.push({pathname: '/ruleConfigNew', state: {params: params}});
	  	 }
	   }

  render() {
	let {checkedRows,fileDefId,selectedRow} = this.state;
	console.log("props inside render :"+JSON.stringify(this.props.location));
	//let templateCheck = this.props.location && this.props.location.state && this.props.location.state.params && (this.props.location.state.params.inputFileType=='PDF');
	let templateCheck = false;
	let enableDelete = checkedRows && checkedRows.length > 0;
	let enableViewRule = selectedRow && selectedRow.FILE_MAPPING_ID && selectedRow.FILE_MAPPING_ID.trim()!=='';
	let {fileMappingData,fileRuleConditionData} = this.props;
	let {EXEC_PARAMS,EXEC_CONDITION,EXEC_VALUE} = this.props.fields;
	let isFileDefIdAvailable = 	fileDefId && fileDefId.trim()!=='';
	const valuetooltip = (
            <Popover id='RuleTooltip' title=''>
            {'Please enter only alphanumeric characters'}
            </Popover>
          );
	const columntooltip = (
            <Popover id='RuleTooltip' title=''>
            {'Please enter column number'}
            </Popover>
          );
	/*this.mappingColumns=[];
	if(undefined!=ruleInputColNumData && ruleInputColNumData.data.length>0){
	ruleInputColNumData.data.forEach((col, index, array)=> {
		if (undefined!=col.INPUT_COL_NUM){ 
		let paramValue = col.INPUT_COL_NUM.split(',')[0];
		  if(undefined!=paramValue){
		  if(this.mappingColumns.indexOf(paramValue)<0)
			  this.mappingColumns.push(paramValue);
		  }}
		  
		  });
	
	}*/

	
	let MESSAGE_DIALOG = <MessageDialog showDialog={this.props.showMessageDialog} messageDialogParams={this.props.messageDialogParams} />
  let BACK_BUTTON = <div style={{display: 'inline-block', float: 'left'}}>
        				<Button className='btn btn-primary btn-xs' onClick = {this.goBack.bind(this)}> {'<< Back'}</Button>
        </div>

  const FILE_DEFINITION_TEXTBOX = <div style={{display: 'inline-block', float: 'left'}}>
					          		<label>{'File Definition'}</label>
					          		<input type="text" value={this.state.fileDefId} />															     
					          	  </div>
     const BR = <br/>
    return (

<HorizontalLayout>
<ClientSelectionHeader disableDropDown ={isFileDefIdAvailable}/>
       <VerticalLayout  onKeyDown={this.onKeyDown}> 
       <FixedPanel>
			 <h3 style={{marginTop: 0,marginBottom: 0}}> <strong>Rule Mapping Configuration  </strong></h3>
       {this.state.fileDefId &&  BR}
       {BACK_BUTTON}
   
       <Form inline>
       <FormGroup >
		 <Col sm={5} componentClass={ControlLabel}>
		 {'File Definition'}
		 </Col>
		 <Col sm={5}>
		<FormControl type="text" value={this.state.fileDefId} disabled='true'/>
		</Col>
	   </FormGroup>
	<FormGroup>
	<Col sm={5} componentClass={ControlLabel}>
 	{templateCheck ?'File Template':'Rule Mappings'}
 	</Col>
 	<Col sm={5}>
		<FormControl componentClass="select" value={this.state.fileMappingId} onChange={(e)=> this.onMappingChange(e.target.value)}>
		 <option value="">--Select--</option>
         {(()=>{
           if(fileMappingData.data!= undefined || fileMappingData.data!=null){
             return fileMappingData.data.map((x)=>{
            	 if (!x.CODE_VALUE.includes('Header') && !x.CODE_VALUE.includes('Footer') && !x.CODE_VALUE.includes('RPRT'))
               return (
                 <option value={x.CODE_VALUE}>{x.CODE_VALUE}</option>
               );
             });
           }
         })()}
         </FormControl>
    </Col>
	</FormGroup>
	</Form>
	{BR}
		<Form inline>
		<FormGroup bsSize="small">
		<label style={{marginLeft: 70}}>{'Column'}&nbsp;&nbsp;</label>		
		<OverlayTrigger overlay={columntooltip} placement='left'>
		<FormControl {...EXEC_PARAMS}  disabled = {undefined == this.state.fileMappingId || " " == this.state.fileMappingId} value={EXEC_PARAMS.value} type="text" placeholder="Column" >
		</FormControl>
		</OverlayTrigger>
	</FormGroup>

		<FormGroup bsSize="small">
			<label>&nbsp;&nbsp;{'Condition'}&nbsp;&nbsp;</label>
			<FormControl {...EXEC_CONDITION} disabled={undefined==EXEC_PARAMS.value  || ""==EXEC_PARAMS.value} value={EXEC_CONDITION.value} componentClass="select" onChange={(e)=> this.onConditionChange(EXEC_CONDITION.onChange,e.target.value)}>
			<option value=""></option>
	         {(()=>{
	           if(fileRuleConditionData.data){
	             return fileRuleConditionData.data.map((x)=>{
	               return (
	                 <option value={x.CODE_VALUE}>{x.LABEL}</option>
	               );
	             });
	           }
	         })()}
			</FormControl>
		</FormGroup>
		<FormGroup bsSize="small">
			<label>&nbsp;&nbsp;{'Value'}&nbsp;&nbsp;</label>
			<OverlayTrigger overlay={valuetooltip} placement='right'>
			<FormControl {...EXEC_VALUE} disabled={!this.state.exeConditionFlag}  value={EXEC_VALUE.value} type="text" placeholder="Value" > 			
		</FormControl>
		</OverlayTrigger>
		</FormGroup>
		<FormGroup >
		&nbsp;&nbsp;&nbsp;&nbsp;<Button bsStyle='btn btn-primary btn-xs' 
            onClick={this.onFormSubmit}  disabled={!(this.state.fileMappingId)}>Add</Button>
		</FormGroup>
		<FormGroup >
		&nbsp;&nbsp;<Button className='btn btn-primary btn-xs' onClick={this.onDeleteLinkClick} 
			disabled={!enableDelete}>Delete</Button>
		</FormGroup>
		<FormGroup >
		&nbsp;&nbsp; <Button className='btn btn-primary btn-xs' 
	     onClick={this.viewRule} disabled={!enableViewRule || templateCheck} >View Rule Config</Button>
		</FormGroup>
		</Form>
		
     </FixedPanel>
     <FlexPanel>
      <DynamicDataGrid
		columns={this.columns}
        dataIdf={553840010}
        gridConnectCallback={this.connectCallback}
        componentId='mappingRuleGrid'
        keyFieldName='KEY_ID'
				editRow={this.state.editRow}
				onRowDoubleClick={this.onRowDoubleClick}
				onChange={this.onChange}
				editErrors={this.state.editErrors}
      			onCheckedChange={this.onCheck}
      			onRowClick={this.onRowClick}
      			scale ={1}
				pageSize={50}
        		excelExport
        		csvExport
        		hasCheckbox
      /> 
      </FlexPanel>
			</VerticalLayout>
		{MESSAGE_DIALOG}
			</HorizontalLayout>

    );
  }
}



