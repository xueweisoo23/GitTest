import React, {Component, PropTypes} from 'react';
import {connect} from 'react-redux';
import {DropdownList} from 'react-widgets';
import {connectCdtDataComponent} from 'ssc-cdt3';
import * as _service from '../service'
import {OverlayTrigger, Popover} from 'react-bootstrap';
import {DropdownEditor} from './DropdownEditor';

@connectCdtDataComponent('outputDelimiterData',553840008)
export class OutputDelimiterEditor extends Component { 
  static propTypes = {
    value: PropTypes.string,
    onChange: PropTypes.func,
    col: PropTypes.object,
    row: PropTypes.object,
    bottomOffset: PropTypes.number,
    rowHeight: PropTypes.number,
    outputDelimiterData: PropTypes.object,
    outputDelimiterDataActions: PropTypes.object,
  }

  constructor(props) {
    super(props);
    const {value} = props;
    this.state = {value};
  }

  onChange = (val) => {

    if (this.props.onChange(val, this.props.col)) {
        this.props.onChange('true', {dataKey: 'IS_OUTPUT_DELIMITER_UPDATED'});
        this.setState({value: val});
    }
  }
   componentDidMount() {
     _service.makeCallWithHandlers(this.props.outputDelimiterDataActions,_service.CALL_TYPE_LOADLIST,{CALL_TYPE:'OUTPUT_DELIMITER_CD'},null,null,undefined,this.props) 
  }

  render() {
    const {col,error,outputDelimiterData,row, bottomOffset, rowHeight} = this.props;
    return (
    <DropdownEditor value={this.state.value} onChange={this.onChange} col={col} row={row} bottomOffset={bottomOffset} rowHeight={rowHeight}
                    dropdownValues={outputDelimiterData} error ={error}>
    </DropdownEditor>   
    );
  }
}
