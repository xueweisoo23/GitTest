import * as _sutils from './sharedutils.js' 

/**
 * @author p530579
 * 
 * File to maintain the service utilities function that could be shared and not specific to the application.
 * If you wanted to add any utilities fucntion specific to the application then add to apputils.js 
 * 
 */


export const CALL_TYPE_LOADLIST = 'LOADLIST';
export const CALL_TYPE_UPDATE = 'UPDATE';
export const CALL_TYPE_ADD = 'ADD';
export const CALL_TYPE_LOAD = 'LOAD';
export const CALL_TYPE_REFRESH = 'REFRESH';
export const CALL_TYPE_COMPONENT_LOAD_ONCE = 'COMPONENT_LOAD_ONCE';


export function makeCall(actions,callType,params) {
  callType = callType!==undefined?callType:'DEFAULT';
  
  switch(callType) {
    case CALL_TYPE_LOADLIST:
          return actions.loadList(params);
          break;
    case CALL_TYPE_UPDATE:
          return actions.update(params);
          break;
    case CALL_TYPE_ADD:
          return actions.addNew(params);
          break;
    case CALL_TYPE_LOAD:
          return actions.load(params);
          break;
    case CALL_TYPE_REFRESH:
          return actions.refresh(params);
          break;
    case CALL_TYPE_COMPONENT_LOAD_ONCE:
          return actions.componentLoadOnce(params.componentId,params);
          break;
    default:
          return actions.loadList(params);
          break;
  }
}
  
export function makeCallWithHandlers(actions,callType,params,successCallback,failureCallback,spinJobId,props) {
  let isSpinnerEnabled = !_sutils.isEmpty(spinJobId);
  if(isSpinnerEnabled)
      props.actions.startSpinner(spinJobId); 
  makeCall(actions,callType,params)
  .then((ret) => {
        if(isSpinnerEnabled) 
          props.actions.stopSpinner(spinJobId);
        
        if (ret.error) {
          if(failureCallback)
              failureCallback(ret,actions,spinJobId);
          else
            actions.error('ERROR', ret.payload._error || 'Error occured on service call.'); 
        }else {
          if(successCallback)
            successCallback(ret,actions,spinJobId);
        }                        	
      })
      .catch((ret) => {
        
        if(isSpinnerEnabled)
          props.actions.stopSpinner(spinJobId);
          
        if(failureCallback)
            failureCallback(ret,actions,spinJobId);
        else
            actions.error('ERROR', ret.payload._error || 'Error occured on service call.');   
    });
 
}

export function getUserName(props) {
  if (props && props.authsession && props.authsession.displayName) {
    return props.authsession.displayName;
  } 
}
