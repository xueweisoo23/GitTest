
import React, { Component, PropTypes } from 'react';
import { connect } from 'react-redux';
import { FormControl, FormGroup } from 'react-bootstrap';
import { connectCdtDataComponent } from 'ssc-cdt3';

import * as _aconst from '../appconstants';
import * as _sutils from '../sharedutils';
import * as _service from '../service';


/**
 *  @author p530579
 * Component to be added on every page so that the client  dropdown will be available on the header ribbon 
 **/

function mapStateToProps(state) {
  return {
    entitledClients: state.clients.entitledClients,
    authsession: state.authsession,
    helpData: state.help.helpData
  }
}
@connect(mapStateToProps, _sutils.mapDispatchToProps)
@connectCdtDataComponent('clientData', 553840008)
@connectCdtDataComponent('helpData', 553840013)
export default class ClientSelectionHeader extends Component {
  static propTypes = {
    clientData: PropTypes.object,
    clientDataActions: PropTypes.object,
    disableDropDown: PropTypes.bool,
    helpData: PropTypes.object,
    helpDataActions: PropTypes.object,
  };

  static defaultProps = {
    disableDropDown: false
  }

  constructor(props) {
    super(props);
    this.state = {}
  }


  componentWillMount() {
    let {entitledClients, helpData} = this.props;
    if (!entitledClients || entitledClients.length <= 0)
      _service.makeCallWithHandlers(this.props.clientDataActions, _service.CALL_TYPE_LOADLIST, { CALL_TYPE: 'CLIENT_ID' }, this.successHandler, null, undefined, this.props);
    else
      this.setSelectedClient(entitledClients);

    if (!helpData || helpData.length <= 0 || !helpData.data || helpData.data.length <= 0) {
      _service.makeCallWithHandlers(this.props.helpDataActions, _service.CALL_TYPE_LOAD, null, this.HelpSuccessHandler, _sutils.defaultErrorHandler.bind(this), undefined, this.props);
    }
  }
  
  HelpSuccessHandler = (ret, actions, spinJobId) => {
    this.props.actions.loadHelpData(ret.payload.data);
  }

  successHandler = (ret, actions, spinJobId) => {
    if (ret.payload.data)
      this.props.actions.reloadClientDropdown(ret.payload.data);
  }

  setSelectedClient = (entitledClients) => {
    let currentSelectedClient = _sutils.getSessionStorage(_aconst.SS_CURRENT_SELECTED_CLIENT);
    if (!currentSelectedClient)
      currentSelectedClient = entitledClients && entitledClients.length > 0 ? entitledClients[0] : '';

    if (currentSelectedClient) {
      this.clientChangedPostActions(currentSelectedClient);
      this.setState({ selectedClientId: currentSelectedClient.CODE_VALUE });
    }
    return currentSelectedClient;
  }

  componentWillReceiveProps(props) {
    this.props = props;
    this.setSelectedClient(this.props.entitledClients);
  }

  clientSelectionChanged = (e) => {
    this.selectedClientId = e.target.value;
    this.clientObj = this.getClientObjByClientId(this.selectedClientId);

    this.clientChangedPostActions(this.clientObj);
    this.setState({ selectedClientId: this.selectedClientId });

  }


  getClientObjByClientId = (ky) => {
    let obj = undefined;
    let {entitledClients} = this.props;
    if (entitledClients && entitledClients.length > 0 && ky !== '') {
      let filtered = entitledClients.filter((item) => { return (item.CODE_VALUE == ky) });
      obj = filtered.length > 0 ? filtered[0] : undefined;
    }
    return obj;
  }

  clientChangedPostActions = (clientObj) => {
    this.props.actions.clientSelectionChanged(clientObj);
    _sutils.setSessionStorage(_aconst.SS_CURRENT_SELECTED_CLIENT, clientObj);
  }

  render() {
    let {entitledClients} = this.props;
    return (
      <div className='clientselection'>
        <FormGroup>

          <label>{'Client App:'}</label>
          <FormControl disabled={this.props.disableDropDown} componentClass="select" placeholder="select" onChange={this.clientSelectionChanged} value={this.state.selectedClientId}>
            {
              (() => {
                if (entitledClients && entitledClients.length > 0) {
                  return entitledClients.map((x) => {
                    return <option value={x.CODE_VALUE} key={x.CODE_VALUE}>{x.LABEL}</option>
                  })
                }
              })()
            }
          </FormControl>
        </FormGroup>
      </div>
    );
  }
}
