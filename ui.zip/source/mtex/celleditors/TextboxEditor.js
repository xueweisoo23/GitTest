import React, {Component, PropTypes} from 'react';
import {DateTimePicker} from 'react-widgets';
import {OverlayTrigger, Popover} from 'react-bootstrap';

export default class TextboxEditor extends Component {
  static propTypes = {
    col: PropTypes.object,
    value: PropTypes.any,
    onChange: PropTypes.func,
    rowHeight: PropTypes.number,
    error: PropTypes.string,
    bottomOffset: PropTypes.number,
    rightOffset: PropTypes.number
  }

  constructor(props) {
    super(props);
    const {value = ''} = props;
    this.state = {value};
  }

  onChange = (val) => {
    if (this.props.onChange(val, this.props.col)) {
      this.setState({value: val});
    }
  }

  render() {
    const {col, rowHeight, error, bottomOffset, rightOffset,rowId} = this.props;
    const {value} = this.state;
    const fieldStyle = {height: rowHeight-42, width: '100%'};
    const dateFieldStyle = {width: '100%', height: rowHeight};
    const className = error ? 'error' : null;
    let isDisabled = col.disableOnEdit && rowId && rowId!==''
    let editField;

    switch (col.dataType) {
      case 'datetime':
        editField = (
          <div className={rightOffset < 50 ? 'rightAlignPopup' : undefined}>
            <DateTimePicker
              key={`${col.dataKey}_picker`} value={value}
              dropUp={bottomOffset < 330} onChange={this.onChange}
              time className={className}
              style={dateFieldStyle} />
          </div>
        );
        break;
      case 'number':
        editField = (
          <input type='number' onChange={(e) => this.onChange(e.target.value)} key={col.dataKey}
            className={className} value={value} style={{...fieldStyle, textAlign: 'right'}} />
        );
        break;
      default:
        editField = (
          <input type='text' disabled ={isDisabled} onChange={(e) => this.onChange(e.target.value)} key={col.dataKey}
            className={className} value={value} style={fieldStyle} maxLength={col.maxLength?col.maxLength:20} /> 
        );
    }

    const hover = error ? <Popover id={`${col.dataKey}_error`}>{error}</Popover> : <div />;
    return (
      <OverlayTrigger
        key={col.dataKey} overlay={hover} placement='top'
        trigger={['hover', 'focus']}>
         {editField}
      </OverlayTrigger>

    );
  }
}
