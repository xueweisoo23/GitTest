import { bindActionCreators } from 'redux'
import * as _actionCreators from './redux/ActionCreators'; 
import * as _aconst from './appconstants';

/**
 * @author p530579
 * 
 * File to maintain the common utilities function that could be shared and not specific to the application.
 * If you wanted to add any utilities fucntion specific to the application then add to apputils.js 
 * 
 */

export function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
}

export function getObjectKeyValue(obj,valueField) {
	
  if(valueField==undefined)
   valueField ='CODE';

  if(typeof obj==='string')
	 return obj; 
   
   return obj[valueField];
}

export function defaultErrorHandler(ret,actions,spinJobId){
    if (ret.error) 
			actions.error('ERROR', ret.payload._error || 'Error occured on service call.');
  }


export function isEmpty(value) {
  if(value!=undefined)
  {
     if(typeof value==='string') {
        if(value.trim()==='')
            return true;
         else
            return false;
     }
     else if(typeof value==='object') {
       if(value===null)
          return true;
       else
          return false;
     } 
  }
  else
    return true;
}

export function isStorageSupported() {
  if (typeof(Storage) === undefined) 
      return false;
  else 
      return true
}

export function doCheckforEntitlement(obj,isHomePage) {
    let isEntitled = getSessionStorage('IS_MTEX_APP_ENTITLED');
    if(isEntitled && isEntitled==='true'){
		  return true;
    } else {
      if(!isHomePage){
    	  obj.context.router.push('/');
    	  return true;
      }
      else
    	  obj.context.router.push('/noentitlement'); 
      return false; 
    }  
  }


export function setSessionStorage(key,value) {
  if (isStorageSupported()) {
    sessionStorage.setItem(key, JSON.stringify(value));
  }
}

export function getSessionStorage(key) {
  if (isStorageSupported()) {
    let obj = sessionStorage.getItem(key);
    return (isEmpty(obj)||obj==='undefined') ?undefined:JSON.parse(obj);
  } 
}

export function setLocalStorage(key,value) {
  if (isStorageSupported()) {
    localStorage.setItem(key, value);
  }
}

export function getLocalStorage(key) {
  if (isStorageSupported()) {
    return localStorage.getItem(key);
  } 
}

export function getUserId(props) {
  if (props.authsession && props.authsession.userId) {
    return props.authsession.userId;
  } 
}

export function getUserName(props) {
  if (props && props.authsession && props.authsession.displayName) {
    return props.authsession.displayName;
  } 
}

export function getSelectedClientId() {
  return getSessionStorage(_aconst.SS_CURRENT_SELECTED_CLIENT).CODE_VALUE;
}


