import React, {Component, PropTypes} from 'react';
import {Button,Modal,ButtonGroup} from 'react-bootstrap';
import { connect } from 'react-redux';

import {HorizontalLayout,FixedPanel} from 'ssc-cdt3';

import * as _sutils from '../sharedutils';


/**
 * @author p530579
 * 
 * MessageDialog for displaying the dialog box on the client side based on the type.
 * Types of message dialog displayed listed below
 * DIALOG_OK
 * DIALOG_OK_CANCEL
 * DIALOG_YES_NO
 * 
 * allows to have a callback method on the dialog buttons need to pass the params as callbackHandler
 * Refer TestMessageDialog.js for sample implementation
 */

export const BTN_TYPE_OK = 'OK';
export const BTN_TYPE_CANCEL = 'Cancel';
export const BTN_TYPE_YES = 'Yes';
export const BTN_TYPE_NO = 'No';
export const BTN_TYPE_CLOSE = 'Close';

export const DIALOG_TYPE_OK = 'DIALOG_OK';
export const DIALOG_TYPE_OK_CANCEL = 'DIALOG_OK_CANCEL';
export const DIALOG_TYPE_YES_NO = 'DIALOG_YES_NO';
export const DIALOG_TYPE_CUSTOM = 'DIALOG_CUSTOM';
 
 export const HEADER_MESSAGE = 'Message'; 
 export const HEADER_CONFIRMATION = 'Confirmation';
 export const HEADER_ERROR = 'ERROR';

function mapStateToProps(state) {
  return {
	 showMessageDialog :state.messageDialog.showMessageDialog,
	 messageDialogParams :state.messageDialog.messageDialogParams
  }
}

@connect(mapStateToProps, _sutils.mapDispatchToProps)
export default class MessageDialog extends Component { 
	static propType = {
     	showMessageDialog:PropTypes.bool.isRequired,
		messageDialogParams: PropTypes.object.isRequired
    }
	 
	static defaultProps = {
		showMessageDialog:false, 
		messageDialogParams: { header: HEADER_MESSAGE, dialogType: DIALOG_TYPE_OK, }
	 } 
 	
	 constructor(props) {
		super(props);
	}

	componentWillReceiveProps=(nextProps) => {
	  this.props = nextProps;
	  }
	  
	closeDialog=()=>{
		this.props.actions.hideMessageDialog(); 
	}
	
	callbackHandler=(btnType) => {
		this.closeDialog();
		
		if(this.props.messageDialogParams.callbackHandler)
			this.props.messageDialogParams.callbackHandler(btnType,this.props.messageDialogParams.messageId) 
	}
	
	getHeaderMessage=()=> {
		if(!this.props.messageDialogParams.header) {
			if(this.props.messageDialogParams.dialogType===DIALOG_TYPE_YES_NO)
				return HEADER_CONFIRMATION;
			else if (this.props.messageDialogParams.header===HEADER_ERROR)
				return HEADER_ERROR;
			else
				return HEADER_MESSAGE; 	
		}
		else
			return this.props.messageDialogParams.header
	}
	
  render() {
		console.log('render inside MessageDialog..........');
		var {customBtns} = this.props.messageDialogParams;
		
		let YES_NO_BUTTON = <HorizontalLayout> 
							
							 <b></b>  
							 <ButtonGroup style={{align: 'right'}}>
								<Button className='btn btn-primary' onClick={this.callbackHandler.bind(this,BTN_TYPE_YES)}>{BTN_TYPE_YES}</Button>
								<Button onClick={this.callbackHandler.bind(this,BTN_TYPE_NO)}>{BTN_TYPE_NO}</Button>
							 </ButtonGroup>
							</HorizontalLayout> 
							
		let OK_BUTTON = <Button onClick={this.callbackHandler.bind(this,BTN_TYPE_OK)}>{BTN_TYPE_OK}</Button>
		
		let OK_CANCEL_BUTTON = <div><Button className='btn btn-primary' onClick={this.callbackHandler.bind(this,BTN_TYPE_OK)}>{BTN_TYPE_OK}</Button>
							   <Button onClick={this.callbackHandler.bind(this,BTN_TYPE_CANCEL)}>{BTN_TYPE_CANCEL}</Button> </div>
							   
		//Handle for custom button captions							   
		let CUSTOM_BUTTON_GRP_START =  <ButtonGroup style={{align: 'right'}}>;
		
		//var  CUSTOM_BUTTON_GRP_END = </ButtonGroup> ;
		
		let htmlMessage = {__html:this.props.messageDialogParams.message};
	return (
		
		<Modal show={this.props.showMessageDialog} onHide={this.callbackHandler.bind(this,BTN_TYPE_CLOSE)} backdrop ={'static'} >
		 <Modal.Header closeButton>
            <Modal.Title><b>{this.getHeaderMessage()}</b></Modal.Title> 
          </Modal.Header>
        
          <Modal.Body>
          	<FixedPanel height={60} >
		   	<div dangerouslySetInnerHTML={htmlMessage} />					
		    </FixedPanel>
		  </Modal.Body>
		 
          <Modal.Footer>
              {this.props.messageDialogParams.dialogType===DIALOG_TYPE_YES_NO &&  YES_NO_BUTTON}
			  {this.props.messageDialogParams.dialogType===DIALOG_TYPE_OK &&  OK_BUTTON}
			  {this.props.messageDialogParams.dialogType===DIALOG_TYPE_OK_CANCEL &&  OK_CANCEL_BUTTON}
			  {this.props.messageDialogParams.dialogType===DIALOG_TYPE_CUSTOM &&  CUSTOM_BUTTON_GRP_START && customBtns.map((item, index)=>{
				return (<Button className='btn btn-primary' onClick={this.callbackHandler.bind(this,item)}>{item}</Button>)	
			})}
          </Modal.Footer>
		   </Modal>
		 
		); 
	}
}
