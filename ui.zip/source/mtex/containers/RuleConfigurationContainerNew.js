import React, {Component,PropTypes} from 'react';
import ReactDOM from 'react';
import {Button,FormControl,ControlLabel,FormGroup,Form,OverlayTrigger, Popover,Col} from 'react-bootstrap';
import {DynamicDataGrid,HorizontalLayout,FixedPanel,FlexPanel,VerticalLayout,connectCdtDataComponent} from 'ssc-cdt3';
import { connect } from 'react-redux';
import * as _service from '../service';
import ModalWindow from '../components/ModalWindow';
import * as _actionCreators from '../redux/ActionCreators'; 
import { bindActionCreators } from 'redux'
import MessageDialog,* as _dialog from '../components/MessageDialog';
import FileUpload from '../components/FileUpload'; 
import { Link } from 'react-router';
import * as _sutils from '../sharedutils';
import ClientSelectionHeader from '../components/ClientSelectionHeader';
import {RULE_CONFIG_COLUMNS,RULE_CONFIG_COLUMNS_XML} from '../shared/ColumnConfigs';
import {AlignmentEditor}          from  '../celleditors/AlignmentEditor';

const UPLOAD_FILE = {
	fileTypes:['.xlsx','.xls','.csv'],
	maxFilesAllowed:1,
	templateFileId:'',
};


function mapStateToProps(state) {
  return {
		 showHelpModalWindow : (state.modalWindow.HELP_WINDOW?state.modalWindow.HELP_WINDOW:false),
	 showFileUploadModalWindow : (state.modalWindow.FILE_UPLOAD?state.modalWindow.FILE_UPLOAD:false),
   showMessageDialog :state.messageDialog.showMessageDialog,
   messageDialogParams :state.messageDialog.messageDialogParams,
   selectedClient:state.clients.selectedClient,
   isClientSelectionChanged:state.clients.isClientSelectionChanged,
	 helpData: state.help.helpData
  }
}

@connect(mapStateToProps, function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(_actionCreators, dispatch),
  }
})
@connectCdtDataComponent('fileMappingData',553840008)
@connectCdtDataComponent('dateFrmtData',553840008)
@connectCdtDataComponent('ruleMappingMetaData',553840011)
export default class RuleConfigurationContainerNew extends Component {
	
  static defaultProps = {
		  showMessageDialog: false
		}
	 
	static propType = {
		fileMappingId: PropTypes.string,
		clientId: PropTypes.string,
		fileMappingData: PropTypes.object,
		fileMappingDataActions: PropTypes.object,
		dateFrmtData:PropTypes.object,
		dateFrmtDataActions:PropTypes.object,
		ruleMappingMetaData: PropTypes.object,
		ruleMappingMetaDataActions: PropTypes.object
      }
  
  static contextTypes = {
		 router: React.PropTypes.object.isRequired,
		}
  
  
  constructor(props) {
    super(props);
		this.state={fileMappingId:undefined,clientId:undefined,
				editRow: undefined,editErrors: undefined, checkedRows: [],fileDefId:undefined,fileType:'',fileContent:undefined};
		this.dateFrmt = [];
		this.columns = [];
		this.fileType = '';
		}
  

onCheck = (checked) => {
    this.setState({checkedRows: checked});
  }

addNew = () => {
	this.modifiedRow = {};
    this.setState({editRow: {}, editErrors: undefined});
    }

onDeleteLinkClick =() =>{
	 this.props.actions.showMessageDialog("Confirm Action",_dialog.DIALOG_TYPE_YES_NO,'Are you sure you would like to delete ?',null, this.deleteDialogCallback, this);
	}
	deleteDialogCallback = (btntype, param) => {
		 if(_dialog.BTN_TYPE_YES === btntype) {
			this.remove();
		 }
		
	}

remove = () => {
    const {checkedRows} = this.state;
    this.gridActions.delete(checkedRows).then((ret) => {
      if (ret.error) {
        this.gridActions.error('Error', ret.payload._error || 'Error deleting items.');
      } else {
    	 // console.log('File Mapping ID: '+this.state.fileMappingId);
    	  let fileMappingId = this.state.fileMappingId;
        this.connectCallback(this.gridActions,{FILE_MAPPING_ID:fileMappingId, CLIENT_ID: _sutils.getSelectedClientId()});
        this.gridActions.success('Success', 'Deleted row(s).');        
        this.setState({editRow: undefined, editErrors: undefined, checkedRows: []});
      }
    });
  }

	uploadFileCallback=(filename,isSuccess,message)=> {
		console.log('uploadFileCallback=>filename:'+filename+':isSuccess:'+isSuccess+':message:'+message);
    if(isSuccess){
      this.props.actions.hideModalWindow('FILE_UPLOAD');
      this.gridActions.success('Success', 'File processed successfully. ');
      this.connectCallback(this.gridActions,{FILE_MAPPING_ID:this.state.fileMappingId, CLIENT_ID: _sutils.getSelectedClientId()});
    } else {
      this.gridActions.error('Error', message);
    }


		//alert(message);
	}

	onRowDoubleClick = (row) => {
   this.modifiedRow = {...row}; // clone for new values
    this.setState({editRow: row, editErrors: undefined});
  }
  
  connectCallback = (gridActions,params,successCallback) => {
    this.gridActions = gridActions;
    if(params)
     _service.makeCallWithHandlers(gridActions,_service.CALL_TYPE_LOADLIST,params,successCallback,null,undefined,this.props) ;  
  }
  
  
  
  loadRuleMetadataSuccessCallBack =(ret,actions,spinJobId)=>{
	  if(ret.payload.data && ret.payload.data.length>0){
	    	console.log("inside success handler of load rule mapping metadata method:"+JSON.stringify(ret))
	    	//this.dateFrmt = ret.payload.data;
	  }
  }

  componentDidMount() {
	  
	  if(this.props.location && this.props.location.state && this.props.location.state.params 
		        && this.props.location.state.params.fileType)  {
		          this.fileType = this.props.location.state.params.fileType;
		          }
	  
	  _service.makeCallWithHandlers(this.props.ruleMappingMetaDataActions,_service.CALL_TYPE_LOADLIST,
  	   		{CLIENT_ID: _sutils.getSelectedClientId()},this.loadRuleMetadataSuccessCallBack,
  	   		null,undefined,this.props);
  
         _service.makeCallWithHandlers(this.props.fileMappingDataActions,_service.CALL_TYPE_LOADLIST,
        	   		{CALL_TYPE:'FILE_MAPPING_LIST',FILTER1:_sutils.getSelectedClientId()},this.loadRuleSuccessCallBack,
        	   		null,undefined,this.props);
                
         _service.makeCallWithHandlers(this.props.dateFrmtDataActions,_service.CALL_TYPE_LOADLIST,
     	   		{CALL_TYPE:'DATE_FORMAT'},this.loadDateFrmtSuccessCallBack,
     	   		null,undefined,this.props);

  }

  componentWillReceiveProps(props) {
   // console.log("Will Receive props of ruleconfignew :"+JSON.stringify(this.props));
    if(this.props.selectedClient.CODE_VALUE !== props.selectedClient.CODE_VALUE && props.isClientSelectionChanged){
    	_service.makeCallWithHandlers(this.props.fileMappingDataActions,_service.CALL_TYPE_LOADLIST,
    	   		{CALL_TYPE:'FILE_MAPPING_LIST',FILTER1:_sutils.getSelectedClientId()},this.loadRuleSuccessCallBack,
    	   		null,undefined,this.props);
    	_service.makeCallWithHandlers(this.props.ruleMappingMetaDataActions,_service.CALL_TYPE_LOADLIST,
    	  	   		{CLIENT_ID: _sutils.getSelectedClientId()},this.loadRuleMetadataSuccessCallBack,
    	  	   		null,undefined,this.props);
    }
  }

  componentWillMount() {
   _sutils.doCheckforEntitlement(this,true);
//   if(this.props.location && this.props.location.state && this.props.location.state.params && this.props.location.state.params.fileDefId)
//   let fildef = this.props.location.state.params.fileDefId;
//   this.setState({fileDefId:fildef});
  }
  loadDateFrmtSuccessCallBack =(ret,actions,spinJobId)=>{
	  if(ret.payload.data && ret.payload.data.length>0){
	    	console.log("inside success handler of date format method:"+JSON.stringify(ret))
	    	this.dateFrmt = ret.payload.data;
	  }
  }
  loadRuleSuccessCallBack =(ret,actions,spinJobId)=>{
	    if(ret.payload.data && ret.payload.data.length>0){
	    	console.log("inside success handler of load field mapping ids method :"+JSON.stringify(ret))
	    	let arr = ret.payload.data;
	    	
	    	if(this.props.location && this.props.location.state && this.props.location.state.params && this.props.location.state.params.fileMappingId){
	    		this.setState({fileMappingId: this.props.location.state.params.fileMappingId});
	    	}    	
	    	let filemapId = this.state.fileMappingId;	    	
	    	this.connectCallback(this.gridActions,{FILE_MAPPING_ID:filemapId,CLIENT_ID: _sutils.getSelectedClientId()});
	    }
	    }
  

modalClosedCallback = (btnType,id)=> {   
		console.log('id:'+id+':btnType:'+btnType);
	 }
	 showHelpWindow=()=>{
    let {helpData} = this.props;
    helpData.map((obj)=>{
      if(obj.HELP_DEF_ID =="VIEW_RULE_CONFIG"){
          this.setState({fileContent:{__html:obj.FILE_CONTENT}});
      }
    })
    this.props.actions.showModalWindow('HELP_WINDOW');
  }

 onChange = (value, column) => {
    const {editErrors = {}} = this.state;
    this.modifiedRow[column.dataKey] = value;
    if (!value) {
      this.setState(
        {editRow: {...this.modifiedRow},
        	editErrors:column.dataKey=='COL_NM'? {...editErrors, [column.dataKey]: `${column.label}:Please enter column name`}:
            	column.dataKey=='MAX_CHAR_QTY'?{...editErrors, [column.dataKey]: `${column.label}:Please enter maximum character limit`}:
            		column.dataKey=='INPUT_COL_NUM'?{...editErrors, [column.dataKey]: `${column.label}:Please enter input column numbers seperated by comma`}:
							 column.dataKey=='MAPPING_RULE_ID'? {...editErrors, [column.dataKey]: undefined}:
								{...editErrors, [column.dataKey]: `${column.label} is required`}
      });
    } else {
      this.setState({
        editRow: {...this.modifiedRow},
        editErrors: {...editErrors, [column.dataKey]: undefined}
      });
    }
    return true;
  }

	onKeyDown = (e) => {
    switch (e.keyCode) {
      case 13: // enter key
      if(!this.modifiedRow) return;
        if (typeof this.modifiedRow['KEY_ID'] === 'undefined') {
          this.add();
        } else {
          this.update();
        }
        break;
      case 27: // escape key
        e.preventDefault();
        e.stopPropagation();
        this.setState({editRow: undefined});
        break;
      default:
        break;
    }
  }

	update = () => {
		this.modifiedRow.CLIENT_ID = _sutils.getSelectedClientId();
    if (this.validate()) {
      this.gridActions.update(this.modifiedRow).then((ret) => {
        if (ret.error) {
          this.gridActions.error('Error', ret.payload._error || 'Please correct errors.');
          this.setState({editErrors: ret.payload});
        } else {
        	let fileMappingId = this.state.fileMappingId;
          this.connectCallback(this.gridActions,{FILE_MAPPING_ID:fileMappingId, CLIENT_ID: _sutils.getSelectedClientId()});
        	//console.log ('ClientID::'+_sutils.getSelectedClientId());
        	this.gridActions.success('Success', 'Update was successful.');
            this.setState({editRow: undefined});
        }
      });
    }
  }

  add = () => {
	  if(this.state.fileMappingId && this.state.fileMappingId.trim()!='')
      this.modifiedRow.FILE_MAPPING_ID=this.state.fileMappingId;

	  this.modifiedRow.CLIENT_ID = _sutils.getSelectedClientId();
    if (this.validate()) {
      this.gridActions.addNew(this.modifiedRow).then((ret) => {
        if (ret.error) {
          this.gridActions.error('Error', ret.payload._error || 'Please correct errors.');
          this.setState({editErrors: ret.payload});
        } else {
        //	console.log('FILE_MAPPING_ID for add rule: '+ this.state.fileMappingId)
          let fileMappingId = this.state.fileMappingId;
          this.connectCallback(this.gridActions,{FILE_MAPPING_ID:fileMappingId, CLIENT_ID: _sutils.getSelectedClientId()});
          //console.log ('ClientID::'+_sutils.getSelectedClientId());
          this.gridActions.success('Success', `New record inserted!`);
          this.setState({editRow: undefined});
        }
      });
    }
  }

  
  
validate() {
    // plug in any validation framework here
    const errors = {};
    if (!this.modifiedRow.SEQUENCE_NUM) {
        errors.SEQUENCE_NUM = 'Sequence Number required';
      }
    
    if (this.modifiedRow.INPUT_COL_NUM) {
    	var regex  = /[A-Za-z_~!@#$%&*()_+-]/;
    	//console.log('expression: '+this.modifiedRow.INPUT_COL_NUM);
		//console.log('regex: '+regex.test(this.modifiedRow.INPUT_COL_NUM));
    	if (regex.test(this.modifiedRow.INPUT_COL_NUM))
    	{
    		//console.log('expression: '+this.modifiedRow.INPUT_COL_NUM);
    		//console.log('regex: '+regex.test(this.modifiedRow.INPUT_COL_NUM));
    		errors.INPUT_COL_NUM = 'Please enter number and comma only.';
    	}
    	
      }
   
    if (!this.modifiedRow.COL_NM) {
    	if(this.fileType!='XML' && this.fileType!='FIXED_LENGTH')
        errors.COL_NM = 'Column  Name is required';
      }
    if((undefined==this.modifiedRow.COL_NM || ""==this.modifiedRow.COL_NM || ""==this.modifiedRow.COL_NM.trim()))
    	{
    	if(this.fileType!='XML' && this.fileType!='FIXED_LENGTH')
    	errors.COL_NM = 'Column  Name must be provided';
    	}
    if (this.modifiedRow.COL_NM) {
    	if(this.fileType!='XML' && this.fileType!='FIXED_LENGTH'){
    	var regex  = /^([a-zA-Z_ ]+)$/;
    	if (!regex.test(this.modifiedRow.COL_NM))
    	errors.EXEC_PARAMS = 'Please enter characters only.';
    	}
  }
    if (!this.modifiedRow.DATA_TYPE_CD) {
        errors.DATA_TYPE_CD = 'Data Type is required';
      }
    if (!this.modifiedRow.MAX_CHAR_QTY) {
	      errors.MAX_CHAR_QTY = 'Max Char Qty is required';
	    }
    if (!this.modifiedRow.IS_MANDATORY_NM) {
      errors.IS_MANDATORY_NM = 'Is Mandatory required';
    }
   
    	if(undefined!=this.modifiedRow.RULE_TXT && ''!=this.modifiedRow.RULE_TXT){

    	if(this.modifiedRow.RULE_TYPE_NM=='DATE_FORMAT')
    		{
    		var boolean = false;
    			var date_frmt='';
    			
    			this.dateFrmt.forEach((col, index, array)=> {
    				if(col.LABEL==this.modifiedRow.RULE_TXT)
    					boolean = true;
    				date_frmt = date_frmt + '\n' + col.LABEL;
    	    	 });
    			if(boolean==false)
    				{
    				errors.RULE_TXT = 'Valid date formats :\n' + date_frmt.trim();
    				//this.gridActions.success('DATE_FORMATS', date_frmt.trim()+'dd/mm/yyyy:dd/mm/yyyy,dd/mm/yyyy:DD/MM/YYYY');
    				}
    		     
    			}
    
    	}
    this.setState({editErrors: errors}); 
    return Object.keys(errors).length === 0;
  }

	 showUploadWindow  = ()=> {
		this.props.actions.showModalWindow('FILE_UPLOAD');
	 }

   goBack=()=>{
	    //let params = {fileDefId:this.props.location.state.params.fileDefId,clientId:_sutils.getSelectedClientId()};
	    let params = {fileDefId:this.props.location.state.params.fileDefId,clientId:_sutils.getSelectedClientId()};
		this.context.router.push({pathname: '/ruleMappingconfig', state: {params: params}});
   }
  
   onMappingChange=(val) =>{
	   this.fileType = '';
	   this.getRuleMappingFileType(val)
	   this.setState({fileMappingId:val})
	   this.connectCallback(this.gridActions,{FILE_MAPPING_ID:val, CLIENT_ID: _sutils.getSelectedClientId()});
   }

addHeader =() =>{
	    console.log("Inside addHeader");
	    let params = {fileMappingId:this.state.fileMappingId,clientId:_sutils.getSelectedClientId(),screen:'view',fileType:this.fileType};
			this.context.router.push({pathname: '/ruleConfigHeader', state: {params: params}});
	  }
   addFooter=() =>{
	   console.log("Inside addHeader");
	   let params = {fileMappingId:this.state.fileMappingId,clientId:_sutils.getSelectedClientId(),screen:'view',fileType:this.fileType};
		this.context.router.push({pathname: '/ruleConfigFooter', state: {params: params}});
   }
   
   /*This method will customize the columns based on selected file types*/
   getGridColumn=()=>{	 
         if(this.fileType=='XML')
  			 return RULE_CONFIG_COLUMNS_XML;
         else if(this.fileType=='FIXED_LENGTH' || this.state.outputFileType=='ADV_FIXED_LENGTH')
			 return  [...RULE_CONFIG_COLUMNS
     	      , {             	 
    			  dataKey: 'ALIGNMENT',
    			  label: '*Alignment',
    			  width: 150,
    			  dataType: 'string',
    			  edit: true,
    			  editor: AlignmentEditor,
    			  maxLength:100
    			}]
  		 else
  			 return RULE_CONFIG_COLUMNS; 	
   }
   
   getRuleMappingFileType=(val)=>{
	   if(this.props.ruleMappingMetaData.data && this.props.ruleMappingMetaData.data.length>0)
		   this.props.ruleMappingMetaData.data.forEach((row, index, array)=> {
			   if(row['RULE_MAPPING_ID']==val)
				   this.fileType = row['OUTPUT_FILE_TYPE']
		   })
   }

  render() {
	  
	  
	this.columns=[];
	this.columns = this.getGridColumn();
	
	let {checkedRows,fileMappingId} = this.state;
	let {fileMappingData} = this.props;
	let enableDelete = checkedRows && checkedRows.length > 0;
	let enableAdd = typeof editRow === 'undefined' && (fileMappingId);
	let FILE_UPLOAD = <ModalWindow id={'FILE_UPLOAD'} modalHeader={'Rule configuration upload'} buttons={[]} showModalWindow = {this.props.showFileUploadModalWindow} modalCloseCallback={this.modalClosedCallback}> 
										<VerticalLayout flex='flex' style={{width: '100%'}}>
                      <FileUpload fileUploadCallback={this.uploadFileCallback.bind(this)} callType={'RULE_UPLOAD'} paramObject={{PARAM1:fileMappingId,PARAM2:_sutils.getSelectedClientId()}} fileUploadConfig={UPLOAD_FILE} />
                    </VerticalLayout> 
						   </ModalWindow>;
	 let HELP_WINDOW = <ModalWindow id={'HELP_WINDOW'} modalHeader={'Help'} buttons={[]} showModalWindow = {this.props.showHelpModalWindow}
                      modalCloseCallback={this.modalClosedCallback}> 
										<VerticalLayout flex='flex' style={{width: '100%'}}>
                      <span dangerouslySetInnerHTML={this.state.fileContent}></span>
                    </VerticalLayout> 
						   </ModalWindow>;	
					   
	let HEADER_BUTTON =  <Button className='btn btn-primary btn-xs' style={{marginRight: 8}} onClick={this.addHeader}>Header</Button>
	let FOOTER_BUTTON =  <Button className='btn btn-primary btn-xs' style={{marginRight: 8}} onClick={this.addFooter}>Footer</Button>
  let isFileMappingAvailable = 	this.props.location && this.props.location.state && this.props.location.state.params && this.props.location.state.params.fileMappingId && this.props.location.state.params.fileDefId;		
  let MESSAGE_DIALOG = <MessageDialog showDialog={this.props.showMessageDialog} messageDialogParams={this.props.messageDialogParams} />
  let BACK_BUTTON = <div style={{display: 'inline-block', float: 'left'}}>
        				<Button className='btn btn-primary btn-xs' onClick = {this.goBack.bind(this)}> {'<< Back'}</Button>
        </div>
  let UPLOAD_BUTTON = <Button className='btn btn-primary btn-xs' disabled={!this.state.fileMappingId} onClick = {this.showUploadWindow.bind(this)}>Upload File</Button>
  const hover = !this.state.fileMappingId ? <Popover id={`fileMapping_error`}>{'File Mapping ID is required'}</Popover> : <div />;
  const className = !this.state.fileMappingId  ? 'error' : null; 

     const BR = <br/>
    return (
			
<HorizontalLayout>
<ClientSelectionHeader disableDropDown={isFileMappingAvailable}/>
       <VerticalLayout flex='flex' onKeyDown={this.onKeyDown}> 
       <FixedPanel style={{overflow: 'visible'}}>
			 <h3 style={{marginTop: 0,marginBottom: 0,width: 760}}> <strong>View Rule Configuration</strong>
			 <strong className =' fa fa-question-circle' style={{ color: '#286090', fontSize: 24, marginLeft: 10,cursor:'pointer' }}
        onClick = {this.showHelpWindow.bind(this)} ></strong></h3>
       {isFileMappingAvailable &&  BR}
       {isFileMappingAvailable && BACK_BUTTON}
       {BR}
       <Form inline>
       	<FormGroup>
       	<label>&nbsp;&nbsp;{'Rule Mappings'}&nbsp;</label>	
			<FormControl componentClass="select" value={this.state.fileMappingId} onChange={(e)=> this.onMappingChange(e.target.value)}>
			<option value="">--Select--</option> 
			{(()=>{
	           if(fileMappingData.data!= undefined || fileMappingData.data!=null){
	             return fileMappingData.data.map((x)=>{
	            	 if (!x.CODE_VALUE.includes('Header') && !x.CODE_VALUE.includes('Footer'))
	            	 return (
	                 <option value={x.CODE_VALUE}>{x.CODE_VALUE}</option>
	               );
	             });
	           }
	         })()}
	         </FormControl>
		</FormGroup>
		
		
		<FormGroup>
		<label>&nbsp;&nbsp;{'Output File Type'}&nbsp;</label>	
			<input type="text" value={this.fileType} disabled='true'/>
		</FormGroup>
		
		</Form>
			  <div style={{display: 'inline-block', float: 'right'}}>
			{(this.fileType=='XML' || this.fileType=='FIXED_LENGTH' || this.fileType=='ADV_FIXED_LENGTH') && HEADER_BUTTON}
			{(this.fileType=='XML' || this.fileType=='FIXED_LENGTH' || this.fileType=='ADV_FIXED_LENGTH') && FOOTER_BUTTON}
                 <Button className='btn btn-primary btn-xs' style={{marginRight: 8}}  disabled={!enableAdd} onClick={this.addNew} >Add</Button>
				 <Button className='btn btn-primary btn-xs' style={{marginRight: 8}} onClick={this.onDeleteLinkClick} disabled={!enableDelete}>Delete</Button>
				 {UPLOAD_BUTTON}
							{ /*	<Button className='btn btn-primary btn-xs' onClick = {this.showUploadWindow.bind(this)}>Upload File</Button>  */ 
            }
            </div>
     </FixedPanel>
     <FlexPanel>
      <DynamicDataGrid
		columns={this.columns}
        dataIdf={553840004}
        gridConnectCallback={this.connectCallback}
        componentId='mappingRuleGrid'
        keyFieldName='KEY_ID'
				editRow={this.state.editRow}
				onRowDoubleClick={this.onRowDoubleClick}
				onChange={this.onChange}
				editErrors={this.state.editErrors}
      			onCheckedChange={this.onCheck}
      			scale ={1}
				pageSize={50}
        		excelExport
        		csvExport
        		hasCheckbox
      /> 
      </FlexPanel>
			{FILE_UPLOAD}
			 {HELP_WINDOW}
			</VerticalLayout>
			{MESSAGE_DIALOG}
			</HorizontalLayout>

    );
  }
}



