
import React, { Component, PropTypes } from 'react';
import { connectCdtDataComponent } from 'ssc-cdt3';
import { Link } from 'react-router';
import { connect } from 'react-redux';

import * as _service from '../service'
import * as _sutils from '../sharedutils';
import * as _aconst from '../appconstants';



/**
 *  @author p530579
 * Class to do all kind of validation while logging to DAS
 **/
function mapStateToProps(state) {
  //  console.log('state from appvalidation : ',state);
  return {
    authsession: state.authsession,
    helpData: state.help.helpData
  }
}

@connect(mapStateToProps, _sutils.mapDispatchToProps)
@connectCdtDataComponent('esfData', 553840009)
@connectCdtDataComponent('clientData', 553840008)
@connectCdtDataComponent('helpData', 553840013)
export default class AppValidationContainer extends Component {

  static contextTypes = {
    router: PropTypes.object.isRequired,
  }

  static propTypes = {
    esfData: PropTypes.object,
    esfDataActions: PropTypes.object,
    clientData: PropTypes.object,
    clientDataActions: PropTypes.object,
    helpData: PropTypes.object,
    helpDataActions: PropTypes.object,
  };

  constructor(props) {
    super(props);
  }

  componentDidMount() {

    if (!_sutils.isEmpty(_sutils.getUserId(this.props))) // call only if the session is authorized.  
      this.doValidation();
  }

  doValidation = () => {
    this.doESFValidation();
  }



  doESFValidation = () => {
    let params = { USER_ID: _sutils.getUserId(this.props), ACTION: 'APP_ENTITLEMENT' };
    _service.makeCallWithHandlers(this.props.esfDataActions, _service.CALL_TYPE_LOADLIST, params, this.esfValidationSuccessHandler, _sutils.defaultErrorHandler.bind(this), undefined, this.props);
  }

  esfValidationSuccessHandler = (ret, actions, spinJobId) => {
    let isValid = "false";
    if (ret.payload.data && ret.payload.data.length > 0)
      isValid = ret.payload.data[0].IS_APP_ENTITLED;

    _sutils.setSessionStorage('IS_MTEX_APP_ENTITLED', isValid);

    if (_sutils.doCheckforEntitlement(this, true))
      _service.makeCallWithHandlers(this.props.clientDataActions, _service.CALL_TYPE_LOADLIST, { CALL_TYPE: 'CLIENT_ID' }, this.entitledClientsLoadedSuccess, _sutils.defaultErrorHandler.bind(this), undefined, this.props);
  }

  entitledClientsLoadedSuccess = (ret, actions, spinJobId) => {
    if (ret.payload.data && ret.payload.data.length > 0)
      _sutils.setSessionStorage(_aconst.SS_CURRENT_SELECTED_CLIENT, ret.payload.data[0]);
    this.props.actions.reloadClientDropdown(ret.payload.data);
    _service.makeCallWithHandlers(this.props.helpDataActions, _service.CALL_TYPE_LOAD, null, this.HelpSuccessHandler, _sutils.defaultErrorHandler.bind(this), undefined, this.props);
    this.loadHomepage();
  }

  HelpSuccessHandler = (ret, actions, spinJobId) => {
    this.props.actions.loadHelpData(ret.payload.data);
  }
  loadHomepage = () => {
    this.context.router.push({ pathname: '/filedef' });
  }


  componentWillReceiveProps(props) {
    // this.doValidation(); 

  }

  render() {
    return (
      <div>

      </div>
    );
  }
}
